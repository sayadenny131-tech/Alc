#!/usr/bin/env python3
"""SKUY Lua custom Lua 5.3 bytecode toolkit.
Designed for Python 3.14 / Termux Android.

Compatibility engine identifiers are intentionally preserved internally.
"""
from __future__ import annotations

import argparse
import os
import struct
import subprocess
import shutil
import hashlib
import json
import sys
import tempfile
import zlib
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# Recovered fixed per-string XOR key (32 bytes), reset for every string.
XOR_KEY = bytes.fromhex(
    "112136474657a78d9d8490d8ab008c35"
    "261af7e45805b8b31507d02c1e8ff6c8"
)

# Observed custom header: Lua 5.3, int=4, size_t=4, instruction=4,
# lua_Integer=8, lua_Number=8, main upvalues=1.
CUSTOM_HEADER = bytes.fromhex(
    "1b4c7561530019930d0a1a0a0404040808"
    "7856000000000000000000000028774001"
)

WATERMARK = b"THIS FILE IS ENCRYPTED BY @SKUY_JANCOOOOOKKKKKKK TOOL"
EXTRA_SOURCE = b"=[V9_OBFUSCATION_ENGINE_BY_@SKUY_JANCOOOOOKKKKKKK]"
EXTRA_CONST_1 = b"PROTECTED_BY_SKUYYY_V9_JANCOK"
EXTRA_CONST_2 = b"https://t.me/sayadeni1311"
EXTRA_INTEGER = 0x7FFFFFFF
EXTRA_RETURN_WORD_CUSTOM = 16422  # raw opcode 38, RETURN A=0 B=1 C=0
FINAL_FOOTER = bytes.fromhex("000000054e647811")

# Full opcode mapping recovered as a simple permutation:
# std 13..29 -> custom 0..16
# std 0..12  -> custom 17..29
# std 30..46 -> unchanged
# This agrees with all directly observed mappings (ADD, BAND, BXOR, SETTABUP, etc.).
def std_opcode_to_custom(op: int) -> int:
    if 0 <= op <= 12:
        return op + 17
    if 13 <= op <= 29:
        return op - 13
    if 30 <= op <= 46:
        return op
    raise ValueError(f"invalid Lua 5.3 opcode {op}")


def custom_opcode_to_std(op: int) -> int:
    if 0 <= op <= 16:
        return op + 13
    if 17 <= op <= 29:
        return op - 17
    if 30 <= op <= 46:
        return op
    raise ValueError(f"invalid custom opcode {op}")


def remap_word(word: int, forward: bool = True) -> int:
    op = word & 0x3F
    new_op = std_opcode_to_custom(op) if forward else custom_opcode_to_std(op)
    return (word & ~0x3F) | new_op


@dataclass
class Constant:
    tag: int
    value: object = None


@dataclass
class Proto:
    source: Optional[bytes]
    linedefined: int
    lastlinedefined: int
    numparams: int
    is_vararg: int
    maxstacksize: int
    code: list[int] = field(default_factory=list)
    constants: list[Constant] = field(default_factory=list)
    upvalues: list[tuple[int, int]] = field(default_factory=list)
    children: list["Proto"] = field(default_factory=list)
    # Standard 5.3 debug (input only)
    std_lineinfo: list[int] = field(default_factory=list)
    std_locvars: list[tuple[Optional[bytes], int, int]] = field(default_factory=list)
    std_upvalue_names: list[Optional[bytes]] = field(default_factory=list)
    # Custom debug (output / custom parse)
    lineinfo_bytes: bytes = b""
    abslineinfo: list[tuple[int, int]] = field(default_factory=list)
    locvars: list[tuple[Optional[bytes], int, int]] = field(default_factory=list)
    upvalue_names: list[Optional[bytes]] = field(default_factory=list)


class Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def take(self, n: int) -> bytes:
        if n < 0 or self.pos + n > len(self.data):
            raise EOFError(f"EOF at 0x{self.pos:X}, need {n}")
        out = self.data[self.pos:self.pos+n]
        self.pos += n
        return out

    def u8(self) -> int:
        return self.take(1)[0]

    def i32(self) -> int:
        return struct.unpack("<i", self.take(4))[0]

    def u32(self) -> int:
        return struct.unpack("<I", self.take(4))[0]


@dataclass
class LuaHeader:
    int_size: int
    size_t_size: int
    instruction_size: int
    lua_integer_size: int
    lua_number_size: int
    main_upvalues: int
    raw: bytes


def parse_lua53_header(r: Reader) -> LuaHeader:
    start = r.pos
    if r.take(4) != b"\x1bLua":
        raise ValueError("not a Lua chunk")
    version = r.u8()
    fmt = r.u8()
    if version != 0x53 or fmt != 0:
        raise ValueError(f"expected Lua 5.3 format 0, got version=0x{version:02X} format={fmt}")
    if r.take(6) != b"\x19\x93\r\n\x1a\n":
        raise ValueError("bad LUAC_DATA")
    int_size = r.u8()
    size_t_size = r.u8()
    ins_size = r.u8()
    lint_size = r.u8()
    lnum_size = r.u8()
    r.take(lint_size)  # LUAC_INT
    r.take(lnum_size)  # LUAC_NUM
    main_up = r.u8()
    return LuaHeader(int_size, size_t_size, ins_size, lint_size, lnum_size,
                     main_up, r.data[start:r.pos])


def read_uint(r: Reader, size: int) -> int:
    return int.from_bytes(r.take(size), "little", signed=False)


def read_int(r: Reader, size: int) -> int:
    return int.from_bytes(r.take(size), "little", signed=True)


def read_plain_string(r: Reader, size_t_size: int) -> Optional[bytes]:
    n = r.u8()
    if n == 0:
        return None
    if n == 0xFF:
        n = read_uint(r, size_t_size)
    if n < 1:
        raise ValueError("bad Lua string size")
    return r.take(n - 1)


def xor_bytes(data: bytes) -> bytes:
    return bytes(b ^ XOR_KEY[i % len(XOR_KEY)] for i, b in enumerate(data))


def read_custom_string(r: Reader) -> Optional[bytes]:
    n = r.u8()
    if n == 0:
        return None
    if n == 0xFF:
        n = r.u32()
    if n < 1:
        raise ValueError("bad custom string size")
    return xor_bytes(r.take(n - 1))


def parse_constant_standard(r: Reader, h: LuaHeader) -> Constant:
    tag = r.u8()
    if tag == 0:
        return Constant(tag, None)
    if tag == 1:
        return Constant(tag, bool(r.u8()))
    if tag == 3:
        return Constant(tag, r.take(h.lua_number_size))
    if tag in (4, 20):
        return Constant(tag, read_plain_string(r, h.size_t_size))
    if tag == 19:
        return Constant(tag, r.take(h.lua_integer_size))
    raise ValueError(f"unsupported constant tag {tag} at 0x{r.pos-1:X}")


def parse_constant_custom(r: Reader) -> Constant:
    tag = r.u8()
    if tag == 0:
        return Constant(tag, None)
    if tag == 1:
        return Constant(tag, bool(r.u8()))
    if tag in (3, 19):
        return Constant(tag, r.take(8))
    if tag in (4, 20):
        return Constant(tag, read_custom_string(r))
    raise ValueError(f"unsupported custom constant tag {tag} at 0x{r.pos-1:X}")


def parse_standard_proto(r: Reader, h: LuaHeader) -> Proto:
    p = Proto(
        source=read_plain_string(r, h.size_t_size),
        linedefined=read_int(r, h.int_size),
        lastlinedefined=read_int(r, h.int_size),
        numparams=r.u8(), is_vararg=r.u8(), maxstacksize=r.u8(),
    )
    ncode = read_int(r, h.int_size)
    if ncode < 0:
        raise ValueError("negative code count")
    p.code = [read_uint(r, h.instruction_size) for _ in range(ncode)]
    nk = read_int(r, h.int_size)
    p.constants = [parse_constant_standard(r, h) for _ in range(nk)]
    nu = read_int(r, h.int_size)
    p.upvalues = [(r.u8(), r.u8()) for _ in range(nu)]
    np = read_int(r, h.int_size)
    p.children = [parse_standard_proto(r, h) for _ in range(np)]
    # Standard Lua 5.3 debug section.
    nline = read_int(r, h.int_size)
    p.std_lineinfo = [read_int(r, h.int_size) for _ in range(nline)]
    nloc = read_int(r, h.int_size)
    p.std_locvars = [
        (read_plain_string(r, h.size_t_size), read_int(r, h.int_size), read_int(r, h.int_size))
        for _ in range(nloc)
    ]
    nupn = read_int(r, h.int_size)
    p.std_upvalue_names = [read_plain_string(r, h.size_t_size) for _ in range(nupn)]
    return p


def parse_custom_proto(r: Reader) -> Proto:
    p = Proto(
        source=read_custom_string(r),
        linedefined=r.i32(), lastlinedefined=r.i32(),
        numparams=r.u8(), is_vararg=r.u8(), maxstacksize=r.u8(),
    )
    ncode = r.i32()
    p.code = [r.u32() for _ in range(ncode)]
    nk = r.i32()
    p.constants = [parse_constant_custom(r) for _ in range(nk)]
    nu = r.i32()
    p.upvalues = [(r.u8(), r.u8()) for _ in range(nu)]
    np = r.i32()
    p.children = [parse_custom_proto(r) for _ in range(np)]
    # Observed custom debug layout is Lua-5.4-like:
    # byte lineinfo + absolute-line table + locvars + upvalue names.
    nline = r.i32()
    p.lineinfo_bytes = r.take(nline)
    nabs = r.i32()
    p.abslineinfo = [(r.i32(), r.i32()) for _ in range(nabs)]
    nloc = r.i32()
    p.locvars = [(read_custom_string(r), r.i32(), r.i32()) for _ in range(nloc)]
    nupn = r.i32()
    p.upvalue_names = [read_custom_string(r) for _ in range(nupn)]
    return p


def parse_standard_chunk(data: bytes) -> tuple[LuaHeader, Proto, int]:
    r = Reader(data)
    h = parse_lua53_header(r)
    root = parse_standard_proto(r, h)
    return h, root, r.pos


def parse_custom_chunk(data: bytes) -> tuple[LuaHeader, Proto, int]:
    r = Reader(data)
    h = parse_lua53_header(r)
    if (h.int_size, h.size_t_size, h.instruction_size, h.lua_integer_size, h.lua_number_size) != (4,4,4,8,8):
        raise ValueError("not the expected custom chunk layout")
    root = parse_custom_proto(r)
    return h, root, r.pos


def clone_core_to_custom(p: Proto) -> Proto:
    out = Proto(
        source=p.source,
        linedefined=p.linedefined,
        lastlinedefined=p.lastlinedefined,
        numparams=p.numparams,
        is_vararg=p.is_vararg,
        maxstacksize=p.maxstacksize,
        code=[remap_word(w, True) for w in p.code],
        constants=[Constant(c.tag, c.value) for c in p.constants],
        upvalues=list(p.upvalues),
        children=[clone_core_to_custom(c) for c in p.children],
        lineinfo_bytes=b"",
        abslineinfo=[],
        locvars=[(WATERMARK, EXTRA_INTEGER, EXTRA_INTEGER)],
        upvalue_names=[],
    )
    return out


def make_extra_proto() -> Proto:
    return Proto(
        source=EXTRA_SOURCE,
        linedefined=0, lastlinedefined=0,
        numparams=0, is_vararg=0, maxstacksize=2,
        code=[EXTRA_RETURN_WORD_CUSTOM],
        constants=[
            Constant(4, EXTRA_CONST_1),
            Constant(4, EXTRA_CONST_2),
            Constant(19, struct.pack("<q", EXTRA_INTEGER)),
        ],
        upvalues=[], children=[],
        lineinfo_bytes=b"\x01", abslineinfo=[],
        locvars=[(WATERMARK, EXTRA_INTEGER, EXTRA_INTEGER)],
        upvalue_names=[],
    )


def transform_standard_to_custom(root: Proto) -> Proto:
    out = clone_core_to_custom(root)
    out.children.append(make_extra_proto())
    return out


def is_extra_proto(p: Proto) -> bool:
    try:
        return (
            p.source == EXTRA_SOURCE and p.code == [EXTRA_RETURN_WORD_CUSTOM]
            and len(p.constants) == 3
            and p.constants[0].tag == 4 and p.constants[0].value == EXTRA_CONST_1
            and p.constants[1].tag == 4 and p.constants[1].value == EXTRA_CONST_2
            and p.constants[2].tag == 19
        )
    except Exception:
        return False


def clone_core_to_standard(p: Proto, depth: int = 0, restore_line_offset: bool = False) -> Proto:
    # Some NADEEM inputs go through a one-line source normalization (observed
    # when the original source begins with a blank line).  Restoring to the
    # *direct luac output of the original source* therefore needs +1 only in
    # that case.  For sources without the leading blank, no adjustment is made.
    linedefined = p.linedefined
    lastlinedefined = p.lastlinedefined
    if restore_line_offset and depth > 0:
        if linedefined > 0:
            linedefined += 1
        if lastlinedefined > 0:
            lastlinedefined += 1

    return Proto(
        source=p.source,
        linedefined=linedefined, lastlinedefined=lastlinedefined,
        numparams=p.numparams, is_vararg=p.is_vararg, maxstacksize=p.maxstacksize,
        code=[remap_word(w, False) for w in p.code],
        constants=[Constant(c.tag, c.value) for c in p.constants],
        upvalues=list(p.upvalues),
        children=[clone_core_to_standard(c, depth + 1, restore_line_offset) for c in p.children],
        std_lineinfo=[], std_locvars=[], std_upvalue_names=[],
    )


class CustomWriter:
    def __init__(self, main_upvalues: int = 1):
        self.buf = bytearray(CUSTOM_HEADER[:-1] + bytes([main_upvalues & 0xFF]))

    def put(self, b: bytes): self.buf.extend(b)
    def u8(self, v: int): self.buf.append(v & 0xFF)
    def i32(self, v: int): self.put(struct.pack("<i", v))
    def u32(self, v: int): self.put(struct.pack("<I", v))

    def string(self, s: Optional[bytes]):
        if s is None:
            self.u8(0); return
        n = len(s) + 1
        if n < 0xFF:
            self.u8(n)
        else:
            self.u8(0xFF); self.u32(n)
        self.put(xor_bytes(s))

    def proto(self, p: Proto):
        self.string(p.source)
        self.i32(p.linedefined); self.i32(p.lastlinedefined)
        self.u8(p.numparams); self.u8(p.is_vararg); self.u8(p.maxstacksize)
        self.i32(len(p.code))
        for w in p.code: self.u32(w)
        self.i32(len(p.constants))
        for c in p.constants:
            self.u8(c.tag)
            if c.tag == 0: pass
            elif c.tag == 1: self.u8(1 if c.value else 0)
            elif c.tag in (3, 19):
                if isinstance(c.value, (bytes, bytearray)):
                    self.put(bytes(c.value))
                else:
                    fmt = "<d" if c.tag == 3 else "<q"
                    self.put(struct.pack(fmt, c.value))
            elif c.tag in (4, 20): self.string(c.value)
            else: raise ValueError(f"unsupported tag {c.tag}")
        self.i32(len(p.upvalues))
        for a,b in p.upvalues: self.u8(a); self.u8(b)
        self.i32(len(p.children))
        for c in p.children: self.proto(c)
        self.i32(len(p.lineinfo_bytes)); self.put(p.lineinfo_bytes)
        self.i32(len(p.abslineinfo))
        for pc,line in p.abslineinfo: self.i32(pc); self.i32(line)
        self.i32(len(p.locvars))
        for name, startpc, endpc in p.locvars:
            self.string(name); self.i32(startpc); self.i32(endpc)
        self.i32(len(p.upvalue_names))
        for n in p.upvalue_names: self.string(n)


class StandardWriter:
    def __init__(self, main_upvalues: int = 1, size_t_size: int = 8):
        self.int_size=4; self.size_t_size=size_t_size; self.ins_size=4
        # Standard Lua 5.3 header for little-endian 64-bit Android-like host.
        sizes=bytes([4,size_t_size,4,8,8])
        self.buf=bytearray(b"\x1bLua\x53\x00\x19\x93\r\n\x1a\n"+sizes)
        self.buf += struct.pack("<q", 0x5678)
        self.buf += struct.pack("<d", 370.5)
        self.buf.append(main_upvalues & 0xFF)

    def put(self,b): self.buf.extend(b)
    def u8(self,v): self.buf.append(v&0xFF)
    def i32(self,v): self.put(struct.pack("<i",v))
    def string(self,s):
        if s is None: self.u8(0); return
        n=len(s)+1
        if n<0xFF:self.u8(n)
        else:self.u8(0xFF);self.put(n.to_bytes(self.size_t_size,"little"))
        self.put(s)
    def proto(self,p: Proto):
        self.string(p.source)
        self.i32(p.linedefined);self.i32(p.lastlinedefined)
        self.u8(p.numparams);self.u8(p.is_vararg);self.u8(p.maxstacksize)
        self.i32(len(p.code));[self.put(struct.pack("<I",w)) for w in p.code]
        self.i32(len(p.constants))
        for c in p.constants:
            self.u8(c.tag)
            if c.tag==0:pass
            elif c.tag==1:self.u8(1 if c.value else 0)
            elif c.tag in (3,19):
                if isinstance(c.value,(bytes,bytearray)):self.put(bytes(c.value))
                else:self.put(struct.pack("<d" if c.tag==3 else "<q",c.value))
            elif c.tag in (4,20):self.string(c.value)
            else:raise ValueError(c.tag)
        self.i32(len(p.upvalues));[(self.u8(a),self.u8(b)) for a,b in p.upvalues]
        self.i32(len(p.children));[self.proto(c) for c in p.children]
        # stripped standard Lua 5.3 debug
        self.i32(0);self.i32(0);self.i32(0)


def build_trailer(body: bytes, rand32: bytes | None=None, rand48: bytes | None=None,
                  rand64: bytes | None=None) -> bytes:
    r32 = os.urandom(32) if rand32 is None else rand32
    r48 = os.urandom(48) if rand48 is None else rand48
    r64 = os.urandom(64) if rand64 is None else rand64
    if (len(r32),len(r48),len(r64)) != (32,48,64):
        raise ValueError("random blocks must be 32/48/64 bytes")
    out=bytearray(body)
    # Bz (+59)
    base_len=len(out)
    out += bytes.fromhex("cefaedfe") + b"SKUYYV5" + r32
    out += bytes.fromhex("dec0adde") + b"MEDN"
    out += struct.pack("<I",base_len) + bytes.fromhex("bebafeca")
    # C1 (+84): CRC32 is over the entire input to C1 (body+Bz).
    in_len=len(out); crc=zlib.crc32(out)&0xFFFFFFFF
    out += bytes.fromhex("b00b135e") + b"NDV6" + bytes.fromhex("deadc0de")
    out += bytes.fromhex("00000600") + struct.pack("<I",in_len) + struct.pack("<I",crc)
    out += b"SKUYY_6V" + r48 + bytes.fromhex("0df0adba")
    # C5 (+122): CRC32 is over the entire input to C5 (body+Bz+C1).
    in_len=len(out); crc=zlib.crc32(out)&0xFFFFFFFF
    out += b"ENCRYPTED_BY_OFFICIAL_SKUYYYJANCOK" + bytes.fromhex("00000900")
    out += struct.pack("<I",in_len) + struct.pack("<I",crc)
    out += b"SKUYY_9V" + r64 + bytes.fromhex("0df0adde")
    out += FINAL_FOOTER
    return bytes(out)


def validate_trailer(data: bytes, parse_end: int) -> dict:
    if len(data)-parse_end != 273:
        return {"valid":False,"reason":f"trailer size {len(data)-parse_end}, expected 273"}
    t=data[parse_end:]
    checks=[]
    checks.append((t[:11] == bytes.fromhex("cefaedfe")+b"SKUYYV5","Bz magic"))
    checks.append((struct.unpack("<I",t[0x33:0x37])[0] == parse_end,"Bz pointer"))
    checks.append((struct.unpack("<I",t[0x4B:0x4F])[0] == parse_end+59,"C1 pointer"))
    checks.append((struct.unpack("<I",t[0x4F:0x53])[0] == (zlib.crc32(data[:parse_end+59])&0xFFFFFFFF),"C1 CRC"))
    checks.append((struct.unpack("<I",t[0xB5:0xB9])[0] == parse_end+143,"C5 pointer"))
    checks.append((struct.unpack("<I",t[0xB9:0xBD])[0] == (zlib.crc32(data[:parse_end+143])&0xFFFFFFFF),"C5 CRC"))
    checks.append((t[-8:] == FINAL_FOOTER,"footer"))
    return {"valid":all(x for x,_ in checks),"checks":checks}



# ---------------------------------------------------------------------------
# Original-trailer preservation helpers (Cosmetic/Text editor)
# ---------------------------------------------------------------------------

def validate_trailer_compatible(data: bytes, parse_end: int) -> dict:
    """Validate the known 273-byte trailer layout without forcing a brand name.

    This accepts the same structural trailer layout used by this toolkit while
    preserving whatever 7-byte brand is already present in the input file.
    """
    if len(data) - parse_end == 0:
        return {"valid": True, "kind": "none", "brand": "NONE", "checks": []}
    if len(data) - parse_end != 273:
        return {
            "valid": False,
            "kind": "unknown",
            "brand": "UNKNOWN",
            "reason": f"trailer size {len(data)-parse_end}, expected 273",
        }

    t = data[parse_end:]
    brand_raw = t[4:11]
    try:
        brand = brand_raw.decode("ascii")
    except UnicodeDecodeError:
        brand = brand_raw.decode("ascii", "replace")

    checks = []
    checks.append((t[:4] == bytes.fromhex("cefaedfe"), "Bz magic"))
    checks.append((struct.unpack("<I", t[0x33:0x37])[0] == parse_end, "Bz pointer"))
    checks.append((struct.unpack("<I", t[0x4B:0x4F])[0] == parse_end + 59, "C1 pointer"))
    checks.append((
        struct.unpack("<I", t[0x4F:0x53])[0]
        == (zlib.crc32(data[:parse_end + 59]) & 0xFFFFFFFF),
        "C1 CRC",
    ))
    checks.append((struct.unpack("<I", t[0xB5:0xB9])[0] == parse_end + 143, "C5 pointer"))
    checks.append((
        struct.unpack("<I", t[0xB9:0xBD])[0]
        == (zlib.crc32(data[:parse_end + 143]) & 0xFFFFFFFF),
        "C5 CRC",
    ))
    checks.append((t[-8:] == FINAL_FOOTER, "footer"))
    return {
        "valid": all(ok for ok, _ in checks),
        "kind": "known-273",
        "brand": brand,
        "brand_raw_hex": brand_raw.hex(),
        "checks": checks,
    }


def _build_with_original_trailer(original: bytes, old_parse_end: int,
                                 new_body: bytes) -> tuple[bytes, dict]:
    """Attach the input file's trailer to a rebuilt body and refresh pointers/CRCs."""
    original_info = validate_trailer_compatible(original, old_parse_end)
    if not original_info.get("valid"):
        raise ValueError(
            "format trailer original belum didukung untuk dipertahankan: "
            + str(original_info.get("reason") or original_info.get("checks"))
        )

    # No trailer: preserve that fact.
    if original_info.get("kind") == "none":
        return new_body, original_info

    trailer = bytearray(original[old_parse_end:])
    new_end = len(new_body)

    # Preserve every original trailer byte except fields whose values depend on
    # body length/content.
    trailer[0x33:0x37] = struct.pack("<I", new_end)
    trailer[0x4B:0x4F] = struct.pack("<I", new_end + 59)

    stage = bytearray(new_body) + trailer
    c1 = zlib.crc32(stage[:new_end + 59]) & 0xFFFFFFFF
    trailer[0x4F:0x53] = struct.pack("<I", c1)

    trailer[0xB5:0xB9] = struct.pack("<I", new_end + 143)
    stage = bytearray(new_body) + trailer
    c5 = zlib.crc32(stage[:new_end + 143]) & 0xFFFFFFFF
    trailer[0xB9:0xBD] = struct.pack("<I", c5)

    full = bytes(new_body) + bytes(trailer)
    check = validate_trailer_compatible(full, new_end)
    if not check.get("valid"):
        raise RuntimeError(f"trailer original gagal diverifikasi: {check}")
    return full, check


def _custom_constant_string_offsets(data: bytes) -> dict[tuple[str, int], dict]:
    """Map string constants to their exact encoded payload offsets in the file."""
    r = Reader(data)
    parse_lua53_header(r)
    found: dict[tuple[str, int], dict] = {}

    def read_string_meta():
        n0_pos = r.pos
        n = r.u8()
        if n == 0:
            return {"length_prefix_pos": n0_pos, "payload_pos": None, "payload_len": 0}
        if n == 0xFF:
            n = r.u32()
        if n < 1:
            raise ValueError("bad custom string size")
        payload_pos = r.pos
        payload_len = n - 1
        r.take(payload_len)
        return {
            "length_prefix_pos": n0_pos,
            "payload_pos": payload_pos,
            "payload_len": payload_len,
        }

    def walk(path: str):
        read_string_meta()  # source
        r.i32(); r.i32()
        r.u8(); r.u8(); r.u8()

        ncode = r.i32()
        if ncode < 0:
            raise ValueError("negative code count")
        r.take(ncode * 4)

        nk = r.i32()
        if nk < 0:
            raise ValueError("negative constant count")
        for i in range(nk):
            tag = r.u8()
            if tag == 0:
                pass
            elif tag == 1:
                r.u8()
            elif tag in (3, 19):
                r.take(8)
            elif tag in (4, 20):
                meta = read_string_meta()
                meta["tag"] = tag
                found[(path, i)] = meta
            else:
                raise ValueError(f"unsupported custom constant tag {tag}")

        nu = r.i32()
        if nu < 0:
            raise ValueError("negative upvalue count")
        r.take(nu * 2)

        np = r.i32()
        if np < 0:
            raise ValueError("negative child proto count")
        for i in range(np):
            walk(f"{path}.{i}")

        nline = r.i32()
        if nline < 0:
            raise ValueError("negative lineinfo count")
        r.take(nline)

        nabs = r.i32()
        if nabs < 0:
            raise ValueError("negative abslineinfo count")
        r.take(nabs * 8)

        nloc = r.i32()
        if nloc < 0:
            raise ValueError("negative locvar count")
        for _ in range(nloc):
            read_string_meta(); r.i32(); r.i32()

        nupn = r.i32()
        if nupn < 0:
            raise ValueError("negative upvalue-name count")
        for _ in range(nupn):
            read_string_meta()

    walk("root")
    return found


def patch_text_constant_fixed_in_place(inp: Path, out: Path, proto_path: str,
                                       index: int, new_text: str,
                                       expect: str | None = None) -> dict:
    """Patch one decoded text constant without rebuilding the bytecode body."""
    original = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(original)
    p = _get_proto_by_path(root, proto_path)
    if index < 0 or index >= len(p.constants):
        raise IndexError(f"constant index {index} tidak tersedia di {proto_path}")

    old = p.constants[index]
    if old.tag not in (4, 20):
        raise ValueError("constant yang dipilih bukan text/string")
    old_text = _const_python_value(old)
    if expect is not None and expect != old_text:
        raise ValueError("isi text berubah dari nilai yang dipilih; batalkan untuk keamanan")

    old_raw = (old.value or b"") if isinstance(old.value, bytes) else str(old.value).encode("utf-8")
    new_raw = new_text.encode("utf-8")
    if len(old_raw) != len(new_raw):
        raise ValueError(
            f"panjang berbeda: lama {len(old_raw)} byte, baru {len(new_raw)} byte"
        )

    offsets = _custom_constant_string_offsets(original)
    meta = offsets.get((proto_path, index))
    if not meta or meta.get("payload_pos") is None:
        raise ValueError("posisi text pada bytecode tidak ditemukan")
    if meta["payload_len"] != len(old_raw):
        raise ValueError("panjang text parser dan posisi file tidak cocok")

    pos = meta["payload_pos"]
    encoded_old = original[pos:pos + len(old_raw)]
    if xor_bytes(encoded_old) != old_raw:
        raise ValueError("text terenkripsi pada posisi terpilih tidak cocok")

    patched_body = bytearray(original[:parse_end])
    patched_body[pos:pos + len(new_raw)] = xor_bytes(new_raw)
    full, trailer_info = _build_with_original_trailer(
        original, parse_end, bytes(patched_body)
    )

    # Verify decoded result and unchanged main structure.
    h2, root2, end2 = parse_custom_chunk(full)
    if end2 != parse_end:
        raise RuntimeError("posisi akhir bytecode berubah pada fixed-length patch")
    p2 = _get_proto_by_path(root2, proto_path)
    if _const_python_value(p2.constants[index]) != new_text:
        raise RuntimeError("hasil text tidak cocok setelah verifikasi")

    before_stats = stats(root)
    after_stats = stats(root2)
    if before_stats != after_stats:
        raise RuntimeError("struktur utama berubah pada fixed-length patch")

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(full)
    return {
        "input": str(inp),
        "output": str(out),
        "method": "fixed-length-original",
        "proto": proto_path,
        "index": index,
        "old_bytes": len(old_raw),
        "new_bytes": len(new_raw),
        "old_file_size": len(original),
        "new_file_size": len(full),
        "brand": trailer_info.get("brand"),
        "trailer_valid": trailer_info.get("valid", False),
        "structure_same": before_stats == after_stats,
        "sha256": hashlib.sha256(full).hexdigest(),
    }


def rebuild_text_constant_original(inp: Path, out: Path, proto_path: str,
                                   index: int, new_text: str,
                                   expect: str | None = None) -> dict:
    """Rebuild a text constant while preserving the original trailer when supported."""
    original = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(original)
    p = _get_proto_by_path(root, proto_path)
    if index < 0 or index >= len(p.constants):
        raise IndexError(f"constant index {index} tidak tersedia di {proto_path}")

    old = p.constants[index]
    if old.tag not in (4, 20):
        raise ValueError("constant yang dipilih bukan text/string")
    old_text = _const_python_value(old)
    if expect is not None and expect != old_text:
        raise ValueError("isi text berubah dari nilai yang dipilih; batalkan untuk keamanan")

    new_raw = new_text.encode("utf-8")
    p.constants[index] = Constant(old.tag, new_raw)

    writer = CustomWriter(main_upvalues=h.main_upvalues)
    writer.proto(root)
    new_body = bytes(writer.buf)
    full, trailer_info = _build_with_original_trailer(original, parse_end, new_body)

    h2, root2, end2 = parse_custom_chunk(full)
    p2 = _get_proto_by_path(root2, proto_path)
    if _const_python_value(p2.constants[index]) != new_text:
        raise RuntimeError("hasil text tidak cocok setelah rebuild")

    before_stats = stats(parse_custom_chunk(original)[1])
    after_stats = stats(root2)
    if before_stats != after_stats:
        raise RuntimeError("jumlah struktur utama berubah setelah rebuild")

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(full)
    return {
        "input": str(inp),
        "output": str(out),
        "method": "rebuild-original",
        "proto": proto_path,
        "index": index,
        "old_bytes": len(old_text.encode("utf-8")),
        "new_bytes": len(new_raw),
        "old_file_size": len(original),
        "new_file_size": len(full),
        "old_parse_end": parse_end,
        "new_parse_end": end2,
        "brand": trailer_info.get("brand"),
        "trailer_valid": trailer_info.get("valid", False),
        "structure_same": before_stats == after_stats,
        "sha256": hashlib.sha256(full).hexdigest(),
    }


def trailer_brand(data: bytes, parse_end: int, strict_fallback: bool = True) -> str:
    info = validate_trailer_compatible(data, parse_end)
    if info.get("valid"):
        return str(info.get("brand", "NONE"))
    if strict_fallback:
        strict = validate_trailer(data, parse_end)
        if strict.get("valid"):
            return "SKUYYV5"
    return "UNKNOWN"

def stats(root: Proto) -> dict:
    protos=ins=const=0; stack=[root]
    while stack:
        p=stack.pop();protos+=1;ins+=len(p.code);const+=len(p.constants);stack.extend(p.children)
    return {"prototypes":protos,"instructions":ins,"constants":const,"root_children":len(root.children)}


def _normalize_nadeem_line_numbers(root: Proto, src: Path) -> int:
    """Match the source-line numbering observed from NADEEM's CK->luac path.

    For source files beginning with a blank first line, NADEEM emits every non-root
    prototype with linedefined/lastlinedefined one lower than direct luac -s.
    This was verified byte-for-byte against the reference output.
    """
    try:
        starts_blank = src.read_bytes().startswith((b"\n", b"\r\n"))
    except OSError:
        starts_blank = False
    if not starts_blank:
        return 0
    changed = 0
    stack = list(root.children)
    while stack:
        p = stack.pop()
        if p.linedefined > 0:
            p.linedefined -= 1
        if p.lastlinedefined > 0:
            p.lastlinedefined -= 1
        changed += 1
        stack.extend(p.children)
    return changed


def compile_source(src: Path, out: Path, luac: Path):
    with tempfile.TemporaryDirectory(prefix="nlua314_") as td:
        std=Path(td)/"source.luac"
        # -s is essential: observed BG input is a stripped Lua 5.3 chunk.
        cp=subprocess.run([str(luac),"-s","-o",str(std),str(src)],capture_output=True,text=True)
        if cp.returncode != 0:
            raise RuntimeError(f"luac failed ({cp.returncode}):\n{cp.stderr or cp.stdout}")
        raw=std.read_bytes()
    h,root,end=parse_standard_chunk(raw)
    if end != len(raw):
        raise ValueError(f"standard chunk trailing data: {len(raw)-end} bytes")
    linefix_count = _normalize_nadeem_line_numbers(root, src)
    custom_root=transform_standard_to_custom(root)
    w=CustomWriter(main_upvalues=h.main_upvalues);w.proto(custom_root)
    body=bytes(w.buf)
    full=build_trailer(body)
    out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(full)
    return {"standard_size":len(raw),"parse_end":len(body),"file_size":len(full),"linefix_prototypes":linefix_count,**stats(custom_root)}


def custom_to_standard_file(inp: Path, out: Path, source: Path | None = None):
    data=inp.read_bytes();h,root,end=parse_custom_chunk(data)
    if root.children and is_extra_proto(root.children[-1]):
        root.children=root.children[:-1]

    restore_line_offset = False
    if source is not None:
        try:
            raw_src = source.read_bytes()
            restore_line_offset = raw_src.startswith((b"\n", b"\r\n"))
        except OSError:
            restore_line_offset = False

    stdroot=clone_core_to_standard(root, 0, restore_line_offset)
    # Recreate a stripped standard chunk; source names remain whatever custom contained.
    sw=StandardWriter(main_upvalues=h.main_upvalues,size_t_size=8);sw.proto(stdroot)
    out.write_bytes(bytes(sw.buf))
    return {
        "custom_parse_end":end,
        "standard_size":len(sw.buf),
        "restored_line_offset": bool(restore_line_offset),
        **stats(stdroot)
    }


def analyze_file(inp: Path):
    data=inp.read_bytes();h,root,end=parse_custom_chunk(data)
    v=validate_trailer(data,end)
    return {"file_size":len(data),"parse_end":end,"trailer_size":len(data)-end,
            "header":{"int":h.int_size,"size_t":h.size_t_size,"instruction":h.instruction_size,
                      "lua_integer":h.lua_integer_size,"lua_number":h.lua_number_size,"main_upvalues":h.main_upvalues},
            **stats(root),"root_source":None if root.source is None else root.source.decode("utf-8","replace"),
            "has_extra_proto":bool(root.children and is_extra_proto(root.children[-1])),
            "trailer_valid":v}




def _clean_luadec_output(s: str) -> str:
    """Remove stdout decorations/noise added by the bundled decompiler.

    NADEEM's Ag/Af post-processing removes the bundled JAR's own
    "EXTRACTED BY" banner before saving, while keeping the outer
    "DECOMPILED USING" banner added by the Python layer.
    """
    noise = (
        "No pubg_map.properties found. Using standard map.",
        "No pubg_map.properties found.",
        "Using standard map.",
        "-- THIS FILE IS EXTRACTED BY @ OFFICIAL_NADEEM896211 TOOL",
        "-- JOIN OVER TELEGRAM CHANNEL @ASSET_FINDER",
    )
    for phrase in noise:
        s = s.replace(phrase, "")

    # Collapse only the leading blank area created by removing the JAR banner.
    # Keep the decompiled body formatting untouched.
    s = s.lstrip("\n")
    return s


def _syntax_check_lua(source_text: str, luac: Path | None) -> tuple[bool | None, str | None]:
    if luac is None or not luac.exists():
        return None, None
    with tempfile.TemporaryDirectory(prefix="nlua314_syntax_") as td:
        p = Path(td) / "check.lua"
        p.write_text(source_text, encoding="utf-8")
        cp = subprocess.run([str(luac), "-p", str(p)], capture_output=True, text=True)
        return cp.returncode == 0, (cp.stderr or cp.stdout or "").strip() or None


def decompile_file(inp: Path, out: Path, luadec: Path, unluac: Path | None = None,
                   source: Path | None = None, luac: Path | None = None,
                   engine: str = "auto", nadeem_jar: Path | None = None) -> dict:
    """Restore NADEEM custom bytecode to standard Lua 5.3, then decompile it.

    engine:
      auto   -> try luadec first, then unluac if available
      luadec -> force EXES/luadec
      unluac -> force EXES/unluac_pro.jar through java
    """
    engine = engine.lower()
    if engine not in {"auto", "luadec", "unluac", "nadeem"}:
        raise ValueError("engine must be: auto, luadec, unluac, or nadeem")

    errors = []
    out.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="nlua314_dec_") as td:
        std = Path(td) / "restored.luac"
        restore_info = custom_to_standard_file(inp, std, source)

        result_text = None
        used_engine = None

        # Exact NADEEM decompile path recovered from runtime tracing.
        # NADEEM does NOT restore to standard bytecode here. It invokes its
        # Java EXES/LUADEC jar directly on the custom input, then repeats with
        # --nodebug, with the second output replacing the first.
        if engine == "nadeem":
            if nadeem_jar is None:
                nadeem_jar = inp.parent / "EXES" / "LUADEC"
            if not nadeem_jar.exists():
                raise RuntimeError(
                    f"SKUY compatibility decompiler not found: {nadeem_jar}. "
                    "Place the required compatibility JAR at ~/Nlua/EXES/LUADEC."
                )

            expected_jar_sha256 = "5928a957f33af8710966e10e160ef2d75b7fbb2a1fb43751cd43bccaf85d2551"
            try:
                actual_jar_sha256 = hashlib.sha256(nadeem_jar.read_bytes()).hexdigest()
                if actual_jar_sha256 != expected_jar_sha256:
                    print(
                        "[SKUY] warning: LUADEC JAR fingerprint differs from "
                        "the captured reference.",
                        flush=True
                    )
            except OSError:
                actual_jar_sha256 = None

            java = shutil.which("java")
            if not java:
                raise RuntimeError("java not found in PATH")

            # Exact official flow: normal pass, then --nodebug pass.
            # The first pass commonly fails on NADEEM's deliberate fake local
            # debug record (start=end=0x7fffffff). Official behavior continues
            # to the --nodebug pass, whose output replaces pass 1.
            timeout_sec = 20
            print("[SKUY] DECOMPILE pass 1/2...", flush=True)
            pass1_timed_out = False
            try:
                cp1 = subprocess.run(
                    [java, "-jar", str(nadeem_jar), str(inp)],
                    capture_output=True,
                    text=True,
                    timeout=timeout_sec
                )
            except subprocess.TimeoutExpired:
                pass1_timed_out = True
                cp1 = None

            print("[SKUY] DECOMPILE pass 2/2 (--nodebug)...", flush=True)
            pass2_timed_out = False
            try:
                cp2 = subprocess.run(
                    [java, "-jar", str(nadeem_jar), "--nodebug", str(inp)],
                    capture_output=True,
                    text=True,
                    timeout=timeout_sec
                )
            except subprocess.TimeoutExpired:
                pass2_timed_out = True
                cp2 = None

            if pass2_timed_out:
                p1err = "" if cp1 is None else (cp1.stderr or "")
                hint = ""
                if "2147483645" in p1err or "2147483647" in p1err:
                    hint = (
                        " Pass 1 also hit SKUY compatibility debug-local watermark; "
                        "the --nodebug pass then exceeded the official 20s limit."
                    )
                raise RuntimeError(
                    "SKUY compatibility decompiler --nodebug pass timed out after "
                    f"{timeout_sec} seconds.{hint} This is a limitation of the "
                    "bundled decompiler on this complex chunk, not a compile/"
                    "custom-parser mismatch."
                )

            if cp2 is None or cp2.returncode != 0:
                p2err = "" if cp2 is None else (cp2.stderr or "")
                raise RuntimeError(
                    "SKUY compatibility decompiler --nodebug pass failed"
                    + (f" ({cp2.returncode})" if cp2 is not None else "")
                    + ": " + p2err.strip()
                )

            candidate = _clean_luadec_output(cp2.stdout or "")
            if not candidate.strip():
                p1rc = None if cp1 is None else cp1.returncode
                raise RuntimeError(
                    "SKUY compatibility decompiler produced no source. "
                    f"pass1={p1rc}, pass2={cp2.returncode}."
                )

            # Runtime trace shows Ag/Af return the decompiled body beginning
            # with three newlines. Official saved file prepends two banner lines
            # and leaves four blank lines before code.
            banner = (
                "-- FILE INI DIDECOMPILE DENGAN TOOL SKUY_JANCOOOOOOOOOOOOOOOK\n"
                "-- MAU TANYA TANYA @sayadeni131 SKUY_JANCOK\n"
            )
            result_text = banner + "\n\n\n\n" + candidate.lstrip("\n")
            used_engine = "nadeem-java-luadec"

        if engine in {"auto", "luadec"}:
            if luadec.exists():
                # This patched luadec supports -dg ("disable built-in local guessing").
                # Stripped PUBG chunks can make the default guesser explode or segfault,
                # so try safer variants before the default mode.
                luadec_variants = [
                    ("luadec-dg", ["-dg"]),
                    ("luadec-s-dg", ["-s", "-dg"]),
                    ("luadec", []),
                ]
                for variant_name, variant_args in luadec_variants:
                    if result_text is not None:
                        break
                    try:
                        cp = subprocess.run(
                            [str(luadec), *variant_args, str(std)],
                            capture_output=True,
                            text=True
                        )
                        if cp.returncode == 0 and cp.stdout.strip():
                            candidate = _clean_luadec_output(cp.stdout)
                            ok, msg = _syntax_check_lua(candidate, luac)
                            if ok is False:
                                errors.append(
                                    f"{variant_name} produced invalid Lua syntax: "
                                    + (msg or "unknown syntax error")
                                )
                            elif candidate.strip():
                                result_text = candidate
                                used_engine = variant_name
                            else:
                                errors.append(f"{variant_name} produced only banner/noise")
                        else:
                            errors.append(
                                "%s failed (%s): %s"
                                % (variant_name, cp.returncode, (cp.stderr or cp.stdout or "").strip())
                            )
                    except Exception as e:
                        errors.append(f"{variant_name} error: {e}")
            else:
                errors.append(f"luadec not found: {luadec}")

            if engine == "luadec" and result_text is None:
                raise RuntimeError("\n".join(errors))

        if result_text is None and engine in {"auto", "unluac"}:
            if unluac is None:
                errors.append("unluac path not configured")
            elif not unluac.exists():
                errors.append(f"unluac jar not found: {unluac}")
            else:
                java = shutil.which("java")
                if not java:
                    errors.append("java not found in PATH")
                else:
                    try:
                        cp = subprocess.run(
                            [java, "-jar", str(unluac), str(std)],
                            capture_output=True,
                            text=True
                        )
                        if cp.returncode == 0 and cp.stdout.strip():
                            candidate = _clean_luadec_output(cp.stdout)
                            ok, msg = _syntax_check_lua(candidate, luac)
                            if ok is False:
                                errors.append("unluac produced invalid Lua syntax: " + (msg or "unknown syntax error"))
                            elif candidate.strip():
                                result_text = candidate
                                used_engine = "unluac"
                            else:
                                errors.append("unluac produced only banner/noise")
                        else:
                            errors.append(
                                "unluac failed (%s): %s"
                                % (cp.returncode, (cp.stderr or cp.stdout or "").strip())
                            )
                    except Exception as e:
                        errors.append(f"unluac error: {e}")

        if result_text is None:
            raise RuntimeError("Decompiler failed:\n" + "\n".join(errors))

        out.write_text(result_text, encoding="utf-8")

        syntax_ok = None
        syntax_message = None
        if luac is not None and luac.exists():
            try:
                cp = subprocess.run(
                    [str(luac), "-p", str(out)],
                    capture_output=True,
                    text=True
                )
                syntax_ok = (cp.returncode == 0)
                syntax_message = (cp.stderr or cp.stdout or "").strip() or None
            except Exception as e:
                syntax_ok = False
                syntax_message = str(e)

        return {
            "engine": used_engine,
            "input": str(inp),
            "output": str(out),
            "custom_parse_end": restore_info.get("custom_parse_end"),
            "restored_standard_size": restore_info.get("standard_size"),
            "restored_line_offset": restore_info.get("restored_line_offset"),
            "source_size": len(result_text.encode("utf-8")),
            "syntax_ok": syntax_ok,
            "syntax_message": syntax_message,
            "pass1_returncode": (
                locals().get("cp1").returncode
                if locals().get("cp1") is not None else None
            ),
            "pass1_timed_out": locals().get("pass1_timed_out", False),
            "pass2_returncode": (
                locals().get("cp2").returncode
                if locals().get("cp2") is not None else None
            ),
            "pass2_timed_out": locals().get("pass2_timed_out", False),
        }



def rescue_decompile(inp: Path, out_dir: Path, nadeem_jar: Path,
                     unluac: Path | None = None, source: Path | None = None,
                     luac: Path | None = None, timeout_sec: int = 20) -> dict:
    """Best-effort analysis path for chunks that defeat NADEEM's source decompiler.

    Produces:
      - restored_standard.luac
      - disassembly.txt              (exact instruction-level view)
      - raw_unluac.lua               (when the fallback JAR emits text)
      - report.json

    This intentionally does not pretend that a failed high-level decompile is
    equivalent to source code. The disassembly is the authoritative fallback.
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    restored = out_dir / "restored_standard.luac"
    restore_info = custom_to_standard_file(inp, restored, source)

    java = shutil.which("java")
    if not java:
        raise RuntimeError("java not found in PATH")
    if not nadeem_jar.exists():
        raise RuntimeError(f"SKUY compatibility decompiler not found: {nadeem_jar}")

    result = {
        "input": str(inp),
        "output_dir": str(out_dir),
        "restore": restore_info,
        "nadeem_jar": str(nadeem_jar),
        "nodebug": {},
        "disassembly": {},
        "raw_unluac": {},
    }

    # 1) Try the official high-level pass once, but do not hang forever.
    try:
        cp = subprocess.run(
            [java, "-jar", str(nadeem_jar), "--nodebug", str(inp)],
            capture_output=True, text=True, timeout=timeout_sec
        )
        result["nodebug"] = {
            "returncode": cp.returncode,
            "timed_out": False,
            "stderr": (cp.stderr or "")[-4000:],
            "stdout_bytes": len((cp.stdout or "").encode("utf-8", "replace")),
        }
        if cp.returncode == 0 and (cp.stdout or "").strip():
            candidate = _clean_luadec_output(cp.stdout)
            path = out_dir / "nadeem_nodebug.lua"
            path.write_text(candidate, encoding="utf-8")
            ok, msg = _syntax_check_lua(candidate, luac)
            result["nodebug"].update({
                "output": str(path),
                "syntax_ok": ok,
                "syntax_message": msg,
            })
    except subprocess.TimeoutExpired:
        result["nodebug"] = {
            "returncode": None,
            "timed_out": True,
            "timeout_seconds": timeout_sec,
        }

    # 2) Exact disassembly. This bypasses expensive control-flow reconstruction
    # and is normally fast even when --nodebug cannot finish.
    try:
        cp = subprocess.run(
            [java, "-jar", str(nadeem_jar), "--disassemble", str(inp)],
            capture_output=True, text=True, timeout=max(timeout_sec, 30)
        )
        dis = cp.stdout or ""
        dis_path = out_dir / "disassembly.txt"
        if dis:
            dis_path.write_text(dis, encoding="utf-8")
        result["disassembly"] = {
            "returncode": cp.returncode,
            "timed_out": False,
            "output": str(dis_path) if dis else None,
            "bytes": len(dis.encode("utf-8", "replace")),
            "stderr": (cp.stderr or "")[-4000:],
        }
    except subprocess.TimeoutExpired:
        result["disassembly"] = {
            "returncode": None,
            "timed_out": True,
        }

    # 3) Optional second opinion: bundled unluac_pro.jar on restored standard.
    if unluac is not None and unluac.exists():
        try:
            cp = subprocess.run(
                [java, "-jar", str(unluac), str(restored)],
                capture_output=True, text=True, timeout=max(timeout_sec, 30)
            )
            raw = _clean_luadec_output(cp.stdout or "")
            raw_path = out_dir / "raw_unluac.lua"
            if raw.strip():
                raw_path.write_text(raw, encoding="utf-8")
                ok, msg = _syntax_check_lua(raw, luac)
            else:
                ok, msg = None, None
            result["raw_unluac"] = {
                "returncode": cp.returncode,
                "timed_out": False,
                "output": str(raw_path) if raw.strip() else None,
                "bytes": len(raw.encode("utf-8", "replace")),
                "syntax_ok": ok,
                "syntax_message": msg,
                "stderr": (cp.stderr or "")[-4000:],
            }
        except subprocess.TimeoutExpired:
            result["raw_unluac"] = {
                "returncode": None,
                "timed_out": True,
            }

    report = out_dir / "report.json"
    report.write_text(json.dumps(result, indent=2), encoding="utf-8")
    result["report"] = str(report)
    return result



# ---------------------------------------------------------------------------
# Native Nlua instruction decoder / CFG inspector
# ---------------------------------------------------------------------------

LUA53_OPCODE_NAMES = [
    "MOVE","LOADK","LOADKX","LOADBOOL","LOADNIL","GETUPVAL","GETTABUP",
    "GETTABLE","SETTABUP","SETUPVAL","SETTABLE","NEWTABLE","SELF",
    "ADD","SUB","MUL","MOD","POW","DIV","IDIV","BAND","BOR","BXOR","SHL",
    "SHR","UNM","BNOT","NOT","LEN","CONCAT","JMP","EQ","LT","LE","TEST",
    "TESTSET","CALL","TAILCALL","RETURN","FORLOOP","FORPREP","TFORCALL",
    "TFORLOOP","SETLIST","CLOSURE","VARARG","EXTRAARG"
]

LUA53_OPCODE_MODE = {
    "MOVE":"ABC","LOADK":"ABx","LOADKX":"ABx","LOADBOOL":"ABC","LOADNIL":"ABC",
    "GETUPVAL":"ABC","GETTABUP":"ABC","GETTABLE":"ABC","SETTABUP":"ABC",
    "SETUPVAL":"ABC","SETTABLE":"ABC","NEWTABLE":"ABC","SELF":"ABC",
    "ADD":"ABC","SUB":"ABC","MUL":"ABC","MOD":"ABC","POW":"ABC","DIV":"ABC",
    "IDIV":"ABC","BAND":"ABC","BOR":"ABC","BXOR":"ABC","SHL":"ABC","SHR":"ABC",
    "UNM":"ABC","BNOT":"ABC","NOT":"ABC","LEN":"ABC","CONCAT":"ABC",
    "JMP":"AsBx","EQ":"ABC","LT":"ABC","LE":"ABC","TEST":"ABC","TESTSET":"ABC",
    "CALL":"ABC","TAILCALL":"ABC","RETURN":"ABC","FORLOOP":"AsBx",
    "FORPREP":"AsBx","TFORCALL":"ABC","TFORLOOP":"AsBx","SETLIST":"ABC",
    "CLOSURE":"ABx","VARARG":"ABC","EXTRAARG":"Ax",
}

RK_BIT = 1 << 8
MAXARG_sBx = ((1 << 18) - 1) >> 1


def _const_display(c: Constant) -> str:
    if c.tag == 0:
        return "nil"
    if c.tag == 1:
        return "true" if bool(c.value) else "false"
    if c.tag == 3:
        if isinstance(c.value, (bytes, bytearray)) and len(c.value) == 8:
            return repr(struct.unpack("<d", bytes(c.value))[0])
        return repr(c.value)
    if c.tag == 19:
        if isinstance(c.value, (bytes, bytearray)) and len(c.value) == 8:
            return repr(struct.unpack("<q", bytes(c.value))[0])
        return repr(c.value)
    if c.tag in (4, 20):
        if c.value is None:
            return '""'
        if isinstance(c.value, bytes):
            s = c.value.decode("utf-8", "backslashreplace")
        else:
            s = str(c.value)
        if len(s) > 120:
            s = s[:117] + "..."
        return json.dumps(s, ensure_ascii=False)
    return f"<tag={c.tag} value={c.value!r}>"


def _decode_std_word(word: int) -> dict:
    op = word & 0x3F
    A = (word >> 6) & 0xFF
    C = (word >> 14) & 0x1FF
    B = (word >> 23) & 0x1FF
    Bx = (word >> 14) & 0x3FFFF
    sBx = Bx - MAXARG_sBx
    Ax = (word >> 6) & 0x3FFFFFF
    name = LUA53_OPCODE_NAMES[op] if 0 <= op < len(LUA53_OPCODE_NAMES) else f"OP_{op}"
    return {
        "op": op, "name": name, "mode": LUA53_OPCODE_MODE.get(name, "?"),
        "A": A, "B": B, "C": C, "Bx": Bx, "sBx": sBx, "Ax": Ax,
    }


def _rk_text(x: int, constants: list[Constant]) -> str:
    if x & RK_BIT:
        k = x & 0xFF
        if 0 <= k < len(constants):
            return f"K{k}({_const_display(constants[k])})"
        return f"K{k}(?)"
    return f"R{x}"


def _instruction_text(d: dict, constants: list[Constant], pc: int) -> str:
    n = d["name"]
    A, B, C = d["A"], d["B"], d["C"]

    if n == "MOVE":
        return f"R{A} := R{B}"
    if n == "LOADK":
        k = d["Bx"]
        val = _const_display(constants[k]) if 0 <= k < len(constants) else "?"
        return f"R{A} := K{k}({val})"
    if n == "LOADKX":
        return f"R{A} := K[EXTRAARG(next)]"
    if n == "LOADBOOL":
        return f"R{A} := {'true' if B else 'false'}" + ("; skip next" if C else "")
    if n == "LOADNIL":
        return f"R{A}..R{A+B} := nil"
    if n == "GETUPVAL":
        return f"R{A} := UP{B}"
    if n == "GETTABUP":
        return f"R{A} := UP{B}[{_rk_text(C, constants)}]"
    if n == "GETTABLE":
        return f"R{A} := R{B}[{_rk_text(C, constants)}]"
    if n == "SETTABUP":
        return f"UP{A}[{_rk_text(B, constants)}] := {_rk_text(C, constants)}"
    if n == "SETUPVAL":
        return f"UP{B} := R{A}"
    if n == "SETTABLE":
        return f"R{A}[{_rk_text(B, constants)}] := {_rk_text(C, constants)}"
    if n == "NEWTABLE":
        return f"R{A} := {{}}  # array_hint={B}, hash_hint={C}"
    if n == "SELF":
        return f"R{A+1} := R{B}; R{A} := R{B}[{_rk_text(C, constants)}]"
    if n in {"ADD","SUB","MUL","MOD","POW","DIV","IDIV","BAND","BOR","BXOR","SHL","SHR"}:
        sym = {
            "ADD":"+","SUB":"-","MUL":"*","MOD":"%","POW":"^","DIV":"/","IDIV":"//",
            "BAND":"&","BOR":"|","BXOR":"~","SHL":"<<","SHR":">>"
        }[n]
        return f"R{A} := {_rk_text(B, constants)} {sym} {_rk_text(C, constants)}"
    if n in {"UNM","BNOT","NOT","LEN"}:
        sym = {"UNM":"-","BNOT":"~","NOT":"not ","LEN":"#"}[n]
        return f"R{A} := {sym}R{B}"
    if n == "CONCAT":
        return f"R{A} := concat(R{B}..R{C})"
    if n in {"JMP","FORLOOP","FORPREP","TFORLOOP"}:
        target = pc + 1 + d["sBx"]
        return f"{n} target=PC{target} sBx={d['sBx']} A={A}"
    if n in {"EQ","LT","LE"}:
        sym = {"EQ":"==","LT":"<","LE":"<="}[n]
        return f"if (({_rk_text(B, constants)} {sym} {_rk_text(C, constants)}) ~= {bool(A)}) then skip next"
    if n == "TEST":
        return f"if truth(R{A}) ~= {bool(C)} then skip next"
    if n == "TESTSET":
        return f"if truth(R{B}) == {bool(C)} then R{A}:=R{B} else skip next"
    if n == "CALL":
        return f"CALL R{A} args={B} results={C}"
    if n == "TAILCALL":
        return f"TAILCALL R{A} args={B}"
    if n == "RETURN":
        return f"RETURN from R{A} count={B}"
    if n == "TFORCALL":
        return f"TFORCALL base=R{A} results={C}"
    if n == "SETLIST":
        return f"SETLIST table=R{A} count={B} block={C}"
    if n == "CLOSURE":
        return f"R{A} := CLOSURE(proto={d['Bx']})"
    if n == "VARARG":
        return f"VARARG -> R{A}, count={B}"
    if n == "EXTRAARG":
        return f"EXTRAARG Ax={d['Ax']}"
    return f"{n} A={A} B={B} C={C} Bx={d['Bx']} sBx={d['sBx']} Ax={d['Ax']}"


def _successors(decoded: list[dict], pc: int) -> list[int]:
    """Conservative control-flow successors for Lua 5.3 instruction PCs."""
    d = decoded[pc]
    n = d["name"]
    size = len(decoded)
    nxt = pc + 1

    if n in {"RETURN", "TAILCALL"}:
        return []
    if n == "JMP":
        t = pc + 1 + d["sBx"]
        return [t] if 0 <= t < size else []
    if n in {"FORLOOP", "TFORLOOP"}:
        t = pc + 1 + d["sBx"]
        out = []
        if 0 <= t < size:
            out.append(t)
        if nxt < size:
            out.append(nxt)
        return list(dict.fromkeys(out))
    if n == "FORPREP":
        t = pc + 1 + d["sBx"]
        return [t] if 0 <= t < size else []
    if n in {"EQ", "LT", "LE", "TEST", "TESTSET"}:
        out = []
        if nxt < size:
            out.append(nxt)
        if pc + 2 < size:
            out.append(pc + 2)
        return out
    if n == "LOADBOOL" and d["C"] != 0:
        return [pc + 2] if pc + 2 < size else []
    if nxt < size:
        return [nxt]
    return []


def _basic_blocks(decoded: list[dict]) -> list[dict]:
    if not decoded:
        return []
    leaders = {0}
    succ_map = {}
    for pc in range(len(decoded)):
        succ = _successors(decoded, pc)
        succ_map[pc] = succ
        for s in succ:
            if 0 <= s < len(decoded):
                leaders.add(s)
        # Instruction after a branch/terminator begins a block if present.
        if decoded[pc]["name"] in {
            "JMP","FORLOOP","FORPREP","TFORLOOP","EQ","LT","LE","TEST","TESTSET",
            "RETURN","TAILCALL"
        } and pc + 1 < len(decoded):
            leaders.add(pc + 1)

    sorted_leaders = sorted(leaders)
    blocks = []
    pc_to_block = {}
    for i, start in enumerate(sorted_leaders):
        end = (sorted_leaders[i+1] - 1) if i + 1 < len(sorted_leaders) else len(decoded) - 1
        bid = len(blocks)
        for pc in range(start, end + 1):
            pc_to_block[pc] = bid
        blocks.append({"id": bid, "start": start, "end": end, "successors": []})

    for b in blocks:
        last = b["end"]
        bids = []
        for s in succ_map.get(last, []):
            if s in pc_to_block:
                bids.append(pc_to_block[s])
        b["successors"] = list(dict.fromkeys(bids))
    return blocks


def native_disassemble(inp: Path, out_txt: Path, cfg_json: Path | None = None,
                       include_extra_proto: bool = False) -> dict:
    """Decode a NADEEM custom chunk natively, without Java/unluac control-flow."""
    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    if (not include_extra_proto) and root.children and is_extra_proto(root.children[-1]):
        root.children = root.children[:-1]

    lines = []
    cfg_doc = {
        "input": str(inp),
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "prototypes": [],
    }

    proto_count = 0
    ins_count = 0

    def walk(p: Proto, path: str, depth: int):
        nonlocal proto_count, ins_count
        proto_count += 1

        std_words = [remap_word(w, forward=False) for w in p.code]
        decoded = [_decode_std_word(w) for w in std_words]
        blocks = _basic_blocks(decoded)
        ins_count += len(decoded)

        source = None if p.source is None else p.source.decode("utf-8", "replace")
        indent = "  " * depth
        lines.append(
            f"{indent}=== PROTO {path} === source={source!r} "
            f"lines={p.linedefined}:{p.lastlinedefined} "
            f"params={p.numparams} vararg={p.is_vararg} stack={p.maxstacksize} "
            f"code={len(p.code)} const={len(p.constants)} upvalues={len(p.upvalues)} "
            f"children={len(p.children)}"
        )

        if p.constants:
            lines.append(f"{indent}-- CONSTANTS")
            for i, c in enumerate(p.constants):
                lines.append(f"{indent}K{i:04d} = {_const_display(c)}  [tag={c.tag}]")

        lines.append(f"{indent}-- CODE")
        for pc, (raw_custom, std_word, d) in enumerate(zip(p.code, std_words, decoded)):
            txt = _instruction_text(d, p.constants, pc)
            lines.append(
                f"{indent}PC{pc:04d}  custom=0x{raw_custom:08X} std=0x{std_word:08X} "
                f"{d['name']:<9} {txt}"
            )

        lines.append(f"{indent}-- BASIC BLOCKS")
        for b in blocks:
            lines.append(
                f"{indent}B{b['id']:03d}: PC{b['start']}..PC{b['end']} "
                f"-> {','.join('B'+str(x) for x in b['successors']) or '-'}"
            )
        lines.append("")

        cfg_doc["prototypes"].append({
            "path": path,
            "source": source,
            "linedefined": p.linedefined,
            "lastlinedefined": p.lastlinedefined,
            "numparams": p.numparams,
            "is_vararg": p.is_vararg,
            "maxstacksize": p.maxstacksize,
            "instruction_count": len(decoded),
            "constant_count": len(p.constants),
            "upvalue_count": len(p.upvalues),
            "child_count": len(p.children),
            "blocks": blocks,
            "instructions": [
                {
                    "pc": pc,
                    "custom_word": p.code[pc],
                    "standard_word": std_words[pc],
                    **decoded[pc],
                    "text": _instruction_text(decoded[pc], p.constants, pc),
                    "successors": _successors(decoded, pc),
                }
                for pc in range(len(decoded))
            ],
        })

        for i, child in enumerate(p.children):
            walk(child, f"{path}.{i}", depth + 1)

    walk(root, "root", 0)

    out_txt.parent.mkdir(parents=True, exist_ok=True)
    out_txt.write_text("\n".join(lines), encoding="utf-8")

    if cfg_json is not None:
        cfg_json.parent.mkdir(parents=True, exist_ok=True)
        cfg_json.write_text(json.dumps(cfg_doc, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "input": str(inp),
        "output": str(out_txt),
        "cfg_json": str(cfg_json) if cfg_json is not None else None,
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "prototypes": proto_count,
        "instructions": ins_count,
        "include_extra_proto": include_extra_proto,
    }



# ---------------------------------------------------------------------------
# Native pseudo-Lua reconstruction
# ---------------------------------------------------------------------------

_BIN_SYM = {
    "ADD":"+","SUB":"-","MUL":"*","MOD":"%","POW":"^","DIV":"/","IDIV":"//",
    "BAND":"&","BOR":"|","BXOR":"~","SHL":"<<","SHR":">>",
}

_UN_SYM = {"UNM":"-","BNOT":"~","NOT":"not ","LEN":"#"}


def _expr_rk(x: int, consts: list[Constant], regs: dict[int, str]) -> str:
    if x & RK_BIT:
        k = x & 0xFF
        return _const_display(consts[k]) if 0 <= k < len(consts) else f"K{k}"
    return regs.get(x, f"R{x}")


def _safe_ident(name: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name))


def _index_expr(base: str, key: str) -> str:
    if key.startswith('"') and key.endswith('"'):
        try:
            raw = json.loads(key)
            if isinstance(raw, str) and _safe_ident(raw):
                return f"{base}.{raw}"
        except Exception:
            pass
    return f"{base}[{key}]"


def _function_stub_name(path: str) -> str:
    return "fn_" + path.replace(".", "_").replace("root", "root")


def _reconstruct_proto_pseudolua(p: Proto, path: str, child_names: dict[int, str]) -> list[str]:
    std_words = [remap_word(w, forward=False) for w in p.code]
    decoded = [_decode_std_word(w) for w in std_words]

    regs: dict[int, str] = {}
    lines: list[str] = []
    labels = set()

    # Collect jump targets first.
    for pc, d in enumerate(decoded):
        if d["name"] in {"JMP","FORLOOP","FORPREP","TFORLOOP"}:
            t = pc + 1 + d["sBx"]
            if 0 <= t < len(decoded):
                labels.add(t)
        if d["name"] in {"EQ","LT","LE","TEST","TESTSET"} and pc + 2 < len(decoded):
            labels.add(pc + 2)

    def emit(s=""):
        lines.append(s)

    for pc, d in enumerate(decoded):
        if pc in labels:
            emit(f"::PC_{pc}::")

        n = d["name"]
        A, B, C = d["A"], d["B"], d["C"]

        if n == "MOVE":
            regs[A] = regs.get(B, f"R{B}")
        elif n == "LOADK":
            k = d["Bx"]
            regs[A] = _const_display(p.constants[k]) if 0 <= k < len(p.constants) else f"K{k}"
        elif n == "LOADKX":
            regs[A] = f"KX_PC{pc}"
        elif n == "LOADBOOL":
            regs[A] = "true" if B else "false"
            emit(f"R{A} = {regs[A]}")
            if C:
                emit("-- skip next")
        elif n == "LOADNIL":
            for r in range(A, A + B + 1):
                regs[r] = "nil"
                emit(f"R{r} = nil")
        elif n == "GETUPVAL":
            regs[A] = f"UP{B}"
        elif n == "GETTABUP":
            key = _expr_rk(C, p.constants, regs)
            regs[A] = _index_expr(f"UP{B}", key)
        elif n == "GETTABLE":
            key = _expr_rk(C, p.constants, regs)
            regs[A] = _index_expr(regs.get(B, f"R{B}"), key)
        elif n == "SETTABUP":
            key = _expr_rk(B, p.constants, regs)
            val = _expr_rk(C, p.constants, regs)
            emit(f"{_index_expr(f'UP{A}', key)} = {val}")
        elif n == "SETUPVAL":
            emit(f"UP{B} = {regs.get(A, f'R{A}')}")
        elif n == "SETTABLE":
            key = _expr_rk(B, p.constants, regs)
            val = _expr_rk(C, p.constants, regs)
            emit(f"{_index_expr(regs.get(A, f'R{A}'), key)} = {val}")
        elif n == "NEWTABLE":
            regs[A] = "{}"
            emit(f"R{A} = {{}}")
        elif n == "SELF":
            base = regs.get(B, f"R{B}")
            key = _expr_rk(C, p.constants, regs)
            regs[A+1] = base
            regs[A] = _index_expr(base, key)
        elif n in _BIN_SYM:
            lhs = _expr_rk(B, p.constants, regs)
            rhs = _expr_rk(C, p.constants, regs)
            regs[A] = f"({lhs} {_BIN_SYM[n]} {rhs})"
        elif n in _UN_SYM:
            src = regs.get(B, f"R{B}")
            regs[A] = f"({_UN_SYM[n]}{src})"
        elif n == "CONCAT":
            parts = [regs.get(r, f"R{r}") for r in range(B, C + 1)]
            regs[A] = "(" + " .. ".join(parts) + ")"
        elif n == "JMP":
            emit(f"goto PC_{pc + 1 + d['sBx']}")
        elif n in {"EQ","LT","LE"}:
            lhs = _expr_rk(B, p.constants, regs)
            rhs = _expr_rk(C, p.constants, regs)
            sym = {"EQ":"==","LT":"<","LE":"<="}[n]
            cond = f"({lhs} {sym} {rhs})"
            if A:
                cond = f"not {cond}"
            emit(f"if {cond} then goto PC_{pc+2} end")
        elif n == "TEST":
            cond = regs.get(A, f"R{A}")
            if C == 0:
                cond = f"not ({cond})"
            emit(f"if {cond} then goto PC_{pc+2} end")
        elif n == "TESTSET":
            cond = regs.get(B, f"R{B}")
            if C == 0:
                cond = f"not ({cond})"
            emit(f"if {cond} then R{A} = {regs.get(B, f'R{B}')} else goto PC_{pc+2} end")
        elif n == "CALL":
            fn = regs.get(A, f"R{A}")
            if B == 0:
                args = "..."
            else:
                args = ", ".join(regs.get(r, f"R{r}") for r in range(A+1, A+B))
            call = f"{fn}({args})"
            if C == 1:
                emit(call)
            elif C == 0:
                emit(f"R{A}, ... = {call}")
                regs[A] = f"({call})"
            else:
                outs = [f"R{r}" for r in range(A, A + C - 1)]
                emit(f"{', '.join(outs)} = {call}")
                regs[A] = f"({call})"
        elif n == "TAILCALL":
            fn = regs.get(A, f"R{A}")
            args = "..." if B == 0 else ", ".join(regs.get(r, f"R{r}") for r in range(A+1, A+B))
            emit(f"return {fn}({args})")
        elif n == "RETURN":
            if B == 1:
                emit("return")
            elif B == 0:
                emit(f"return R{A}, ...")
            else:
                vals = [regs.get(r, f"R{r}") for r in range(A, A+B-1)]
                emit("return " + ", ".join(vals))
        elif n == "FORPREP":
            emit(f"-- numeric for setup R{A}..R{A+3}")
            emit(f"goto PC_{pc + 1 + d['sBx']}")
        elif n == "FORLOOP":
            emit(f"-- numeric for loop R{A}..R{A+3}")
            emit(f"goto PC_{pc + 1 + d['sBx']}")
        elif n == "TFORCALL":
            emit(f"-- generic for call base R{A} results={C}")
        elif n == "TFORLOOP":
            emit(f"-- generic for loop")
            emit(f"goto PC_{pc + 1 + d['sBx']}")
        elif n == "SETLIST":
            emit(f"-- SETLIST R{A}, count={B}, block={C}")
        elif n == "CLOSURE":
            child = d["Bx"]
            fn = child_names.get(child, f"fn_child_{child}")
            regs[A] = fn
            emit(f"R{A} = {fn}")
        elif n == "VARARG":
            if B == 0:
                emit(f"R{A}, ... = ...")
                regs[A] = "..."
            else:
                for r in range(A, A+B-1):
                    regs[r] = "..."
                    emit(f"R{r} = ...")
        elif n == "EXTRAARG":
            emit(f"-- EXTRAARG {d['Ax']}")
        else:
            emit(f"-- {n} A={A} B={B} C={C}")

    return lines


def native_pseudolua(inp: Path, out_lua: Path, include_extra_proto: bool = False) -> dict:
    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    if (not include_extra_proto) and root.children and is_extra_proto(root.children[-1]):
        root.children = root.children[:-1]

    chunks: list[str] = []
    proto_count = 0
    ins_count = 0

    def walk(p: Proto, path: str, depth: int):
        nonlocal proto_count, ins_count
        proto_count += 1
        ins_count += len(p.code)

        child_names = {i: _function_stub_name(f"{path}.{i}") for i in range(len(p.children))}
        fn_name = _function_stub_name(path)

        chunks.append(f"-- PROTO {path} lines={p.linedefined}:{p.lastlinedefined} code={len(p.code)}")
        chunks.append(f"local function {fn_name}(...)")
        body = _reconstruct_proto_pseudolua(p, path, child_names)
        if body:
            chunks.extend("    " + line if line else "" for line in body)
        else:
            chunks.append("    -- empty prototype")
        chunks.append("end")
        chunks.append("")

        for i, child in enumerate(p.children):
            walk(child, f"{path}.{i}", depth + 1)

    walk(root, "root", 0)

    out_lua.parent.mkdir(parents=True, exist_ok=True)
    out_lua.write_text("\n".join(chunks), encoding="utf-8")

    return {
        "input": str(inp),
        "output": str(out_lua),
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "prototypes": proto_count,
        "instructions": ins_count,
        "include_extra_proto": include_extra_proto,
        "note": "Pseudo-Lua reconstruction; intended for analysis/edit targeting, not yet guaranteed round-trip compilable.",
    }



# ---------------------------------------------------------------------------
# Constant scanner / patcher
# ---------------------------------------------------------------------------

def _walk_protos(root: Proto):
    stack = [("root", root)]
    while stack:
        path, p = stack.pop()
        yield path, p
        for i in range(len(p.children) - 1, -1, -1):
            stack.append((f"{path}.{i}", p.children[i]))


def _const_python_value(c: Constant):
    if c.tag == 0:
        return None
    if c.tag == 1:
        return bool(c.value)
    if c.tag == 3:
        if isinstance(c.value, (bytes, bytearray)) and len(c.value) == 8:
            return struct.unpack("<d", bytes(c.value))[0]
        return float(c.value)
    if c.tag == 19:
        if isinstance(c.value, (bytes, bytearray)) and len(c.value) == 8:
            return struct.unpack("<q", bytes(c.value))[0]
        return int(c.value)
    if c.tag in (4, 20):
        raw = c.value or b""
        if isinstance(raw, bytes):
            return raw.decode("utf-8", "replace")
        return str(raw)
    return c.value


def scan_constants(inp: Path, query: str | None = None,
                   include_extra_proto: bool = False) -> dict:
    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    if (not include_extra_proto) and root.children and is_extra_proto(root.children[-1]):
        root.children = root.children[:-1]

    q = query.casefold() if query else None
    rows = []

    for path, p in _walk_protos(root):
        for i, c in enumerate(p.constants):
            value = _const_python_value(c)
            display = _const_display(c)

            if q is not None:
                hay = f"{path} {i} {c.tag} {display} {value}".casefold()
                if q not in hay:
                    continue

            rows.append({
                "proto": path,
                "index": i,
                "tag": c.tag,
                "type": {
                    0: "nil",
                    1: "boolean",
                    3: "number",
                    4: "string",
                    19: "integer",
                    20: "long_string",
                }.get(c.tag, f"tag_{c.tag}"),
                "value": value,
                "display": display,
            })

    return {
        "input": str(inp),
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "query": query,
        "matches": len(rows),
        "constants": rows,
    }


def _get_proto_by_path(root: Proto, path: str) -> Proto:
    if path == "root":
        return root
    parts = path.split(".")
    if not parts or parts[0] != "root":
        raise ValueError("prototype path must be root or root.N[.N...]")
    p = root
    for part in parts[1:]:
        try:
            idx = int(part)
        except ValueError as e:
            raise ValueError(f"invalid prototype path component: {part!r}") from e
        if idx < 0 or idx >= len(p.children):
            raise IndexError(
                f"prototype path {path!r} does not exist; "
                f"child index {idx} outside 0..{len(p.children)-1}"
            )
        p = p.children[idx]
    return p


def _parse_patch_value(type_name: str, value_text: str | None,
                       old: Constant | None = None) -> Constant:
    t = type_name.lower()

    if t == "auto":
        if old is None:
            raise ValueError("--type auto requires an existing constant")
        tag = old.tag
        if tag in (4, 20):
            t = "string" if tag == 4 else "long_string"
        elif tag == 19:
            t = "integer"
        elif tag == 3:
            t = "number"
        elif tag == 1:
            t = "boolean"
        elif tag == 0:
            t = "nil"
        else:
            raise ValueError(f"unsupported old constant tag {tag}")

    if t == "nil":
        return Constant(0, None)

    if value_text is None:
        raise ValueError(f"--value is required for type {t}")

    if t == "boolean":
        v = value_text.strip().lower()
        if v in {"1", "true", "yes", "on"}:
            return Constant(1, True)
        if v in {"0", "false", "no", "off"}:
            return Constant(1, False)
        raise ValueError("boolean value must be true/false, 1/0, yes/no, or on/off")

    if t == "integer":
        value = int(value_text, 0)
        if not -(1 << 63) <= value < (1 << 63):
            raise ValueError("integer outside signed 64-bit range")
        return Constant(19, struct.pack("<q", value))

    if t == "number":
        value = float(value_text)
        return Constant(3, struct.pack("<d", value))

    if t in {"string", "long_string"}:
        tag = 4 if t == "string" else 20
        return Constant(tag, value_text.encode("utf-8"))

    raise ValueError(
        "type must be auto, string, long_string, integer, number, boolean, or nil"
    )


def patch_constant(inp: Path, out: Path, proto_path: str, index: int,
                   value_text: str | None, type_name: str = "auto",
                   expect: str | None = None) -> dict:
    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    p = _get_proto_by_path(root, proto_path)
    if index < 0 or index >= len(p.constants):
        raise IndexError(
            f"constant index {index} outside 0..{len(p.constants)-1} "
            f"for prototype {proto_path}"
        )

    old = p.constants[index]
    old_display = _const_display(old)
    old_value = _const_python_value(old)

    if expect is not None:
        exp = expect
        if exp != str(old_value) and exp != old_display:
            raise ValueError(
                f"--expect mismatch: constant is {old_display} / {old_value!r}, "
                f"not {expect!r}"
            )

    new = _parse_patch_value(type_name, value_text, old)
    p.constants[index] = new

    w = CustomWriter(main_upvalues=h.main_upvalues)
    w.proto(root)
    body = bytes(w.buf)
    full = build_trailer(body)

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(full)

    # Verify that our freshly written chunk reparses and has a valid trailer.
    h2, root2, end2 = parse_custom_chunk(full)
    trailer = validate_trailer(full, end2)
    if not trailer.get("valid"):
        raise RuntimeError(f"patched output trailer validation failed: {trailer}")

    p2 = _get_proto_by_path(root2, proto_path)
    new2 = p2.constants[index]

    return {
        "input": str(inp),
        "output": str(out),
        "proto": proto_path,
        "index": index,
        "old": {
            "tag": old.tag,
            "value": old_value,
            "display": old_display,
        },
        "new": {
            "tag": new2.tag,
            "value": _const_python_value(new2),
            "display": _const_display(new2),
        },
        "old_parse_end": parse_end,
        "new_parse_end": end2,
        "old_file_size": len(data),
        "new_file_size": len(full),
        "trailer_valid": trailer.get("valid", False),
        "sha256": hashlib.sha256(full).hexdigest(),
    }



# ---------------------------------------------------------------------------
# Constant reference analysis / batch patch plans
# ---------------------------------------------------------------------------

def _constant_refs_for_proto(p: Proto) -> dict[int, list[dict]]:
    """Find instruction references to constants in one prototype."""
    refs: dict[int, list[dict]] = {i: [] for i in range(len(p.constants))}
    std_words = [remap_word(w, forward=False) for w in p.code]
    decoded = [_decode_std_word(w) for w in std_words]

    def add(k: int, pc: int, operand: str, d: dict):
        if 0 <= k < len(p.constants):
            refs[k].append({
                "pc": pc,
                "op": d["name"],
                "operand": operand,
                "text": _instruction_text(d, p.constants, pc),
            })

    for pc, d in enumerate(decoded):
        n = d["name"]

        if n == "LOADK":
            add(d["Bx"], pc, "Bx", d)
            continue

        if n == "LOADKX":
            # LOADKX gets its constant from the following EXTRAARG.
            if pc + 1 < len(decoded) and decoded[pc + 1]["name"] == "EXTRAARG":
                add(decoded[pc + 1]["Ax"], pc, "Ax(next EXTRAARG)", d)
            continue

        # RK operands in Lua 5.3.
        rk_b_ops = {
            "SETTABUP","SETTABLE",
            "ADD","SUB","MUL","MOD","POW","DIV","IDIV",
            "BAND","BOR","BXOR","SHL","SHR",
            "EQ","LT","LE",
        }
        rk_c_ops = {
            "GETTABUP","GETTABLE","SETTABUP","SETTABLE","SELF",
            "ADD","SUB","MUL","MOD","POW","DIV","IDIV",
            "BAND","BOR","BXOR","SHL","SHR",
            "EQ","LT","LE",
        }

        if n in rk_b_ops and (d["B"] & RK_BIT):
            add(d["B"] & 0xFF, pc, "B(RK)", d)
        if n in rk_c_ops and (d["C"] & RK_BIT):
            add(d["C"] & 0xFF, pc, "C(RK)", d)

    return refs


def inspect_constants(inp: Path, query: str | None = None,
                      include_unreferenced: bool = False,
                      include_extra_proto: bool = False) -> dict:
    """Scan constants and show exactly where bytecode instructions use them."""
    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    if (not include_extra_proto) and root.children and is_extra_proto(root.children[-1]):
        root.children = root.children[:-1]

    q = query.casefold() if query else None
    rows = []

    for path, p in _walk_protos(root):
        refs = _constant_refs_for_proto(p)
        for i, c in enumerate(p.constants):
            value = _const_python_value(c)
            display = _const_display(c)
            cref = refs.get(i, [])

            if not include_unreferenced and not cref:
                continue

            if q is not None:
                hay = (
                    f"{path} {i} {c.tag} {display} {value} "
                    + " ".join(f"{r['pc']} {r['op']} {r['text']}" for r in cref)
                ).casefold()
                if q not in hay:
                    continue

            rows.append({
                "proto": path,
                "index": i,
                "tag": c.tag,
                "type": {
                    0: "nil",
                    1: "boolean",
                    3: "number",
                    4: "string",
                    19: "integer",
                    20: "long_string",
                }.get(c.tag, f"tag_{c.tag}"),
                "value": value,
                "display": display,
                "reference_count": len(cref),
                "references": cref,
            })

    return {
        "input": str(inp),
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "query": query,
        "matches": len(rows),
        "constants": rows,
    }


def apply_patch_plan(inp: Path, out: Path, plan_path: Path) -> dict:
    """Apply multiple constant edits atomically from a JSON patch plan.

    Plan format:
    {
      "patches": [
        {
          "proto": "root.1.2",
          "index": 5,
          "type": "auto",
          "value": "20260930",
          "expect": "20260830"
        }
      ]
    }
    """
    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    patches = plan.get("patches")
    if not isinstance(patches, list) or not patches:
        raise ValueError("patch plan must contain a non-empty 'patches' list")

    prepared = []

    # Validate every patch first. Nothing is written until all checks pass.
    for n, item in enumerate(patches):
        if not isinstance(item, dict):
            raise ValueError(f"patch #{n} must be an object")

        proto_path = str(item.get("proto", ""))
        index = int(item["index"])
        type_name = str(item.get("type", "auto"))
        value_text = item.get("value")
        if value_text is not None:
            value_text = str(value_text)
        expect = item.get("expect")
        if expect is not None:
            expect = str(expect)

        p = _get_proto_by_path(root, proto_path)
        if index < 0 or index >= len(p.constants):
            raise IndexError(
                f"patch #{n}: constant index {index} outside "
                f"0..{len(p.constants)-1} for {proto_path}"
            )

        old = p.constants[index]
        old_display = _const_display(old)
        old_value = _const_python_value(old)

        if expect is not None and expect not in {str(old_value), old_display}:
            raise ValueError(
                f"patch #{n}: --expect mismatch at {proto_path} K{index}: "
                f"actual={old_display} / {old_value!r}, expected={expect!r}"
            )

        new = _parse_patch_value(type_name, value_text, old)

        prepared.append({
            "n": n,
            "proto": proto_path,
            "index": index,
            "old": old,
            "old_value": old_value,
            "old_display": old_display,
            "new": new,
        })

    # Apply only after all entries validated.
    for item in prepared:
        p = _get_proto_by_path(root, item["proto"])
        p.constants[item["index"]] = item["new"]

    w = CustomWriter(main_upvalues=h.main_upvalues)
    w.proto(root)
    body = bytes(w.buf)
    full = build_trailer(body)

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(full)

    # Reparse and verify trailer.
    h2, root2, end2 = parse_custom_chunk(full)
    trailer = validate_trailer(full, end2)
    if not trailer.get("valid"):
        raise RuntimeError(f"patched output trailer validation failed: {trailer}")

    changes = []
    for item in prepared:
        p2 = _get_proto_by_path(root2, item["proto"])
        new2 = p2.constants[item["index"]]
        changes.append({
            "proto": item["proto"],
            "index": item["index"],
            "old": {
                "tag": item["old"].tag,
                "value": item["old_value"],
                "display": item["old_display"],
            },
            "new": {
                "tag": new2.tag,
                "value": _const_python_value(new2),
                "display": _const_display(new2),
            },
        })

    return {
        "input": str(inp),
        "output": str(out),
        "plan": str(plan_path),
        "patch_count": len(changes),
        "changes": changes,
        "old_parse_end": parse_end,
        "new_parse_end": end2,
        "old_file_size": len(data),
        "new_file_size": len(full),
        "trailer_valid": trailer.get("valid", False),
        "sha256": hashlib.sha256(full).hexdigest(),
    }


def make_patch_plan(inp: Path, out_plan: Path, query: str,
                    include_extra_proto: bool = False) -> dict:
    """Create a reviewable JSON plan template from matching constants."""
    scan = inspect_constants(
        inp,
        query=query,
        include_unreferenced=True,
        include_extra_proto=include_extra_proto,
    )

    patches = []
    for row in scan["constants"]:
        patches.append({
            "proto": row["proto"],
            "index": row["index"],
            "type": "auto",
            "value": str(row["value"]) if row["value"] is not None else "",
            "expect": str(row["value"]) if row["value"] is not None else row["display"],
            "reference_count": row["reference_count"],
            "references": row["references"],
        })

    doc = {
        "input": str(inp),
        "query": query,
        "instructions": (
            "Review this file. Change only each patch's 'value' field. "
            "Delete patch entries you do not want to modify. Then run "
            "apply-patch-plan."
        ),
        "patches": patches,
    }

    out_plan.parent.mkdir(parents=True, exist_ok=True)
    out_plan.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "input": str(inp),
        "output_plan": str(out_plan),
        "query": query,
        "matches": len(patches),
    }



# ---------------------------------------------------------------------------
# Constant semantic-context analysis
# ---------------------------------------------------------------------------

def _classify_constant_usage(refs: list[dict]) -> list[str]:
    kinds = set()
    for r in refs:
        op = r.get("op")
        operand = r.get("operand")

        if op in {"EQ", "LT", "LE"}:
            kinds.add("comparison")
        if op in {"SETTABLE", "SETTABUP"}:
            if operand == "B(RK)":
                kinds.add("table_key")
            elif operand == "C(RK)":
                kinds.add("table_value")
            else:
                kinds.add("table_write")
        if op in {"GETTABLE", "GETTABUP", "SELF"}:
            kinds.add("table_lookup")
        if op in {
            "ADD","SUB","MUL","MOD","POW","DIV","IDIV",
            "BAND","BOR","BXOR","SHL","SHR"
        }:
            kinds.add("arithmetic")
        if op in {"LOADK", "LOADKX"}:
            kinds.add("load")
    return sorted(kinds)


def _guess_role(row: dict, context_entries: list[dict]) -> list[dict]:
    """Conservative heuristics only; every guess includes a reason."""
    guesses = []
    value = row.get("value")
    refs = row.get("references", [])
    usage = set(_classify_constant_usage(refs))

    def add(role: str, confidence: str, reason: str):
        guesses.append({
            "role": role,
            "confidence": confidence,
            "reason": reason,
        })

    # Date-like integer/number heuristic.
    if isinstance(value, int):
        s = str(abs(value))
        if len(s) == 8 and s[:2] in {"19", "20"}:
            try:
                y, m, d = int(s[:4]), int(s[4:6]), int(s[6:8])
                if 1 <= m <= 12 and 1 <= d <= 31:
                    if "comparison" in usage:
                        add(
                            "date_or_expiration_threshold",
                            "medium",
                            f"8-digit calendar-like value {y:04d}-{m:02d}-{d:02d} is used by a comparison instruction."
                        )
                    else:
                        add(
                            "date_like_constant",
                            "low",
                            f"8-digit calendar-like value {y:04d}-{m:02d}-{d:02d}."
                        )
            except Exception:
                pass

    # Unix timestamp-ish range.
    if isinstance(value, int) and 946684800 <= value <= 4102444800:
        if "comparison" in usage:
            add(
                "timestamp_threshold",
                "medium",
                "Value is in a plausible Unix timestamp range and is compared in bytecode."
            )
        else:
            add(
                "timestamp_like_constant",
                "low",
                "Value is in a plausible Unix timestamp range."
            )

    if isinstance(value, str):
        low = value.casefold()
        if any(k in low for k in ("expire", "expired", "expiration", "kadaluarsa")):
            add(
                "expiration_text_or_key",
                "high",
                "String itself contains expiration-related wording."
            )
        if any(k in low for k in ("welcome", "watermark", "title", "label", "menu", "text")):
            if "table_key" in usage or "table_value" in usage or "table_lookup" in usage:
                add(
                    "ui_or_cosmetic_text",
                    "medium",
                    "String contains UI/cosmetic wording and participates in table access/write."
                )
            else:
                add(
                    "ui_or_cosmetic_text",
                    "low",
                    "String contains UI/cosmetic wording."
                )

    if "table_key" in usage and isinstance(value, str):
        add(
            "table_field_name",
            "high",
            "Constant is used as an RK table key in SETTABLE/SETTABUP."
        )
    if "table_lookup" in usage and isinstance(value, str):
        add(
            "table_lookup_key",
            "high",
            "Constant is used as a table lookup key."
        )
    if "comparison" in usage:
        add(
            "comparison_threshold_or_sentinel",
            "medium",
            "Constant is directly referenced by EQ/LT/LE."
        )
    if "arithmetic" in usage and isinstance(value, (int, float)):
        add(
            "numeric_parameter",
            "medium",
            "Constant participates directly in arithmetic."
        )

    # Context-based clues from neighboring instructions.
    neighbor_ops = {
        item["instruction"]["op"]
        for item in context_entries
        if isinstance(item, dict) and item.get("instruction")
    }
    if "CALL" in neighbor_ops and isinstance(value, str):
        add(
            "call_related_string",
            "low",
            "A function CALL occurs in the nearby instruction window."
        )

    # Deduplicate same role, keeping first/highest-quality reason.
    seen = set()
    out = []
    rank = {"high": 3, "medium": 2, "low": 1}
    for g in sorted(guesses, key=lambda x: rank.get(x["confidence"], 0), reverse=True):
        if g["role"] not in seen:
            out.append(g)
            seen.add(g["role"])
    return out


def analyze_constant_context(inp: Path, query: str | None = None,
                             window: int = 5,
                             include_unreferenced: bool = False,
                             include_extra_proto: bool = False) -> dict:
    """Show constants, exact references, nearby instructions, and conservative role guesses."""
    if window < 0 or window > 100:
        raise ValueError("--window must be between 0 and 100")

    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    if (not include_extra_proto) and root.children and is_extra_proto(root.children[-1]):
        root.children = root.children[:-1]

    q = query.casefold() if query else None
    results = []

    for path, p in _walk_protos(root):
        refs_map = _constant_refs_for_proto(p)
        std_words = [remap_word(w, forward=False) for w in p.code]
        decoded = [_decode_std_word(w) for w in std_words]

        for i, c in enumerate(p.constants):
            refs = refs_map.get(i, [])
            if not include_unreferenced and not refs:
                continue

            value = _const_python_value(c)
            display = _const_display(c)

            if q is not None:
                hay = (
                    f"{path} {i} {c.tag} {display} {value} "
                    + " ".join(f"{r['pc']} {r['op']} {r['text']}" for r in refs)
                ).casefold()
                if q not in hay:
                    continue

            context_entries = []
            seen_pc = set()
            for ref in refs:
                center = ref["pc"]
                lo = max(0, center - window)
                hi = min(len(decoded) - 1, center + window)
                for pc in range(lo, hi + 1):
                    if pc in seen_pc:
                        continue
                    seen_pc.add(pc)
                    d = decoded[pc]
                    context_entries.append({
                        "pc": pc,
                        "is_reference": any(rr["pc"] == pc for rr in refs),
                        "instruction": {
                            "op": d["name"],
                            "text": _instruction_text(d, p.constants, pc),
                            "successors": _successors(decoded, pc),
                        },
                    })

            context_entries.sort(key=lambda x: x["pc"])

            row = {
                "proto": path,
                "index": i,
                "tag": c.tag,
                "type": {
                    0: "nil",
                    1: "boolean",
                    3: "number",
                    4: "string",
                    19: "integer",
                    20: "long_string",
                }.get(c.tag, f"tag_{c.tag}"),
                "value": value,
                "display": display,
                "reference_count": len(refs),
                "usage_classes": _classify_constant_usage(refs),
                "references": refs,
                "context": context_entries,
            }
            row["guesses"] = _guess_role(row, context_entries)
            results.append(row)

    return {
        "input": str(inp),
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "query": query,
        "window": window,
        "matches": len(results),
        "results": results,
        "note": (
            "Guesses are heuristic and intentionally conservative. "
            "Use exact references/context as the source of truth."
        ),
    }


def write_constant_context_report(inp: Path, out_json: Path, query: str | None = None,
                                  window: int = 5,
                                  include_unreferenced: bool = False,
                                  include_extra_proto: bool = False) -> dict:
    report = analyze_constant_context(
        inp,
        query=query,
        window=window,
        include_unreferenced=include_unreferenced,
        include_extra_proto=include_extra_proto,
    )
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return {
        "input": str(inp),
        "output": str(out_json),
        "query": query,
        "window": window,
        "matches": report["matches"],
    }



# ---------------------------------------------------------------------------
# Register value-flow tracing
# ---------------------------------------------------------------------------

def _writes_register(d: dict, reg: int) -> bool:
    """Conservative check whether one Lua 5.3 instruction writes `reg`."""
    n = d["name"]
    A, B, C = d["A"], d["B"], d["C"]

    if n in {
        "MOVE","LOADK","LOADKX","LOADBOOL","GETUPVAL","GETTABUP","GETTABLE",
        "NEWTABLE","SELF","ADD","SUB","MUL","MOD","POW","DIV","IDIV",
        "BAND","BOR","BXOR","SHL","SHR","UNM","BNOT","NOT","LEN","CONCAT",
        "CLOSURE"
    }:
        if n == "SELF":
            return reg in {A, A + 1}
        return reg == A

    if n == "LOADNIL":
        return A <= reg <= A + B

    if n == "TESTSET":
        return reg == A

    if n == "CALL":
        if C == 0:
            # Variable result count; at minimum R[A] can be overwritten.
            return reg >= A
        if C >= 2:
            return A <= reg <= A + C - 2
        return False

    if n == "VARARG":
        if B == 0:
            return reg >= A
        return A <= reg <= A + B - 2

    if n in {"FORLOOP","FORPREP"}:
        return A <= reg <= A + 3

    if n == "TFORCALL":
        return A + 3 <= reg <= A + 2 + C

    if n == "TFORLOOP":
        return reg == A + 1

    return False


def _read_registers(d: dict) -> list[int]:
    """Conservative register reads for value-flow analysis."""
    n = d["name"]
    A, B, C = d["A"], d["B"], d["C"]
    out = []

    def rk(x):
        if not (x & RK_BIT):
            out.append(x)

    if n == "MOVE":
        out.append(B)
    elif n == "GETTABLE":
        out.append(B); rk(C)
    elif n == "SETTABUP":
        rk(B); rk(C)
    elif n == "SETUPVAL":
        out.append(A)
    elif n == "SETTABLE":
        out.append(A); rk(B); rk(C)
    elif n == "SELF":
        out.append(B); rk(C)
    elif n in {
        "ADD","SUB","MUL","MOD","POW","DIV","IDIV",
        "BAND","BOR","BXOR","SHL","SHR","EQ","LT","LE"
    }:
        rk(B); rk(C)
    elif n in {"UNM","BNOT","NOT","LEN"}:
        out.append(B)
    elif n == "CONCAT":
        out.extend(range(B, C + 1))
    elif n in {"TEST"}:
        out.append(A)
    elif n == "TESTSET":
        out.append(B)
    elif n in {"CALL","TAILCALL"}:
        out.append(A)
        if B == 0:
            # Unknown upper bound; caller stack tail is consumed.
            pass
        elif B >= 2:
            out.extend(range(A + 1, A + B))
    elif n == "RETURN":
        if B == 0:
            out.append(A)
        elif B >= 2:
            out.extend(range(A, A + B - 1))
    elif n in {"FORLOOP","FORPREP"}:
        out.extend(range(A, A + 4))
    elif n == "TFORCALL":
        out.extend(range(A, A + 3))
    elif n == "TFORLOOP":
        out.append(A + 1)
    elif n == "SETLIST":
        out.append(A)
        if B > 0:
            out.extend(range(A + 1, A + B + 1))

    return sorted(set(out))


def _def_source(d: dict, p: Proto, decoded: list[dict], pc: int) -> dict:
    """Describe how an instruction defines its destination value."""
    n = d["name"]
    A, B, C = d["A"], d["B"], d["C"]

    src = {
        "pc": pc,
        "op": n,
        "text": _instruction_text(d, p.constants, pc),
        "source_registers": _read_registers(d),
        "constant_indices": [],
    }

    if n == "LOADK":
        src["constant_indices"] = [d["Bx"]]
    elif n == "LOADKX":
        if pc + 1 < len(decoded) and decoded[pc + 1]["name"] == "EXTRAARG":
            src["constant_indices"] = [decoded[pc + 1]["Ax"]]
    else:
        for key in ("B", "C"):
            x = d[key]
            if x & RK_BIT:
                src["constant_indices"].append(x & 0xFF)

    src["constant_indices"] = sorted(set(src["constant_indices"]))
    return src


def trace_register_backward(p: Proto, target_pc: int, target_reg: int,
                            max_steps: int = 80, max_depth: int = 12) -> dict:
    """Trace the latest definitions feeding a register at a given PC.

    This is deliberately local/conservative: it walks backward in bytecode order.
    It does not claim path-sensitive SSA correctness across every loop/branch.
    """
    std_words = [remap_word(w, forward=False) for w in p.code]
    decoded = [_decode_std_word(w) for w in std_words]

    if not (0 <= target_pc <= len(decoded)):
        raise ValueError("target_pc outside prototype code range")
    if target_reg < 0:
        raise ValueError("target_reg must be non-negative")

    visited = set()

    def walk(before_pc: int, reg: int, depth: int):
        key = (before_pc, reg, depth)
        if key in visited:
            return {
                "register": reg,
                "before_pc": before_pc,
                "status": "cycle_or_duplicate",
            }
        visited.add(key)

        if depth > max_depth:
            return {
                "register": reg,
                "before_pc": before_pc,
                "status": "max_depth",
            }

        lo = max(-1, before_pc - max_steps - 1)
        for pc in range(before_pc - 1, lo, -1):
            d = decoded[pc]
            if not _writes_register(d, reg):
                continue

            info = _def_source(d, p, decoded, pc)
            info["register"] = reg
            info["status"] = "defined"

            children = []
            for src_reg in info["source_registers"]:
                children.append(walk(pc, src_reg, depth + 1))
            if children:
                info["sources"] = children

            consts = []
            for k in info["constant_indices"]:
                if 0 <= k < len(p.constants):
                    consts.append({
                        "index": k,
                        "tag": p.constants[k].tag,
                        "value": _const_python_value(p.constants[k]),
                        "display": _const_display(p.constants[k]),
                    })
            if consts:
                info["constants"] = consts

            return info

        return {
            "register": reg,
            "before_pc": before_pc,
            "status": "no_local_definition_found",
            "note": "Value may come from parameters, varargs, loop state, or another control-flow path.",
        }

    return walk(target_pc, target_reg, 0)


def _trace_ref_operands(p: Proto, ref: dict, max_steps: int, max_depth: int) -> list[dict]:
    """Trace register operands surrounding a constant reference instruction."""
    std_words = [remap_word(w, forward=False) for w in p.code]
    decoded = [_decode_std_word(w) for w in std_words]
    pc = ref["pc"]
    d = decoded[pc]
    regs = _read_registers(d)

    traces = []
    for reg in regs:
        traces.append({
            "register": reg,
            "trace": trace_register_backward(
                p, pc, reg,
                max_steps=max_steps,
                max_depth=max_depth,
            ),
        })
    return traces


def analyze_value_flow(inp: Path, query: str | None = None,
                       window: int = 4, max_steps: int = 80,
                       max_depth: int = 12,
                       include_extra_proto: bool = False) -> dict:
    """Analyze constants plus backward register flow around their use sites."""
    if max_steps < 1 or max_steps > 5000:
        raise ValueError("--max-steps must be between 1 and 5000")
    if max_depth < 1 or max_depth > 100:
        raise ValueError("--max-depth must be between 1 and 100")

    data = inp.read_bytes()
    h, root, parse_end = parse_custom_chunk(data)

    if (not include_extra_proto) and root.children and is_extra_proto(root.children[-1]):
        root.children = root.children[:-1]

    q = query.casefold() if query else None
    results = []

    for path, p in _walk_protos(root):
        refs_map = _constant_refs_for_proto(p)
        std_words = [remap_word(w, forward=False) for w in p.code]
        decoded = [_decode_std_word(w) for w in std_words]

        for i, c in enumerate(p.constants):
            refs = refs_map.get(i, [])
            if not refs:
                continue

            value = _const_python_value(c)
            display = _const_display(c)

            if q is not None:
                hay = (
                    f"{path} {i} {c.tag} {display} {value} "
                    + " ".join(f"{r['pc']} {r['op']} {r['text']}" for r in refs)
                ).casefold()
                if q not in hay:
                    continue

            ref_reports = []
            for ref in refs:
                pc = ref["pc"]
                lo = max(0, pc - window)
                hi = min(len(decoded) - 1, pc + window)
                context = [
                    {
                        "pc": qpc,
                        "op": decoded[qpc]["name"],
                        "text": _instruction_text(decoded[qpc], p.constants, qpc),
                        "successors": _successors(decoded, qpc),
                    }
                    for qpc in range(lo, hi + 1)
                ]

                ref_reports.append({
                    "reference": ref,
                    "context": context,
                    "register_traces": _trace_ref_operands(
                        p, ref,
                        max_steps=max_steps,
                        max_depth=max_depth,
                    ),
                })

            row = {
                "proto": path,
                "index": i,
                "tag": c.tag,
                "type": {
                    0: "nil",
                    1: "boolean",
                    3: "number",
                    4: "string",
                    19: "integer",
                    20: "long_string",
                }.get(c.tag, f"tag_{c.tag}"),
                "value": value,
                "display": display,
                "usage_classes": _classify_constant_usage(refs),
                "references": ref_reports,
            }
            results.append(row)

    return {
        "input": str(inp),
        "parse_end": parse_end,
        "trailer_size": len(data) - parse_end,
        "query": query,
        "window": window,
        "max_steps": max_steps,
        "max_depth": max_depth,
        "matches": len(results),
        "results": results,
        "note": (
            "Backward traces are conservative/local, not full path-sensitive SSA. "
            "They are intended to reveal value origins around edit targets."
        ),
    }


def write_value_flow_report(inp: Path, out_json: Path, query: str | None = None,
                            window: int = 4, max_steps: int = 80,
                            max_depth: int = 12,
                            include_extra_proto: bool = False) -> dict:
    report = analyze_value_flow(
        inp,
        query=query,
        window=window,
        max_steps=max_steps,
        max_depth=max_depth,
        include_extra_proto=include_extra_proto,
    )
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return {
        "input": str(inp),
        "output": str(out_json),
        "query": query,
        "matches": report["matches"],
    }


def compare_files(a: Path, b: Path) -> dict:
    import hashlib
    da=a.read_bytes(); db=b.read_bytes()
    try:
        _,_,ea=parse_custom_chunk(da)
    except Exception:
        ea=max(0,len(da)-273)
    try:
        _,_,eb=parse_custom_chunk(db)
    except Exception:
        eb=max(0,len(db)-273)
    ba=da[:ea]; bb=db[:eb]
    first=None
    for i,(x,y) in enumerate(zip(ba,bb)):
        if x!=y:
            first=i;break
    if first is None and len(ba)!=len(bb): first=min(len(ba),len(bb))
    return {
        "file_a":str(a),"file_b":str(b),
        "size_a":len(da),"size_b":len(db),
        "parse_end_a":ea,"parse_end_b":eb,
        "body_identical":ba==bb,
        "body_sha256_a":hashlib.sha256(ba).hexdigest(),
        "body_sha256_b":hashlib.sha256(bb).hexdigest(),
        "first_body_diff":first,
        "full_identical":da==db,
        "note":"Full files normally differ because Bz/C1/C5 contain fresh urandom bytes."
    }



# ===========================================================================
# SKUYRJ OPEN — RJTOOL BYRJ6 PAYLOAD EXTRACT / UNWRAP
# ===========================================================================
#
# Scope:
#   RJ-protected custom Lua bytecode -> verified inner custom Lua bytecode.
#   This module intentionally STOPS after producing the no-RJ bytecode.
#   It does not automatically decompile the extracted payload.
#
# Design:
#   - No hard-coded file offsets.
#   - Detect semantic fingerprints and literal-table structure.
#   - Rebuild custom 64-character alphabet.
#   - Decode and transform every chunk.
#   - Require FNV-1a + RJ secondary checksum PASS for every chunk.
#   - Require final inner custom Lua parser PASS to EOF.
# ===========================================================================

_SKUYRJ_MASK32 = 0xFFFFFFFF
_SKUYRJ_FNV_OFFSET = 2166136261
_SKUYRJ_FNV_PRIME = 16777619
_SKUYRJ_CHECK_SEED = 2654435769
_SKUYRJ_FAILURE_TEXT = "RJTOOL payload chunk integrity failure"
_SKUYRJ_PROFILE_MARKER = "RJTOOL_BYRJ6"
_SKUYRJ_LFIELDS_PER_FLUSH = 50

_SKUYRJ_OP_LOADK = 1
_SKUYRJ_OP_NEWTABLE = 11
_SKUYRJ_OP_SETLIST = 43


@dataclass
class _SkuyRJLiteralTable:
    pc_start: int
    register: int
    values: list
    setlist_count: int = 0
    pc_end: int = -1


def _skuyrj_root_values(root: Proto) -> list:
    return [_const_python_value(c) for c in root.constants]


def _skuyrj_reconstruct_literal_tables(root: Proto) -> list[_SkuyRJLiteralTable]:
    """Statically rebuild linear NEWTABLE/LOADK/SETLIST literal tables."""
    regs = [None] * max(256, root.maxstacksize + 64)
    tables: list[_SkuyRJLiteralTable] = []
    decoded = [_decode_std_word(remap_word(w, False)) for w in root.code]

    for pc, d in enumerate(decoded):
        op = d["op"]
        a = d["A"]

        if op == _SKUYRJ_OP_LOADK:
            k = d["Bx"]
            if not (0 <= k < len(root.constants)):
                raise ValueError(f"LOADK constant out of range at PC{pc}: K{k}")
            regs[a] = _const_python_value(root.constants[k])

        elif op == _SKUYRJ_OP_NEWTABLE:
            obj = []
            regs[a] = obj
            tables.append(_SkuyRJLiteralTable(pc_start=pc, register=a, values=obj))

        elif op == _SKUYRJ_OP_SETLIST:
            tab = regs[a]
            if not isinstance(tab, list):
                continue

            b = d["B"]
            c = d["C"]
            # Verified BYRJ6 literal-table shape uses explicit B/C.
            if b == 0 or c == 0:
                continue

            start = (c - 1) * _SKUYRJ_LFIELDS_PER_FLUSH
            need = start + b
            if len(tab) < need:
                tab.extend([None] * (need - len(tab)))

            for i in range(1, b + 1):
                tab[start + i - 1] = regs[a + i]

            for t in reversed(tables):
                if t.values is tab:
                    t.setlist_count += 1
                    t.pc_end = pc
                    break

    return tables


def _skuyrj_find_alphabet(values: list) -> tuple[int, str]:
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")
    candidates = []

    for i in range(0, len(values) - 7):
        parts = values[i:i + 8]
        if not all(isinstance(x, str) and len(x) == 8 for x in parts):
            continue
        alphabet = "".join(parts)
        if len(alphabet) != 64 or len(set(alphabet)) != 64:
            continue
        if not set(alphabet).issubset(allowed):
            continue
        candidates.append((i, alphabet))

    if not candidates:
        raise ValueError("RJTOOL custom 64-character alphabet not found")

    failure_indices = [i for i, v in enumerate(values) if v == _SKUYRJ_FAILURE_TEXT]
    if failure_indices:
        fk = failure_indices[0]
        candidates.sort(key=lambda x: abs(x[0] - fk))

    return candidates[0]


def _skuyrj_all_type(values: list, typ: type) -> bool:
    return bool(values) and all(isinstance(x, typ) for x in values)


def _skuyrj_find_table_group(
    tables: list[_SkuyRJLiteralTable],
) -> tuple[list[int], list[list]]:
    """
    Detect six BYRJ6 payload tables:
      encoded chunks / permutation / state A / state B / FNV / checksum
    """
    candidates = [t for t in tables if len(t.values) >= 128]
    matches = []

    for i in range(0, len(candidates) - 5):
        group = candidates[i:i + 6]
        lens = [len(t.values) for t in group]
        if len(set(lens)) != 1:
            continue

        n = lens[0]
        if n < 128:
            continue
        if not _skuyrj_all_type(group[0].values, str):
            continue
        if not all(_skuyrj_all_type(t.values, int) for t in group[1:]):
            continue

        permutation = group[1].values
        if len(set(permutation)) != n:
            continue
        if min(permutation) != 1 or max(permutation) != n:
            continue
        if set(permutation) != set(range(1, n + 1)):
            continue

        matches.append(group)

    if not matches:
        raise ValueError("RJTOOL six-table payload structure not found")

    matches.sort(key=lambda g: len(g[0].values), reverse=True)
    group = matches[0]
    return [t.pc_start for t in group], [t.values for t in group]


def _skuyrj_find_key_tables(
    tables: list[_SkuyRJLiteralTable],
    first_payload_pc: int,
) -> tuple[list[int], list[int], list[int]]:
    candidates = [
        t for t in tables
        if t.pc_start < first_payload_pc
        and len(t.values) == 32
        and all(isinstance(x, int) and 0 <= x <= 255 for x in t.values)
    ]
    if len(candidates) < 2:
        raise ValueError("RJTOOL 32-byte transform tables not found")
    a, b = candidates[-2], candidates[-1]
    return [a.pc_start, b.pc_start], list(a.values), list(b.values)


def _skuyrj_detect_profile(root: Proto, tables: list[_SkuyRJLiteralTable]) -> dict:
    values = _skuyrj_root_values(root)

    marker_hits = [
        (i, v) for i, v in enumerate(values)
        if isinstance(v, str) and _SKUYRJ_PROFILE_MARKER in v
    ]
    if not marker_hits:
        raise ValueError(f"{_SKUYRJ_PROFILE_MARKER} marker not found")

    failure_hits = [i for i, v in enumerate(values) if v == _SKUYRJ_FAILURE_TEXT]
    if not failure_hits:
        raise ValueError("RJTOOL integrity-failure marker not found")

    fingerprints = {
        "fnv_offset": _SKUYRJ_FNV_OFFSET,
        "fnv_prime": _SKUYRJ_FNV_PRIME,
        "secondary_seed": _SKUYRJ_CHECK_SEED,
        "lcg1_mul": 1103515245,
        "lcg1_add": 12345,
        "lcg2_mul": 1664525,
        "lcg2_add": 1013904223,
    }
    number_hits = {}
    for name, value in fingerprints.items():
        hit = []
        stack = [("root", root)]
        while stack:
            path, proto = stack.pop()
            for i, c in enumerate(proto.constants):
                try:
                    v = _const_python_value(c)
                except Exception:
                    continue
                if v == value:
                    hit.append({"proto": path, "constant": i})
            for j in range(len(proto.children) - 1, -1, -1):
                stack.append((f"{path}.{j}", proto.children[j]))
        if not hit:
            raise ValueError(f"RJTOOL numeric fingerprint missing: {name}={value}")
        number_hits[name] = hit

    alphabet_k, alphabet = _skuyrj_find_alphabet(values)
    group_pcs, group_values = _skuyrj_find_table_group(tables)
    key_pcs, key_a, key_b = _skuyrj_find_key_tables(tables, group_pcs[0])

    encoded, permutation, state_a, state_b, exp_fnv, exp_check = group_values
    n = len(encoded)

    if any(x is None for table in group_values for x in table):
        raise ValueError("RJ payload table contains unresolved entries")
    if any(not s for s in encoded):
        raise ValueError("RJ encoded payload contains empty chunk")

    marker_k, marker_text = marker_hits[0]
    return {
        "profile": "RJTOOL_BYRJ6",
        "marker_constant": marker_k,
        "marker": marker_text,
        "failure_constant": failure_hits[0],
        "alphabet_constant_start": alphabet_k,
        "alphabet": alphabet,
        "chunk_count": n,
        "table_pcs": {
            "encoded": group_pcs[0],
            "permutation": group_pcs[1],
            "state_a": group_pcs[2],
            "state_b": group_pcs[3],
            "expected_fnv": group_pcs[4],
            "expected_checksum": group_pcs[5],
            "key_a": key_pcs[0],
            "key_b": key_pcs[1],
        },
        "number_hits": number_hits,
        "_tables": {
            "encoded": encoded,
            "permutation": permutation,
            "state_a": state_a,
            "state_b": state_b,
            "expected_fnv": exp_fnv,
            "expected_checksum": exp_check,
            "key_a": key_a,
            "key_b": key_b,
        },
    }


def _skuyrj_decode_custom_base64(text: str, alphabet: str) -> list[int]:
    if len(alphabet) != 64 or len(set(alphabet)) != 64:
        raise ValueError("invalid RJ custom alphabet")

    lookup = {ch: i for i, ch in enumerate(alphabet)}
    raw = []

    for off in range(0, len(text), 4):
        q = text[off:off + 4]
        if len(q) < 2:
            raise ValueError(f"invalid encoded tail at offset {off}")

        vals = []
        for ch in q:
            if ch == "=":
                vals.append(0)
            elif ch in lookup:
                vals.append(lookup[ch])
            else:
                raise ValueError(f"encoded character not in RJ alphabet: {ch!r}")

        while len(vals) < 4:
            vals.append(0)

        packed = vals[0] * 262144 + vals[1] * 4096 + vals[2] * 64 + vals[3]
        raw.append((packed >> 16) & 0xFF)
        if len(q) > 2 and q[2] != "=":
            raw.append((packed >> 8) & 0xFF)
        if len(q) > 3 and q[3] != "=":
            raw.append(packed & 0xFF)

    return raw


def _skuyrj_rol32(x: int, n: int) -> int:
    x &= _SKUYRJ_MASK32
    return ((x << n) | (x >> (32 - n))) & _SKUYRJ_MASK32


def _skuyrj_transform_chunk(
    raw: list[int],
    logical_index: int,
    state_a_initial: int,
    state_b_initial: int,
    per_chunk_mix: int,
    key_a: list[int],
    key_b: list[int],
) -> tuple[bytes, int, int]:
    if len(key_a) != len(key_b) or not key_a:
        raise ValueError("invalid RJ transform key tables")

    state_a = state_a_initial & _SKUYRJ_MASK32
    state_b = state_b_initial & _SKUYRJ_MASK32
    fnv = _SKUYRJ_FNV_OFFSET
    check = _SKUYRJ_CHECK_SEED
    out = bytearray()

    for pos, src_byte in enumerate(raw, 1):
        j = (pos - 1) % len(key_a)

        k = key_a[j] ^ key_b[j]
        k ^= (
            logical_index * 131
            + pos * 17
            + per_chunk_mix
        ) & 0xFF
        k &= 0xFF

        state_a = (
            ((state_a ^ k ^ pos) * 1103515245) + 12345
        ) & _SKUYRJ_MASK32
        state_a = _skuyrj_rol32(state_a, 7)

        tmp = (state_a ^ (k * 257) ^ pos) & _SKUYRJ_MASK32
        state_b = (
            state_b
            + ((tmp * 1664525) & _SKUYRJ_MASK32)
            + 1013904223
        ) & _SKUYRJ_MASK32
        state_b = _skuyrj_rol32(state_b, 11)

        b = (
            src_byte
            ^ state_a
            ^ state_b
            ^ (k * 167)
            ^ pos
        ) & 0xFF
        out.append(b)

        fnv = ((fnv ^ b) * _SKUYRJ_FNV_PRIME) & _SKUYRJ_MASK32
        check = (check + b * (pos + 31)) & _SKUYRJ_MASK32
        check = (check ^ (fnv >> 7)) & _SKUYRJ_MASK32

    return bytes(out), fnv, check


def _skuyrj_extract_payload(profile: dict, progress_cb=None) -> tuple[bytes, dict]:
    t = profile["_tables"]
    encoded = t["encoded"]
    permutation = t["permutation"]
    state_a = t["state_a"]
    state_b = t["state_b"]
    exp_fnv = t["expected_fnv"]
    exp_check = t["expected_checksum"]
    key_a = t["key_a"]
    key_b = t["key_b"]
    alphabet = profile["alphabet"]

    n = len(encoded)
    parts = []
    fnv_pass = 0
    check_pass = 0
    samples = []

    checkpoints = {1, n}
    if n >= 10:
        step = max(1, n // 10)
        checkpoints.update(range(step, n + 1, step))

    for logical in range(1, n + 1):
        storage_index = permutation[logical - 1]
        if not (1 <= storage_index <= n):
            raise ValueError(
                f"invalid RJ permutation at logical chunk {logical}: {storage_index}"
            )

        enc = encoded[storage_index - 1]
        raw = _skuyrj_decode_custom_base64(enc, alphabet)

        chunk, actual_fnv, actual_check = _skuyrj_transform_chunk(
            raw=raw,
            logical_index=logical,
            state_a_initial=state_a[logical - 1],
            state_b_initial=state_b[logical - 1],
            per_chunk_mix=state_a[logical - 1],
            key_a=key_a,
            key_b=key_b,
        )

        expected_fnv = exp_fnv[logical - 1] & _SKUYRJ_MASK32
        expected_check = exp_check[logical - 1] & _SKUYRJ_MASK32

        if actual_fnv != expected_fnv:
            raise ValueError(
                f"RJ FNV mismatch chunk {logical}: "
                f"actual={actual_fnv} expected={expected_fnv}"
            )
        fnv_pass += 1

        if actual_check != expected_check:
            raise ValueError(
                f"RJ checksum mismatch chunk {logical}: "
                f"actual={actual_check} expected={expected_check}"
            )
        check_pass += 1

        parts.append(chunk)

        if logical <= 3 or logical == n:
            samples.append({
                "logical_chunk": logical,
                "storage_chunk": storage_index,
                "encoded_chars": len(enc),
                "decoded_bytes": len(raw),
                "payload_bytes": len(chunk),
                "fnv": actual_fnv,
                "checksum": actual_check,
            })

        if progress_cb and logical in checkpoints:
            progress_cb(logical, n, fnv_pass, check_pass)

    return b"".join(parts), {
        "chunk_count": n,
        "fnv_pass": fnv_pass,
        "checksum_pass": check_pass,
        "sample_chunks": samples,
    }


def _skuyrj_validate_inner(payload: bytes) -> dict:
    h, root, end = parse_custom_chunk(payload)
    trailing = len(payload) - end
    if end != len(payload):
        raise ValueError(
            f"inner Lua parse did not reach EOF: "
            f"parse_end={end}, size={len(payload)}, trailing={trailing}"
        )
    return {
        "type": "CUSTOM_LUA_53",
        "header": {
            "int": h.int_size,
            "size_t": h.size_t_size,
            "instruction": h.instruction_size,
            "lua_integer": h.lua_integer_size,
            "lua_number": h.lua_number_size,
            "main_upvalues": h.main_upvalues,
        },
        "parse_end": end,
        "trailing": trailing,
        **stats(root),
    }


def skuyrj_open_file(
    inp: Path,
    out: Path,
    report_path: Path,
    progress_cb=None,
) -> dict:
    """Verified RJTOOL BYRJ6 unwrap. No decompile is performed."""
    raw = inp.read_bytes()
    outer_sha = hashlib.sha256(raw).hexdigest()

    outer_h, root, outer_end = parse_custom_chunk(raw)
    literal_tables = _skuyrj_reconstruct_literal_tables(root)
    profile = _skuyrj_detect_profile(root, literal_tables)

    payload, integrity = _skuyrj_extract_payload(
        profile,
        progress_cb=progress_cb,
    )
    inner = _skuyrj_validate_inner(payload)
    inner_sha = hashlib.sha256(payload).hexdigest()

    public_profile = {
        k: v for k, v in profile.items()
        if k != "_tables"
    }
    report = {
        "status": "VERIFIED",
        "mode": "Skuyrj open",
        "profile": public_profile,
        "input": {
            "path": str(inp),
            "size": len(raw),
            "sha256": outer_sha,
            "parse_end": outer_end,
            "trailing": len(raw) - outer_end,
            "stats": stats(root),
            "header": {
                "int": outer_h.int_size,
                "size_t": outer_h.size_t_size,
                "instruction": outer_h.instruction_size,
                "lua_integer": outer_h.lua_integer_size,
                "lua_number": outer_h.lua_number_size,
                "main_upvalues": outer_h.main_upvalues,
            },
        },
        "integrity": integrity,
        "output": {
            "path": str(out),
            "size": len(payload),
            "sha256": inner_sha,
        },
        "inner": inner,
    }

    # IMPORTANT: only create final output after every check above passed.
    out.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return report


# ===========================================================================
# SKUY PROTECTION ENGINE
# ===========================================================================
# Source Protection -> Custom Compile -> SKUY Protect outer bytecode.
# SKUY Open supports both original RJTOOL_BYRJ6 and SKUY_PROTECT_V1.

_SKUY_PROFILE_MARKER = "SKUY_PROTECT_V1"
_SKUY_FAILURE_TEXT = "SKUY payload integrity failure"
_SKUY_BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"


def _skuy_fnv1a_bytes(data: bytes) -> int:
    h = _SKUYRJ_FNV_OFFSET
    for b in data:
        h = ((h ^ b) * _SKUYRJ_FNV_PRIME) & _SKUYRJ_MASK32
    return h


def _skuy_checksum_bytes(data: bytes) -> int:
    fnv = _SKUYRJ_FNV_OFFSET
    check = _SKUYRJ_CHECK_SEED
    for pos, b in enumerate(data, 1):
        fnv = ((fnv ^ b) * _SKUYRJ_FNV_PRIME) & _SKUYRJ_MASK32
        check = (check + b * (pos + 31)) & _SKUYRJ_MASK32
        check = (check ^ (fnv >> 7)) & _SKUYRJ_MASK32
    return check


def _skuy_custom_b64encode(data: bytes, alphabet: str) -> str:
    if len(alphabet) != 64 or len(set(alphabet)) != 64:
        raise ValueError("invalid SKUY alphabet")
    out = []
    for off in range(0, len(data), 3):
        q = data[off:off + 3]
        b1 = q[0]
        b2 = q[1] if len(q) > 1 else 0
        b3 = q[2] if len(q) > 2 else 0
        packed = (b1 << 16) | (b2 << 8) | b3
        out.append(alphabet[(packed >> 18) & 63])
        out.append(alphabet[(packed >> 12) & 63])
        out.append(alphabet[(packed >> 6) & 63] if len(q) > 1 else "=")
        out.append(alphabet[packed & 63] if len(q) > 2 else "=")
    return "".join(out)


def _skuy_encode_chunk(payload: bytes, logical_index: int, state_a_initial: int,
                       state_b_initial: int, per_chunk_mix: int,
                       key_a: list[int], key_b: list[int]) -> bytes:
    state_a = state_a_initial & _SKUYRJ_MASK32
    state_b = state_b_initial & _SKUYRJ_MASK32
    out = bytearray()
    for pos, payload_byte in enumerate(payload, 1):
        j = (pos - 1) % len(key_a)
        k = key_a[j] ^ key_b[j]
        k ^= (logical_index * 131 + pos * 17 + per_chunk_mix) & 0xFF
        k &= 0xFF
        state_a = (((state_a ^ k ^ pos) * 1103515245) + 12345) & _SKUYRJ_MASK32
        state_a = _skuyrj_rol32(state_a, 7)
        tmp = (state_a ^ (k * 257) ^ pos) & _SKUYRJ_MASK32
        state_b = (
            state_b + ((tmp * 1664525) & _SKUYRJ_MASK32) + 1013904223
        ) & _SKUYRJ_MASK32
        state_b = _skuyrj_rol32(state_b, 11)
        mask = (state_a ^ state_b ^ (k * 167) ^ pos) & 0xFF
        out.append(payload_byte ^ mask)
    return bytes(out)


def _skuy_split_payload(payload: bytes, mode: str = "direct") -> list[bytes]:
    mode = mode.lower()
    chunks = []
    pos = 0
    rng = secrets.SystemRandom()
    while pos < len(payload):
        if mode == "max":
            size = rng.randint(704, 1536)
        elif mode == "bal":
            size = rng.randint(960, 1344)
        else:
            size = rng.randint(896, 1408)
        chunks.append(payload[pos:pos + size])
        pos += size
    return chunks or [b""]


def _skuy_build_profile_data(payload: bytes, mode: str = "direct") -> dict:
    rng = secrets.SystemRandom()
    alphabet_chars = list(_SKUY_BASE64)
    rng.shuffle(alphabet_chars)
    alphabet = "".join(alphabet_chars)
    key_a = [secrets.randbelow(256) for _ in range(32)]
    key_b = [secrets.randbelow(256) for _ in range(32)]
    logical_chunks = _skuy_split_payload(payload, mode)
    n = len(logical_chunks)
    permutation = list(range(1, n + 1))
    rng.shuffle(permutation)
    state_a = [secrets.randbits(32) for _ in range(n)]
    state_b = [secrets.randbits(32) for _ in range(n)]
    expected_fnv = []
    expected_check = []
    encoded_logical = []
    for logical, chunk in enumerate(logical_chunks, 1):
        expected_fnv.append(_skuy_fnv1a_bytes(chunk))
        expected_check.append(_skuy_checksum_bytes(chunk))
        raw = _skuy_encode_chunk(
            chunk, logical,
            state_a[logical - 1], state_b[logical - 1], state_a[logical - 1],
            key_a, key_b,
        )
        encoded_logical.append(_skuy_custom_b64encode(raw, alphabet))
    encoded_storage = [None] * n
    for logical in range(1, n + 1):
        storage = permutation[logical - 1]
        encoded_storage[storage - 1] = encoded_logical[logical - 1]
    return {
        "alphabet": alphabet,
        "key_a": key_a,
        "key_b": key_b,
        "encoded": encoded_storage,
        "permutation": permutation,
        "state_a": state_a,
        "state_b": state_b,
        "expected_fnv": expected_fnv,
        "expected_checksum": expected_check,
        "whole_fnv": _skuy_fnv1a_bytes(payload),
        "whole_checksum": _skuy_checksum_bytes(payload),
        "chunk_count": n,
        "mode": mode,
    }


def _skuy_lua_quote(s: str) -> str:
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def _skuy_lua_table(values, strings: bool = False, per_line: int = 12) -> str:
    parts = [_skuy_lua_quote(v) if strings else str(int(v)) for v in values]
    lines = []
    for i in range(0, len(parts), per_line):
        lines.append("    " + ",".join(parts[i:i + per_line]))
    return "{\n" + ",\n".join(lines) + "\n}"


def _skuy_build_outer_loader(profile: dict, mode: str = "direct") -> str:
    alphabet = profile["alphabet"]
    frags = [alphabet[i:i + 8] for i in range(0, 64, 8)]
    marker = f"{_SKUY_PROFILE_MARKER}_{secrets.token_hex(8)}"
    key_a = _skuy_lua_table(profile["key_a"], per_line=16)
    key_b = _skuy_lua_table(profile["key_b"], per_line=16)
    encoded = _skuy_lua_table(profile["encoded"], strings=True, per_line=1)
    permutation = _skuy_lua_table(profile["permutation"], per_line=20)
    state_a = _skuy_lua_table(profile["state_a"], per_line=12)
    state_b = _skuy_lua_table(profile["state_b"], per_line=12)
    exp_fnv = _skuy_lua_table(profile["expected_fnv"], per_line=12)
    exp_chk = _skuy_lua_table(profile["expected_checksum"], per_line=12)
    junk = ""
    if mode.lower() == "max":
        junk_vals = [secrets.randbits(31) for _ in range(48)]
        junk = "\nlocal __SKUY_NOISE = " + _skuy_lua_table(junk_vals, per_line=12) + "\n"

    return (
        "-- SKUY PROTECT OUTER LOADER\n"
        f"local __SKUY_MARKER={_skuy_lua_quote(marker)}\n"
        f"local __SKUY_FAIL={_skuy_lua_quote(_SKUY_FAILURE_TEXT)}\n"
        + "\n".join(f"local __A{i+1}={_skuy_lua_quote(frags[i])}" for i in range(8)) + "\n"
        + "local __ALPHABET=__A1..__A2..__A3..__A4..__A5..__A6..__A7..__A8\n"
        + f"local __KEY_A={key_a}\nlocal __KEY_B={key_b}\n"
        + f"local __ENCODED={encoded}\nlocal __ORDER={permutation}\n"
        + f"local __STATE_A={state_a}\nlocal __STATE_B={state_b}\n"
        + f"local __EXPECTED_FNV={exp_fnv}\nlocal __EXPECTED_CHECK={exp_chk}\n"
        + f"local __WHOLE_FNV={profile['whole_fnv']}\nlocal __WHOLE_CHECK={profile['whole_checksum']}\n"
        + junk
        + r'''
local __LOOKUP={}
for i=1,#__ALPHABET do
    __LOOKUP[string.sub(__ALPHABET,i,i)]=i-1
end

local function __rol32(x,n)
    x=x&0xFFFFFFFF
    return (((x<<n)|(x>>(32-n)))&0xFFFFFFFF)
end

local function __decode64(s)
    local out={}
    local oi=1
    for p=1,#s,4 do
        local c1=string.sub(s,p,p)
        local c2=string.sub(s,p+1,p+1)
        local c3=string.sub(s,p+2,p+2)
        local c4=string.sub(s,p+3,p+3)
        local v1=__LOOKUP[c1] or 0
        local v2=__LOOKUP[c2] or 0
        local v3=(c3=="=" or c3=="") and 0 or (__LOOKUP[c3] or 0)
        local v4=(c4=="=" or c4=="") and 0 or (__LOOKUP[c4] or 0)
        local x=((v1<<18)|(v2<<12)|(v3<<6)|v4)
        out[oi]=(x>>16)&255; oi=oi+1
        if c3~="=" and c3~="" then out[oi]=(x>>8)&255; oi=oi+1 end
        if c4~="=" and c4~="" then out[oi]=x&255; oi=oi+1 end
    end
    return out
end

local function __transform(raw,logical,sa,sb,mix)
    local out={}
    local fnv=2166136261
    local chk=2654435769
    for pos=1,#raw do
        local j=((pos-1)%32)+1
        local k=(__KEY_A[j]~__KEY_B[j])
        k=(k~((logical*131+pos*17+mix)&255))&255
        sa=(((sa~k~pos)*1103515245)+12345)&0xFFFFFFFF
        sa=__rol32(sa,7)
        local tmp=(sa~(k*257)~pos)&0xFFFFFFFF
        sb=(sb+((tmp*1664525)&0xFFFFFFFF)+1013904223)&0xFFFFFFFF
        sb=__rol32(sb,11)
        local b=(raw[pos]~sa~sb~(k*167)~pos)&255
        out[pos]=b
        fnv=((fnv~b)*16777619)&0xFFFFFFFF
        chk=(chk+b*(pos+31))&0xFFFFFFFF
        chk=(chk~(fnv>>7))&0xFFFFFFFF
    end
    return out,fnv,chk
end

local __PARTS={}
for logical=1,#__ORDER do
    local storage=__ORDER[logical]
    local raw=__decode64(__ENCODED[storage])
    local bytes,fnv,chk=__transform(raw,logical,__STATE_A[logical],__STATE_B[logical],__STATE_A[logical])
    if fnv~=__EXPECTED_FNV[logical] or chk~=__EXPECTED_CHECK[logical] then
        error(__SKUY_FAIL,0)
    end
    local chars={}
    for i=1,#bytes do chars[i]=string.char(bytes[i]) end
    __PARTS[logical]=table.concat(chars)
end

local __PAYLOAD=table.concat(__PARTS)
local __FNV=2166136261
local __CHK=2654435769
for i=1,#__PAYLOAD do
    local b=string.byte(__PAYLOAD,i)
    __FNV=((__FNV~b)*16777619)&0xFFFFFFFF
    __CHK=(__CHK+b*(i+31))&0xFFFFFFFF
    __CHK=(__CHK~(__FNV>>7))&0xFFFFFFFF
end
if __FNV~=__WHOLE_FNV or __CHK~=__WHOLE_CHECK then error(__SKUY_FAIL,0) end
local __CHUNK,__ERR=load(__PAYLOAD,"@SKUY_INNER")
if not __CHUNK then error(__ERR or "SKUY inner payload load failed",0) end
return __CHUNK()
'''
    )


def _skuy_validate_custom_payload(data: bytes) -> dict:
    h, root, end = parse_custom_chunk(data)
    trailing = len(data) - end
    trailer = validate_trailer_compatible(data, end)
    if trailing and not trailer.get("valid"):
        raise ValueError(f"custom bytecode trailing data unsupported: {trailing} bytes")
    return {
        "parse_end": end,
        "trailing": trailing,
        "trailer_valid": bool(trailer.get("valid")),
        "trailer_kind": trailer.get("kind"),
        **stats(root),
    }


def _skuy_detect_profile(root: Proto, tables: list[_SkuyRJLiteralTable]) -> dict:
    values = _skuyrj_root_values(root)
    marker_hits = [(i, v) for i, v in enumerate(values) if isinstance(v, str) and _SKUY_PROFILE_MARKER in v]
    if not marker_hits:
        raise ValueError(f"{_SKUY_PROFILE_MARKER} marker not found")
    failure_hits = [i for i, v in enumerate(values) if v == _SKUY_FAILURE_TEXT]
    if not failure_hits:
        raise ValueError("SKUY integrity-failure marker not found")
    alphabet_k, alphabet = _skuyrj_find_alphabet(values)
    candidates = [t for t in tables if len(t.values) >= 1]
    matches = []
    for i in range(0, len(candidates) - 5):
        group = candidates[i:i + 6]
        lens = [len(t.values) for t in group]
        if len(set(lens)) != 1:
            continue
        n = lens[0]
        if not _skuyrj_all_type(group[0].values, str):
            continue
        if not all(_skuyrj_all_type(t.values, int) for t in group[1:]):
            continue
        perm = group[1].values
        if len(set(perm)) != n or set(perm) != set(range(1, n + 1)):
            continue
        matches.append(group)
    if not matches:
        raise ValueError("SKUY six-table payload structure not found")
    matches.sort(key=lambda g: len(g[0].values), reverse=True)
    group = matches[0]
    group_pcs = [t.pc_start for t in group]
    group_values = [t.values for t in group]
    key_pcs, key_a, key_b = _skuyrj_find_key_tables(tables, group_pcs[0])
    encoded, permutation, state_a, state_b, exp_fnv, exp_check = group_values
    required = [2166136261,16777619,2654435769,1103515245,12345,1664525,1013904223]
    seen = set()
    stack = [root]
    while stack:
        p = stack.pop()
        for c in p.constants:
            try:
                v = _const_python_value(c)
            except Exception:
                continue
            if isinstance(v, int):
                seen.add(v)
        stack.extend(p.children)
    missing = [x for x in required if x not in seen]
    if missing:
        raise ValueError(f"SKUY transform fingerprints missing: {missing}")
    return {
        "profile": "SKUY_PROTECT_V1",
        "marker_constant": marker_hits[0][0],
        "marker": marker_hits[0][1],
        "failure_constant": failure_hits[0],
        "alphabet_constant_start": alphabet_k,
        "alphabet": alphabet,
        "chunk_count": len(encoded),
        "table_pcs": {
            "encoded": group_pcs[0], "permutation": group_pcs[1],
            "state_a": group_pcs[2], "state_b": group_pcs[3],
            "expected_fnv": group_pcs[4], "expected_checksum": group_pcs[5],
            "key_a": key_pcs[0], "key_b": key_pcs[1],
        },
        "_tables": {
            "encoded": encoded, "permutation": permutation,
            "state_a": state_a, "state_b": state_b,
            "expected_fnv": exp_fnv, "expected_checksum": exp_check,
            "key_a": key_a, "key_b": key_b,
        },
    }


def skuy_open_file(inp: Path, out: Path, report_path: Path, progress_cb=None) -> dict:
    raw = inp.read_bytes()
    outer_h, root, outer_end = parse_custom_chunk(raw)
    literal_tables = _skuyrj_reconstruct_literal_tables(root)
    root_values = _skuyrj_root_values(root)
    if any(isinstance(v, str) and _SKUY_PROFILE_MARKER in v for v in root_values):
        profile = _skuy_detect_profile(root, literal_tables)
    elif any(isinstance(v, str) and _SKUYRJ_PROFILE_MARKER in v for v in root_values):
        profile = _skuyrj_detect_profile(root, literal_tables)
    else:
        raise ValueError("unsupported outer profile: RJTOOL_BYRJ6/SKUY_PROTECT_V1 not detected")
    payload, integrity = _skuyrj_extract_payload(profile, progress_cb=progress_cb)
    inner = _skuy_validate_custom_payload(payload)
    inner_sha = hashlib.sha256(payload).hexdigest()
    public_profile = {k: v for k, v in profile.items() if k != "_tables"}
    report = {
        "status": "VERIFIED",
        "mode": "SKUY Open",
        "profile": public_profile,
        "input": {
            "path": str(inp), "size": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "parse_end": outer_end, "trailing": len(raw) - outer_end,
            "stats": stats(root),
        },
        "integrity": integrity,
        "output": {"path": str(out), "size": len(payload), "sha256": inner_sha},
        "inner": inner,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    return report


def _skuy_source_payload_wrapper(payload: str, chunk_name: str) -> tuple[str, int]:
    raw = payload.encode("utf-8")
    expected = _skuy_fnv1a_bytes(raw)
    parts = []
    for off in range(0, len(raw), 192):
        block = raw[off:off+192]
        parts.append('"' + ''.join(f"\\{b:03d}" for b in block) + '"')
    if not parts:
        parts = ['""']
    parts_text = ",\n".join("    "+x for x in parts)
    name = str(chunk_name).replace("\\","/").replace('"','_')
    wrapper = (
        "-- SKUY SOURCE PROTECTION\nreturn (function()\n"
        f"    local __EXPECTED={expected}\n"
        "    local function __hash(data)\n"
        "        local h=2166136261\n"
        "        for i=1,#data do h=((h~string.byte(data,i))*16777619)&0xFFFFFFFF end\n"
        "        return h\n"
        "    end\n"
        "    local __PAYLOAD_PARTS={\n"
        + parts_text + "\n    }\n"
        "    local __payload=table.concat(__PAYLOAD_PARTS); __PAYLOAD_PARTS=nil\n"
        "    if __hash(__payload)~=__EXPECTED then error(\"SKUY source payload integrity failure\",0) end\n"
        f"    local __chunk,__err=load(__payload,\"@{name}\")\n"
        "    if not __chunk then error(__err or \"SKUY source payload load failed\",0) end\n"
        "    return __chunk()\nend)()\n"
    )
    return wrapper, expected


def skuy_source_protect_file(inp: Path, out: Path, report_path: Path, luac: Path) -> dict:
    source = inp.read_text(encoding="utf-8", errors="strict")
    ok, msg = _syntax_check_lua(source, luac)
    if ok is False:
        raise ValueError("source syntax invalid: " + (msg or "unknown error"))
    luamin = shutil.which("luamin")
    if not luamin:
        raise RuntimeError("luamin not found. Install with: npm i -g luamin")
    with tempfile.TemporaryDirectory(prefix="skuy_source_protect_") as td:
        td = Path(td)
        mini = td / "min.lua"
        with mini.open("w", encoding="utf-8", newline="\n") as f:
            cp = subprocess.run([luamin, "-f", str(inp)], stdout=f, stderr=subprocess.PIPE, text=True)
        if cp.returncode != 0:
            raise RuntimeError((cp.stderr or "luamin failed").strip())
        min_text = mini.read_text(encoding="utf-8", errors="strict")
        ok2, msg2 = _syntax_check_lua(min_text, luac)
        if ok2 is False:
            raise ValueError("minified source syntax invalid: " + (msg2 or "unknown"))
        wrapper, expected = _skuy_source_payload_wrapper(min_text, inp.name)
        ok3, msg3 = _syntax_check_lua(wrapper, luac)
        if ok3 is False:
            raise ValueError("protected source syntax invalid: " + (msg3 or "unknown"))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(wrapper, encoding="utf-8", newline="\n")
    report = {
        "status":"VERIFIED", "mode":"Source Protection",
        "input":{"path":str(inp),"size":inp.stat().st_size,"sha256":hashlib.sha256(inp.read_bytes()).hexdigest()},
        "stages":["syntax PASS","minify PASS","string/long-string payload encoding PASS","FNV-1a payload integrity PASS","final syntax PASS"],
        "payload_fnv1a": expected,
        "output":{"path":str(out),"size":out.stat().st_size,"sha256":hashlib.sha256(out.read_bytes()).hexdigest()},
    }
    report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return report


def skuy_protect_file(inp: Path, out: Path, report_path: Path, luac: Path,
                      mode: str = "direct", progress_cb=None) -> dict:
    inner = inp.read_bytes()
    inner_info = _skuy_validate_custom_payload(inner)
    profile_data = _skuy_build_profile_data(inner, mode=mode)
    loader = _skuy_build_outer_loader(profile_data, mode=mode)
    with tempfile.TemporaryDirectory(prefix="skuy_outer_build_") as td:
        td = Path(td)
        loader_src = td / "outer_loader.lua"
        compiled = td / "outer_custom.lua"
        extracted = td / "selftest_inner.lua"
        extracted_report = td / "selftest_report.json"
        loader_src.write_text(loader, encoding="utf-8", newline="\n")
        ok, msg = _syntax_check_lua(loader, luac)
        if ok is False:
            raise ValueError("generated SKUY loader syntax invalid: " + (msg or "unknown"))
        compile_info = compile_source(loader_src, compiled, luac)
        open_info = skuy_open_file(compiled, extracted, extracted_report, progress_cb=progress_cb)
        recovered = extracted.read_bytes()
        if recovered != inner:
            raise RuntimeError("SKUY self-test FAILED: reopened inner differs byte-for-byte")
        final_bytes = compiled.read_bytes()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(final_bytes)
    report = {
        "status":"VERIFIED", "mode":"SKUY Protect",
        "profile":"SKUY_PROTECT_V1", "protection_mode":mode,
        "input":{"path":str(inp),"size":len(inner),"sha256":hashlib.sha256(inner).hexdigest(),"custom":inner_info},
        "build":{"chunk_count":profile_data["chunk_count"],"whole_fnv":profile_data["whole_fnv"],"whole_checksum":profile_data["whole_checksum"],"compile":compile_info},
        "self_test":{"open_profile":open_info["profile"]["profile"],"fnv_pass":open_info["integrity"]["fnv_pass"],"checksum_pass":open_info["integrity"]["checksum_pass"],"byte_for_byte":True,"sha256_match":True},
        "output":{"path":str(out),"size":len(final_bytes),"sha256":hashlib.sha256(final_bytes).hexdigest()},
    }
    report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    return report


def menu(base: Path):
    """Interactive SKUY workspace menu for Termux.

    This layer manages branding, folders, file selection, and safe output names.
    Core bytecode functions are intentionally left unchanged.
    """
    luac = base / "EXES" / "luac"
    luadec = base / "EXES" / "luadec"
    unluac = base / "EXES" / "unluac_pro.jar"
    nadeem_jar = base / "EXES" / "LUADEC"  # internal compatibility engine path

    # ------------------------------------------------------------------
    # SKUY workspace layout
    # ------------------------------------------------------------------
    WS = {
        "compile_in": base / "Compile Lua" / "input",
        "compile_out": base / "Compile Lua" / "output",

        "restore_in": base / "Restore Custom" / "input",
        "restore_out": base / "Restore Custom" / "output",

        "dec_skuy_in": base / "Decompile" / "Skuy" / "input",
        "dec_skuy_out": base / "Decompile" / "Skuy" / "output",

        "dec_native_in": base / "Decompile" / "Native Source" / "input",
        "dec_native_out": base / "Decompile" / "Native Source" / "output",

        "dec_rescue_in": base / "Decompile" / "Rescue" / "input",
        "dec_rescue_out": base / "Decompile" / "Rescue" / "output",

        "dec_disasm_in": base / "Decompile" / "Disassembly" / "input",
        "dec_disasm_out": base / "Decompile" / "Disassembly" / "output",

        "dec_rj_in": base / "Decompile" / "SKUY Open" / "input",
        "dec_rj_out": base / "Decompile" / "SKUY Open" / "output",

        "protect_source_in": base / "Protection" / "Source" / "input",
        "protect_source_out": base / "Protection" / "Source" / "output",
        "protect_skuy_in": base / "Protection" / "SKUY Protect" / "input",
        "protect_skuy_out": base / "Protection" / "SKUY Protect" / "output",
        "protect_full_in": base / "Protection" / "Full Protection" / "input",
        "protect_full_out": base / "Protection" / "Full Protection" / "output",

        "editor_in": base / "Bytecode Editor" / "input",
        "editor_edit": base / "Bytecode Editor" / "Edit",
        "editor_out": base / "Bytecode Editor" / "output",

        "analyze_in": base / "Analyze" / "input",
        "analyze_out": base / "Analyze" / "output",
    }

    for p in WS.values():
        p.mkdir(parents=True, exist_ok=True)

    use_color = sys.stdout.isatty() and not os.environ.get("NO_COLOR")

    def col(code: str, s: str) -> str:
        return f"\033[{code}m{s}\033[0m" if use_color else s

    def clear():
        if sys.stdout.isatty():
            print("\033[2J\033[H", end="")

    def line(ch="─", n=56):
        return ch * n

    def title(text_: str):
        print(col("1;36", f"\n  {text_}"))
        print(col("2;37", "  " + line()))

    def pause():
        try:
            input(col("2;37", "\n  Tekan Enter untuk kembali..."))
        except (EOFError, KeyboardInterrupt):
            pass

    def ask(prompt: str, optional: bool = False) -> str:
        suffix = " (opsional)" if optional else ""
        return input(col("1;37", f"  {prompt}{suffix}: ")).strip()

    def show(obj):
        if isinstance(obj, (dict, list)):
            print(json.dumps(obj, indent=2, ensure_ascii=False))
        else:
            print(obj)

    def ok(msg: str):
        print(col("1;32", f"\n  ✓ {msg}"))

    def warn(msg: str):
        print(col("1;33", f"\n  ! {msg}"))

    def err(e: Exception):
        print(col("1;31", f"\n  ✗ ERROR: {e}"))

    def count_files(folder: Path) -> int:
        try:
            return sum(1 for x in folder.iterdir() if x.is_file())
        except Exception:
            return 0

    def status_line(*pairs):
        parts = [f"{name}:{count_files(folder)}" for name, folder in pairs]
        print(col("2;37", "  " + "   ".join(parts)))

    def files_in(folder: Path):
        return sorted(
            [p for p in folder.iterdir() if p.is_file()],
            key=lambda p: p.name.lower()
        )

    def select_file(folder: Path, label="file") -> Path | None:
        items = files_in(folder)
        if not items:
            warn(f"Tidak ada {label} di: {folder}")
            return None

        print(col("2;37", f"\n  Folder: {folder}"))
        for i, p in enumerate(items, 1):
            size = p.stat().st_size
            print(f"  {i}. {p.name}  ({size:,} byte)")
        print("  0. Batal")

        while True:
            raw = ask("Pilih file")
            try:
                n = int(raw)
            except ValueError:
                warn("Masukkan nomor file.")
                continue
            if n == 0:
                return None
            if 1 <= n <= len(items):
                return items[n - 1]
            warn("Nomor tidak tersedia.")

    def safe_output(folder: Path, filename: str) -> Path:
        """Never silently overwrite an existing user output."""
        target = folder / filename
        if not target.exists():
            return target

        stem = target.stem
        suffix = target.suffix
        n = 2
        while True:
            candidate = folder / f"{stem}_{n}{suffix}"
            if not candidate.exists():
                return candidate
            n += 1

    def output_name_from(srcp: Path, folder: Path, suffix_text: str = "",
                         extension: str | None = None) -> Path:
        ext = srcp.suffix if extension is None else extension
        name = f"{srcp.stem}{suffix_text}{ext}"
        return safe_output(folder, name)

    def banner():
        clear()
        print(col("1;36", r"""
  ███████╗██╗  ██╗██╗   ██╗██╗   ██╗
  ██╔════╝██║ ██╔╝██║   ██║╚██╗ ██╔╝
  ███████╗█████╔╝ ██║   ██║ ╚████╔╝
  ╚════██║██╔═██╗ ██║   ██║  ╚██╔╝
  ███████║██║  ██╗╚██████╔╝   ██║
  ╚══════╝╚═╝  ╚═╝ ╚═════╝    ╚═╝
          ██╗     ██╗   ██╗ █████╗
          ██║     ██║   ██║██╔══██╗
          ██║     ██║   ██║███████║
          ██║     ██║   ██║██╔══██║
          ███████╗╚██████╔╝██║  ██║
          ╚══════╝ ╚═════╝ ╚═╝  ╚═╝"""))
        print(col("2;37", "  Lua 5.3 Custom Bytecode Toolkit"))
        print(col("2;37", "  Compile • Decompile • Inspect • Edit • Validate"))
        print(col("2;37", "  " + line()))

    # ------------------------------------------------------------------
    # CORE
    # ------------------------------------------------------------------
    def compile_workspace():
        clear()
        title("COMPILE LUA → CUSTOM BYTECODE")
        status_line(("Input", WS["compile_in"]), ("Output", WS["compile_out"]))
        srcp = select_file(WS["compile_in"], "source Lua")
        if srcp is None:
            return

        outp = output_name_from(srcp, WS["compile_out"], "_custom", ".lua")
        info = compile_source(srcp, outp, luac)
        show(info)
        ok(f"Output: {outp}")
        pause()

    def restore_workspace():
        clear()
        title("RESTORE CUSTOM → STANDARD LUA 5.3")
        status_line(("Input", WS["restore_in"]), ("Output", WS["restore_out"]))
        srcp = select_file(WS["restore_in"], "custom bytecode")
        if srcp is None:
            return

        outp = output_name_from(srcp, WS["restore_out"], "_standard", ".luac")
        info = custom_to_standard_file(srcp, outp, source=None)
        show(info)
        ok(f"Output: {outp}")
        pause()

    # ------------------------------------------------------------------
    # DECOMPILE
    # ------------------------------------------------------------------
    def decompile_menu():
        while True:
            clear()
            title("DECOMPILE")
            print("  1. SKUY Compatible Decompile")
            print("  2. Native Source")
            print("  3. Rescue Decompile")
            print("  4. Native Disassembly + CFG")
            print("  5. SKUY Open")
            print("  0. Kembali")
            c = ask("Pilih")
            if c == "0":
                return

            try:
                if c == "1":
                    clear(); title("SKUY COMPATIBLE DECOMPILE")
                    status_line(("Input", WS["dec_skuy_in"]), ("Output", WS["dec_skuy_out"]))
                    srcp = select_file(WS["dec_skuy_in"], "custom bytecode")
                    if srcp is None:
                        continue
                    outp = output_name_from(srcp, WS["dec_skuy_out"], "_decompiled", ".lua")
                    info = decompile_file(
                        srcp, outp, luadec, unluac,
                        source=None, luac=luac,
                        engine="nadeem", nadeem_jar=nadeem_jar,
                    )
                    show(info)
                    ok(f"Output: {outp}")

                elif c == "2":
                    clear(); title("NATIVE SOURCE")
                    status_line(("Input", WS["dec_native_in"]), ("Output", WS["dec_native_out"]))
                    srcp = select_file(WS["dec_native_in"], "custom bytecode")
                    if srcp is None:
                        continue
                    outp = output_name_from(srcp, WS["dec_native_out"], "_native", ".lua")
                    info = native_pseudolua(srcp, outp)
                    show(info)
                    warn("Native Source masih pseudo-Lua; belum dijamin round-trip.")
                    ok(f"Output: {outp}")

                elif c == "3":
                    clear(); title("RESCUE DECOMPILE")
                    status_line(("Input", WS["dec_rescue_in"]), ("Output", WS["dec_rescue_out"]))
                    srcp = select_file(WS["dec_rescue_in"], "custom bytecode")
                    if srcp is None:
                        continue
                    outdir = safe_output(
                        WS["dec_rescue_out"],
                        f"{srcp.stem}_rescue"
                    )
                    outdir.mkdir(parents=True, exist_ok=True)
                    info = rescue_decompile(
                        srcp, outdir, nadeem_jar, unluac,
                        source=None, luac=luac, timeout_sec=20,
                    )
                    show(info)
                    ok(f"Output folder: {outdir}")

                elif c == "4":
                    clear(); title("NATIVE DISASSEMBLY + CFG")
                    status_line(("Input", WS["dec_disasm_in"]), ("Output", WS["dec_disasm_out"]))
                    srcp = select_file(WS["dec_disasm_in"], "custom bytecode")
                    if srcp is None:
                        continue
                    outp = output_name_from(srcp, WS["dec_disasm_out"], "_disasm", ".txt")
                    cfg = output_name_from(srcp, WS["dec_disasm_out"], "_cfg", ".json")
                    info = native_disassemble(srcp, outp, cfg)
                    show(info)
                    ok(f"Disassembly: {outp}")
                    ok(f"CFG: {cfg}")

                elif c == "5":
                    clear(); title("SKUY OPEN")
                    status_line(("Input", WS["dec_rj_in"]), ("Output", WS["dec_rj_out"]))
                    srcp = select_file(WS["dec_rj_in"], "RJTOOL / SKUY protected Lua")
                    if srcp is None:
                        continue

                    outp = output_name_from(
                        srcp, WS["dec_rj_out"], "_no_RJ", ".lua"
                    )
                    reportp = safe_output(
                        WS["dec_rj_out"],
                        f"{outp.stem}_report.json"
                    )

                    print(col("2;37", "\n  Membuka outer protection RJTOOL BYRJ6..."))
                    def _rj_progress(done, total, fnv_ok, chk_ok):
                        pct = done * 100.0 / total
                        print(
                            col(
                                "2;37",
                                f"  Chunk {done}/{total} ({pct:5.1f}%)  "
                                f"FNV:{fnv_ok}  CHECK:{chk_ok}"
                            )
                        )

                    info = skuy_open_file(
                        srcp, outp, reportp,
                        progress_cb=_rj_progress,
                    )

                    print()
                    print(f"  Profile      : {info['profile']['profile']}")
                    print(f"  Chunks       : {info['integrity']['chunk_count']}")
                    print(
                        f"  FNV          : "
                        f"{info['integrity']['fnv_pass']}/"
                        f"{info['integrity']['chunk_count']} PASS"
                    )
                    print(
                        f"  RJ Checksum  : "
                        f"{info['integrity']['checksum_pass']}/"
                        f"{info['integrity']['chunk_count']} PASS"
                    )
                    print(f"  Inner size   : {info['output']['size']:,} byte")
                    print(f"  Inner SHA256 : {info['output']['sha256']}")
                    print(
                        f"  Parse end    : "
                        f"{info['inner']['parse_end']:,}"
                    )
                    print(f"  Trailing     : {info['inner']['trailing']}")
                    ok(f"Inner custom Lua: {outp}")
                    ok(f"Report: {reportp}")

                else:
                    warn("Pilihan tidak tersedia.")
                pause()

            except Exception as e:
                err(e); pause()

    # ------------------------------------------------------------------
    # PROTECTION
    # ------------------------------------------------------------------
    def _paired_output(folder: Path, base_stem: str):
        n = 1
        while True:
            suffix = "" if n == 1 else f"_{n}"
            lua = folder / f"{base_stem}{suffix}.lua"
            report = folder / f"{base_stem}{suffix}_report.json"
            if not lua.exists() and not report.exists():
                return lua, report
            n += 1

    def protection_menu():
        while True:
            clear(); title("PROTECTION")
            print("  1. Source Protection")
            print("  2. SKUY Protect")
            print("  3. Full Protection")
            print("  0. Kembali")
            c = ask("Pilih")
            if c == "0": return
            try:
                if c == "1":
                    clear(); title("SOURCE PROTECTION")
                    status_line(("Input", WS["protect_source_in"]), ("Output", WS["protect_source_out"]))
                    srcp = select_file(WS["protect_source_in"], "source Lua")
                    if srcp is None: continue
                    outp, reportp = _paired_output(WS["protect_source_out"], f"{srcp.stem}_protected")
                    info = skuy_source_protect_file(srcp, outp, reportp, luac)
                    show(info); ok(f"Protected source: {outp}"); ok(f"Report: {reportp}")
                elif c == "2":
                    clear(); title("SKUY PROTECT")
                    status_line(("Input", WS["protect_skuy_in"]), ("Output", WS["protect_skuy_out"]))
                    srcp = select_file(WS["protect_skuy_in"], "custom bytecode")
                    if srcp is None: continue
                    outp, reportp = _paired_output(WS["protect_skuy_out"], f"{srcp.stem}_SKUY_PROTECTED")
                    def progress(done,total,fnv,chk):
                        pct=done*100.0/total
                        print(col("2;37",f"  Self-test {done}/{total} ({pct:5.1f}%) FNV:{fnv} CHECK:{chk}"))
                    info=skuy_protect_file(srcp,outp,reportp,luac,mode="direct",progress_cb=progress)
                    show(info); ok(f"SKUY protected: {outp}"); ok(f"Report: {reportp}")
                elif c == "3":
                    clear(); title("FULL PROTECTION")
                    status_line(("Input", WS["protect_full_in"]), ("Output", WS["protect_full_out"]))
                    print("  1. BALANCED"); print("  2. MAX"); print("  0. Kembali")
                    mode_raw=ask("Pilih")
                    if mode_raw=="0": continue
                    if mode_raw not in {"1","2"}: warn("Pilihan tidak tersedia."); pause(); continue
                    mode="bal" if mode_raw=="1" else "max"
                    suffix="_Bal" if mode=="bal" else "_max"
                    srcp=select_file(WS["protect_full_in"],"source Lua")
                    if srcp is None: continue
                    outp, reportp=_paired_output(WS["protect_full_out"],f"{srcp.stem}{suffix}")
                    with tempfile.TemporaryDirectory(prefix="skuy_full_protect_") as td:
                        td=Path(td); protected_source=td/"protected_source.lua"; source_report=td/"source_report.json"; inner=td/"inner_custom.lua"; outer_report=td/"outer_report.json"
                        print(col("2;37","\n  [1/4] Source Protection...")); source_info=skuy_source_protect_file(srcp,protected_source,source_report,luac)
                        print(col("2;37","  [2/4] Custom Compile...")); compile_info=compile_source(protected_source,inner,luac)
                        print(col("2;37","  [3/4] SKUY Protect + self-test..."))
                        def progress(done,total,fnv,chk):
                            pct=done*100.0/total; print(col("2;37",f"    {done}/{total} ({pct:5.1f}%) FNV:{fnv} CHECK:{chk}"))
                        outer_info=skuy_protect_file(inner,outp,outer_report,luac,mode=mode,progress_cb=progress)
                        print(col("2;37","  [4/4] Final verification PASS"))
                    full_report={"status":"VERIFIED","mode":"FULL PROTECTION","profile":"BALANCED" if mode=="bal" else "MAX","input":{"path":str(srcp),"size":srcp.stat().st_size,"sha256":hashlib.sha256(srcp.read_bytes()).hexdigest()},"source_protection":source_info,"custom_compile":compile_info,"skuy_protect":outer_info,"output":{"path":str(outp),"size":outp.stat().st_size,"sha256":hashlib.sha256(outp.read_bytes()).hexdigest()}}
                    reportp.write_text(json.dumps(full_report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
                    ok(f"FULL PROTECTED: {outp}"); ok(f"Report: {reportp}")
                else: warn("Pilihan tidak tersedia.")
                pause()
            except Exception as e:
                err(e); pause()

    # ------------------------------------------------------------------
    # BYTECODE EDITOR
    # ------------------------------------------------------------------
    def editor_menu():
        """SKUY Bytecode Editor.

        SAFE EDITOR:
          - Stable constant-level editing.
          - Uses exact constant matching + expect checks.
          - Rebuilds the custom bytecode and validates trailer/structure.

        FULL EDITABLE LUA:
          - Development path for whole-source recovery.
          - Falls back to Native Source when SKUY Compatible cannot finish.
        """

        def _exact_constant_matches(srcp: Path, old_text: str, category: str):
            report = inspect_constants(
                srcp,
                query=old_text,
                include_unreferenced=True,
                include_extra_proto=False,
            )

            rows = []
            for row in report.get("constants", []):
                value = row.get("value")
                typ = row.get("type")

                exact = (
                    str(value) == old_text
                    or row.get("display") == old_text
                )
                if not exact:
                    continue

                if category == "text" and typ not in {"string", "long_string"}:
                    continue
                if category == "numeric" and typ not in {"integer", "number"}:
                    continue

                rows.append(row)
            return rows

        def _pick_constant(rows):
            if not rows:
                warn("Constant yang cocok tidak ditemukan.")
                return None

            print()
            print(col("2;37", "  Kandidat constant:"))
            for i, row in enumerate(rows, 1):
                refs = row.get("reference_count", 0)
                print(
                    f"  {i}. {row['proto']}  K{row['index']}  "
                    f"[{row['type']}]  {row['display']}  refs:{refs}"
                )
            print("  0. Batal")

            while True:
                raw = ask("Pilih constant")
                try:
                    n = int(raw)
                except ValueError:
                    warn("Masukkan nomor.")
                    continue
                if n == 0:
                    return None
                if 1 <= n <= len(rows):
                    return rows[n - 1]
                warn("Nomor tidak tersedia.")

        def _text_rows(srcp: Path, query: str | None = None):
            report = inspect_constants(
                srcp,
                query=query,
                include_unreferenced=True,
                include_extra_proto=False,
            )
            rows = []
            for row in report.get("constants", []):
                if row.get("type") not in {"string", "long_string"}:
                    continue
                value = row.get("value")
                if not isinstance(value, str):
                    continue
                rows.append(row)
            return rows

        def _text_summary(row, max_width: int = 70):
            value = row.get("value") or ""
            first = value.split("\n", 1)[0].replace("\r", "")
            if len(first) > max_width:
                first = first[:max_width - 3] + "..."
            lines = value.count("\n") + 1
            size = len(value.encode("utf-8"))
            return f"{first!r}  [{lines} baris, {size} byte]"

        def _pick_text_constant(rows, page_size: int = 20):
            if not rows:
                warn("Teks yang cocok tidak ditemukan.")
                return None

            page = 0
            pages = max(1, (len(rows) + page_size - 1) // page_size)
            while True:
                start = page * page_size
                end = min(len(rows), start + page_size)
                print()
                print(col("2;37", f"  Hasil {start + 1}-{end} dari {len(rows)}"))
                for idx in range(start, end):
                    row = rows[idx]
                    print(
                        f"  {idx + 1}. {row['proto']} K{row['index']}  "
                        f"{_text_summary(row)}"
                    )
                print("  0. Batal")
                if pages > 1:
                    print("  n. Halaman berikutnya")
                    print("  p. Halaman sebelumnya")

                raw = ask("Pilih teks").lower()
                if raw == "0":
                    return None
                if raw == "n" and pages > 1:
                    if page + 1 < pages:
                        page += 1
                    else:
                        warn("Sudah halaman terakhir.")
                    continue
                if raw == "p" and pages > 1:
                    if page > 0:
                        page -= 1
                    else:
                        warn("Sudah halaman pertama.")
                    continue
                try:
                    n = int(raw)
                except ValueError:
                    warn("Masukkan nomor teks.")
                    continue
                if 1 <= n <= len(rows):
                    return rows[n - 1]
                warn("Nomor tidak tersedia.")

        def _show_full_text(row):
            value = row.get("value") or ""
            parts = value.split("\n")
            print()
            print(col("2;37", f"  {row['proto']} K{row['index']}"))
            print(col("2;37", f"  {len(parts)} baris, {len(value.encode('utf-8'))} byte"))
            print()
            for i, line_ in enumerate(parts, 1):
                shown = line_[:-1] if line_.endswith("\r") else line_
                print(f"  [{i}] {shown}")

        def _edit_text_lines(old_text: str) -> str:
            if "\r\n" in old_text and old_text.replace("\r\n", "").find("\n") < 0:
                sep = "\r\n"
            else:
                sep = "\n"
            parts = old_text.split(sep)
            new_parts = []

            print()
            print(col("2;37", "  Edit per baris. Enter tanpa mengetik = tetap."))
            for i, old_line in enumerate(parts, 1):
                print()
                print(col("2;37", f"  Baris {i} lama:"))
                print(f"  {old_line}")
                try:
                    raw = input(col("1;37", f"  Baris {i} baru [Enter = tetap]: "))
                except (EOFError, KeyboardInterrupt):
                    raw = ""
                new_parts.append(old_line if raw == "" else raw)
            return sep.join(new_parts)

        def _confirm_yes(prompt: str) -> bool:
            try:
                raw = input(col("1;37", f"  {prompt} [Y/n]: ")).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return False
            return raw in {"", "y", "yes", "ya"}

        def _preview_text_change(old_text: str, new_text: str):
            old_lines = old_text.count("\n") + 1
            new_lines = new_text.count("\n") + 1
            old_bytes = len(old_text.encode("utf-8"))
            new_bytes = len(new_text.encode("utf-8"))
            print()
            print(col("2;37", "  PREVIEW"))
            print(f"  Baris lama : {old_lines}")
            print(f"  Baris baru : {new_lines}")
            print(f"  Ukuran lama: {old_bytes} byte")
            print(f"  Ukuran baru: {new_bytes} byte")
            print()
            for i, line_ in enumerate(new_text.split("\n"), 1):
                print(f"  [{i}] {line_}")
            return old_bytes, new_bytes

        def _save_verified_temp(temp_path: Path, srcp: Path, suffix: str):
            outp = output_name_from(srcp, WS["editor_out"], suffix, ".lua")
            shutil.copy2(temp_path, outp)
            ok(f"Custom Bytecode: {outp}")
            return outp

        def _fallback_builtin_text(srcp: Path, picked: dict, new_text: str,
                                   old_brand: str) -> bool:
            print()
            warn("Metode ORIGINAL gagal atau tidak didukung untuk file ini.")
            if not _confirm_yes("Coba metode bawaan tool?"):
                warn("Dibatalkan. File asli tidak berubah.")
                return False

            with tempfile.TemporaryDirectory(prefix="skuylua_cosmetic_fallback_") as td:
                tmp = Path(td) / "fallback.lua"
                info = patch_constant(
                    srcp,
                    tmp,
                    proto_path=picked["proto"],
                    index=picked["index"],
                    value_text=new_text,
                    type_name="auto",
                    expect=str(picked["value"]),
                )
                raw = tmp.read_bytes()
                _, _, end = parse_custom_chunk(raw)
                new_brand = trailer_brand(raw, end)

                print()
                ok("Hasil metode bawaan tool VALID.")
                print(f"  INPUT  : {old_brand}")
                print(f"  OUTPUT : {new_brand}")
                if new_brand != old_brand:
                    warn("BRAND / FORMAT BERUBAH.")

                if not _confirm_yes("Simpan hasil ini?"):
                    warn("Hasil tidak disimpan. File asli tetap aman.")
                    return False
                _save_verified_temp(tmp, srcp, "_cosmetic_rebuilt")
                return True

        def _apply_cosmetic_change(srcp: Path, picked: dict, new_text: str,
                                   force_rebuild: bool = False):
            old_text = str(picked["value"])
            old_bytes, new_bytes = _preview_text_change(old_text, new_text)
            if old_text == new_text:
                warn("Tidak ada perubahan.")
                return

            raw_in = srcp.read_bytes()
            _, _, input_end = parse_custom_chunk(raw_in)
            input_brand = trailer_brand(raw_in, input_end)

            if not force_rebuild and old_bytes == new_bytes:
                print()
                print(col("1;32", "  Metode: FIXED LENGTH / ORIGINAL"))
                print("  Struktur file akan dipertahankan.")
                if not _confirm_yes("Lanjut?"):
                    warn("Dibatalkan.")
                    return

                with tempfile.TemporaryDirectory(prefix="skuylua_cosmetic_fixed_") as td:
                    tmp = Path(td) / "fixed.lua"
                    try:
                        info = patch_text_constant_fixed_in_place(
                            srcp,
                            tmp,
                            proto_path=picked["proto"],
                            index=picked["index"],
                            new_text=new_text,
                            expect=old_text,
                        )
                    except Exception as e:
                        err(e)
                        _fallback_builtin_text(srcp, picked, new_text, input_brand)
                        return

                    print()
                    ok("Patch berhasil dan hasil sudah diverifikasi.")
                    print(f"  INPUT  : {input_brand}")
                    print(f"  OUTPUT : {info.get('brand', 'UNKNOWN')}")
                    print(f"  Ukuran : {info['old_file_size']} → {info['new_file_size']} byte")
                    if not _confirm_yes("Simpan hasil?"):
                        warn("Hasil tidak disimpan. File asli tetap aman.")
                        return
                    _save_verified_temp(tmp, srcp, "_cosmetic_edited")
                return

            print()
            print(col("1;33", "  Metode: REBUILD BYTECODE"))
            print("  Teks baru berbeda panjang dari teks lama.")
            if not _confirm_yes("Lanjut?"):
                warn("Dibatalkan.")
                return

            with tempfile.TemporaryDirectory(prefix="skuylua_cosmetic_original_") as td:
                tmp = Path(td) / "original.lua"
                try:
                    info = rebuild_text_constant_original(
                        srcp,
                        tmp,
                        proto_path=picked["proto"],
                        index=picked["index"],
                        new_text=new_text,
                        expect=old_text,
                    )
                except Exception as e:
                    warn(f"Metode ORIGINAL gagal: {e}")
                    _fallback_builtin_text(srcp, picked, new_text, input_brand)
                    return

                print()
                ok("Rebuild ORIGINAL berhasil dan VALID.")
                print(f"  INPUT  : {input_brand}")
                print(f"  OUTPUT : {info.get('brand', 'UNKNOWN')}")
                print(f"  Ukuran : {info['old_file_size']} → {info['new_file_size']} byte")
                if not _confirm_yes("Simpan hasil?"):
                    warn("Hasil tidak disimpan. File asli tetap aman.")
                    return
                _save_verified_temp(tmp, srcp, "_cosmetic_rebuilt")

        def _cosmetic_pick_by_search(srcp: Path):
            print()
            q = ask("Kata pencarian")
            if not q:
                warn("Kata pencarian tidak boleh kosong.")
                return None
            rows = _text_rows(srcp, q)
            return _pick_text_constant(rows)

        def _cosmetic_edit_selected(srcp: Path, picked: dict,
                                    force_rebuild: bool = False):
            _show_full_text(picked)
            new_text = _edit_text_lines(str(picked["value"]))
            _apply_cosmetic_change(srcp, picked, new_text, force_rebuild=force_rebuild)

        def _cosmetic_menu():
            srcp = select_file(WS["editor_in"], "bytecode")
            if srcp is None:
                return

            while True:
                clear()
                title("COSMETIC / TEXT")
                print(f"  File: {srcp.name}")
                print()
                print("  1. Cari & Edit Teks")
                print("  2. Lihat Semua Teks")
                print("  3. Edit Beda Panjang")
                print("  0. Kembali")
                c = ask("Pilih")
                if c == "0":
                    return

                try:
                    if c == "1":
                        picked = _cosmetic_pick_by_search(srcp)
                        if picked is not None:
                            _cosmetic_edit_selected(srcp, picked, force_rebuild=False)
                    elif c == "2":
                        rows = _text_rows(srcp, None)
                        picked = _pick_text_constant(rows)
                        if picked is not None:
                            _cosmetic_edit_selected(srcp, picked, force_rebuild=False)
                    elif c == "3":
                        print()
                        print(col("2;37", "  Cari teks yang akan diedit."))
                        picked = _cosmetic_pick_by_search(srcp)
                        if picked is not None:
                            _cosmetic_edit_selected(srcp, picked, force_rebuild=True)
                    else:
                        warn("Pilihan tidak tersedia.")
                except Exception as e:
                    err(e)
                pause()

        def _safe_edit_session(category: str, title_text: str):
            clear()
            title(title_text)
            status_line(
                ("Input", WS["editor_in"]),
                ("Edit", WS["editor_edit"]),
                ("Output", WS["editor_out"]),
            )

            srcp = select_file(WS["editor_in"], "bytecode")
            if srcp is None:
                return

            patches = []

            while True:
                print()
                if category == "time":
                    print(col(
                        "2;37",
                        "  Contoh nilai lama: 2026, 8, 31, 23, 59, atau string tanggal."
                    ))
                elif category == "text":
                    print(col(
                        "2;37",
                        "  Masukkan teks lama persis seperti yang ada di bytecode."
                    ))
                else:
                    print(col(
                        "2;37",
                        "  Masukkan angka lama persis seperti nilai constant."
                    ))

                old_text = ask("Nilai lama")
                if not old_text:
                    warn("Nilai lama tidak boleh kosong.")
                    continue

                filter_category = (
                    "text" if category == "text"
                    else "numeric" if category == "numeric"
                    else "all"
                )

                rows = _exact_constant_matches(
                    srcp,
                    old_text,
                    "text" if filter_category == "text"
                    else "numeric" if filter_category == "numeric"
                    else "all",
                )

                picked = _pick_constant(rows)
                if picked is None:
                    again = ask("Cari nilai lain? [y/N]", optional=True).lower()
                    if again == "y":
                        continue
                    break

                new_text = ask("Nilai baru")

                patch_type = "auto"
                if picked["type"] in {"string", "long_string"}:
                    patch_type = "auto"
                elif picked["type"] in {"integer", "number"}:
                    patch_type = "auto"
                elif picked["type"] == "boolean":
                    patch_type = "auto"

                patches.append({
                    "proto": picked["proto"],
                    "index": picked["index"],
                    "type": patch_type,
                    "value": new_text,
                    "expect": str(picked["value"]),
                })

                ok(
                    f"Ditambahkan: {picked['proto']} K{picked['index']} "
                    f"{picked['display']} → {new_text}"
                )

                more = ask("Tambah edit lain? [y/N]", optional=True).lower()
                if more != "y":
                    break

            if not patches:
                warn("Tidak ada perubahan yang diterapkan.")
                return

            plan_name = f"{srcp.stem}_safe_edit_plan.json"
            plan_path = safe_output(WS["editor_edit"], plan_name)
            plan_doc = {
                "brand": "SKUY Lua",
                "mode": "safe_constant_editor",
                "source": str(srcp),
                "patches": patches,
            }
            plan_path.write_text(
                json.dumps(plan_doc, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

            outp = output_name_from(
                srcp,
                WS["editor_out"],
                "_safe_edited",
                ".lua",
            )

            info = apply_patch_plan(srcp, outp, plan_path)
            show(info)
            ok(f"Patch plan: {plan_path}")
            ok(f"Custom Bytecode: {outp}")

        def safe_editor_menu():
            while True:
                clear()
                title("SAFE EDITOR")
                status_line(
                    ("Input", WS["editor_in"]),
                    ("Edit", WS["editor_edit"]),
                    ("Output", WS["editor_out"]),
                )
                print()
                print("  1. Time / Expired")
                print("  2. Cosmetic / Text")
                print("  3. Numeric Config")
                print("  0. Kembali")
                c = ask("Pilih")
                if c == "0":
                    return

                try:
                    if c == "1":
                        _safe_edit_session(
                            "time",
                            "SAFE EDITOR - TIME / EXPIRED",
                        )
                    elif c == "2":
                        _cosmetic_menu()
                    elif c == "3":
                        _safe_edit_session(
                            "numeric",
                            "SAFE EDITOR - NUMERIC CONFIG",
                        )
                    else:
                        warn("Pilihan tidak tersedia.")
                    pause()
                except Exception as e:
                    err(e)
                    pause()

        def full_editable_menu():
            while True:
                clear()
                title("FULL EDITABLE LUA - DEVELOPMENT")
                status_line(
                    ("Input", WS["editor_in"]),
                    ("Edit", WS["editor_edit"]),
                    ("Output", WS["editor_out"]),
                )
                print()
                print("  1. Make Bytecode → Editable")
                print("  2. Make Editable → Bytecode")
                print("  0. Kembali")
                c = ask("Pilih")
                if c == "0":
                    return

                try:
                    if c == "1":
                        clear()
                        title("MAKE BYTECODE → EDITABLE")
                        status_line(
                            ("Input", WS["editor_in"]),
                            ("Edit", WS["editor_edit"]),
                        )

                        srcp = select_file(WS["editor_in"], "bytecode")
                        if srcp is None:
                            continue

                        outp = output_name_from(
                            srcp,
                            WS["editor_edit"],
                            "_editable",
                            ".lua",
                        )

                        mode_used = None
                        syntax_ready = False
                        syntax_message = ""

                        try:
                            info = decompile_file(
                                srcp,
                                outp,
                                luadec,
                                unluac,
                                source=None,
                                luac=luac,
                                engine="nadeem",
                                nadeem_jar=nadeem_jar,
                            )
                            mode_used = "SKUY Compatible"
                            show(info)
                        except Exception as first_error:
                            warn(
                                f"SKUY Compatible tidak selesai: {first_error}"
                            )
                            warn("Mencoba Native Source...")
                            info = native_pseudolua(srcp, outp)
                            mode_used = "Native Source"
                            show(info)

                        try:
                            candidate = outp.read_text(
                                encoding="utf-8",
                                errors="replace",
                            )
                            syntax_ready, syntax_message = _syntax_check_lua(
                                candidate,
                                luac,
                            )
                        except Exception as syntax_error:
                            syntax_ready = False
                            syntax_message = str(syntax_error)

                        meta = {
                            "brand": "SKUY Lua",
                            "source_bytecode": str(srcp),
                            "editable_file": str(outp),
                            "mode_used": mode_used,
                            "syntax_ready": syntax_ready,
                            "syntax_message": syntax_message,
                            "build_status": (
                                "READY"
                                if syntax_ready
                                else "INSPECT_ONLY"
                            ),
                        }
                        meta_path = outp.with_suffix(
                            outp.suffix + ".skuy.json"
                        )
                        meta_path.write_text(
                            json.dumps(
                                meta,
                                indent=2,
                                ensure_ascii=False,
                            ),
                            encoding="utf-8",
                        )

                        ok(f"Editable Lua: {outp}")
                        ok(f"Metadata: {meta_path}")

                        if syntax_ready:
                            ok("STATUS: READY - luac syntax check lolos.")
                        else:
                            warn(
                                "STATUS: INSPECT_ONLY - belum valid Lua penuh."
                            )
                            if syntax_message:
                                warn(f"Syntax: {syntax_message}")

                    elif c == "2":
                        clear()
                        title("MAKE EDITABLE → BYTECODE")
                        status_line(
                            ("Edit", WS["editor_edit"]),
                            ("Output", WS["editor_out"]),
                        )

                        edit_files = [
                            p for p in files_in(WS["editor_edit"])
                            if p.suffix.lower() == ".lua"
                        ]
                        if not edit_files:
                            warn(
                                f"Tidak ada editable Lua di: "
                                f"{WS['editor_edit']}"
                            )
                            pause()
                            continue

                        print(
                            col(
                                "2;37",
                                f"\n  Folder: {WS['editor_edit']}",
                            )
                        )
                        for i, p in enumerate(edit_files, 1):
                            meta_path = p.with_suffix(
                                p.suffix + ".skuy.json"
                            )
                            status = "UNKNOWN"
                            if meta_path.exists():
                                try:
                                    meta = json.loads(
                                        meta_path.read_text(
                                            encoding="utf-8"
                                        )
                                    )
                                    status = meta.get(
                                        "build_status",
                                        "UNKNOWN",
                                    )
                                except Exception:
                                    pass
                            print(
                                f"  {i}. {p.name}  "
                                f"({p.stat().st_size:,} byte) "
                                f"[{status}]"
                            )
                        print("  0. Batal")

                        srcp = None
                        while True:
                            raw = ask("Pilih file")
                            try:
                                n = int(raw)
                            except ValueError:
                                warn("Masukkan nomor file.")
                                continue
                            if n == 0:
                                break
                            if 1 <= n <= len(edit_files):
                                srcp = edit_files[n - 1]
                                break
                            warn("Nomor tidak tersedia.")

                        if srcp is None:
                            continue

                        candidate = srcp.read_text(
                            encoding="utf-8",
                            errors="replace",
                        )
                        syntax_ok, syntax_msg = _syntax_check_lua(
                            candidate,
                            luac,
                        )

                        if not syntax_ok:
                            warn(
                                "File belum valid Lua dan tidak akan "
                                "dipaksa menjadi bytecode."
                            )
                            warn(f"Syntax: {syntax_msg}")
                            pause()
                            continue

                        outp = output_name_from(
                            srcp,
                            WS["editor_out"],
                            "_bytecode",
                            ".lua",
                        )
                        info = compile_source(srcp, outp, luac)
                        show(info)
                        ok(f"Custom Bytecode: {outp}")

                    else:
                        warn("Pilihan tidak tersedia.")

                    pause()

                except Exception as e:
                    err(e)
                    pause()

        while True:
            clear()
            title("BYTECODE EDITOR")
            status_line(
                ("Input", WS["editor_in"]),
                ("Edit", WS["editor_edit"]),
                ("Output", WS["editor_out"]),
            )
            print()
            print("  1. Safe Editor")
            print("  2. Full Editable Lua")
            print("  0. Kembali")
            c = ask("Pilih")

            if c == "0":
                return
            elif c == "1":
                safe_editor_menu()
            elif c == "2":
                full_editable_menu()
            else:
                warn("Pilihan tidak tersedia.")
                pause()

    # ------------------------------------------------------------------
    # ANALYZE
    # ------------------------------------------------------------------
    def analysis_menu():
        while True:
            clear()
            title("ANALYZE")
            status_line(("Input", WS["analyze_in"]), ("Output", WS["analyze_out"]))
            print()
            print("  1. Analyze Custom Bytecode")
            print("  2. Constant Context Report")
            print("  3. Value-Flow Report")
            print("  4. Native Disassembly Report")
            print("  5. Compare Dua File")
            print("  0. Kembali")
            c = ask("Pilih")
            if c == "0":
                return

            try:
                if c == "1":
                    srcp = select_file(WS["analyze_in"], "bytecode")
                    if srcp is None:
                        continue
                    report = analyze_file(srcp)
                    outp = output_name_from(srcp, WS["analyze_out"], "_analyze", ".json")
                    outp.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
                    show(report)
                    ok(f"Report: {outp}")

                elif c == "2":
                    srcp = select_file(WS["analyze_in"], "bytecode")
                    if srcp is None:
                        continue
                    q = ask("Query", optional=True) or None
                    outp = output_name_from(srcp, WS["analyze_out"], "_constant_context", ".json")
                    show(write_constant_context_report(srcp, outp, query=q, window=6))
                    ok(f"Report: {outp}")

                elif c == "3":
                    srcp = select_file(WS["analyze_in"], "bytecode")
                    if srcp is None:
                        continue
                    q = ask("Query", optional=True) or None
                    outp = output_name_from(srcp, WS["analyze_out"], "_value_flow", ".json")
                    show(write_value_flow_report(
                        srcp, outp, query=q,
                        window=6, max_steps=120, max_depth=16,
                    ))
                    ok(f"Report: {outp}")

                elif c == "4":
                    srcp = select_file(WS["analyze_in"], "bytecode")
                    if srcp is None:
                        continue
                    outp = output_name_from(srcp, WS["analyze_out"], "_disasm", ".txt")
                    cfg = output_name_from(srcp, WS["analyze_out"], "_cfg", ".json")
                    show(native_disassemble(srcp, outp, cfg))
                    ok(f"Disassembly: {outp}")
                    ok(f"CFG: {cfg}")

                elif c == "5":
                    a = select_file(WS["analyze_in"], "file A")
                    if a is None:
                        continue
                    b = select_file(WS["analyze_in"], "file B")
                    if b is None:
                        continue
                    report = compare_files(a, b)
                    outp = safe_output(
                        WS["analyze_out"],
                        f"compare_{a.stem}_VS_{b.stem}.json"
                    )
                    outp.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
                    show(report)
                    ok(f"Report: {outp}")

                else:
                    warn("Pilihan tidak tersedia.")

                pause()

            except Exception as e:
                err(e); pause()

    # ------------------------------------------------------------------
    # MAIN
    # ------------------------------------------------------------------
    while True:
        banner()
        print(col("1;37", "  [ CORE ]"))
        print("  1. Compile Lua - Custom Bytecode")
        print("  2. Restore Custom - Standard Lua 5.3")
        print("  3. Decompile")
        print()
        print(col("1;37", "  [ PROTECTION ]"))
        print("  4. Protection")
        print()
        print(col("1;37", "  [ EDIT ]"))
        print("  5. Bytecode Editor")
        print()
        print(col("1;37", "  [ TOOLS ]"))
        print("  6. Analyze")
        print("  0. Exit")
        print(col("2;37", "  " + line()))

        choice = ask("Pilih menu")

        try:
            if choice == "0":
                clear()
                print(col("1;36", "\n  SKUY ditutup.\n"))
                return
            elif choice == "1":
                compile_workspace()
            elif choice == "2":
                restore_workspace()
            elif choice == "3":
                decompile_menu()
            elif choice == "4":
                protection_menu()
            elif choice == "5":
                editor_menu()
            elif choice == "6":
                analysis_menu()
            else:
                warn("Pilihan tidak tersedia.")
                pause()

        except KeyboardInterrupt:
            warn("Dibatalkan.")
            pause()
        except Exception as e:
            err(e)
            pause()




# ============================================================================
# SKUY MASTER HANDOFF EXTENSIONS (2026-09-14)
# License / ALONE / ZAKPUBG knowledge accumulated during joint Lua analysis.
# This section is intentionally self-contained and uses the parser above.
# ============================================================================

MASTER_TOOL_VERSION = "2026.09.14"
MASTER_XOR_KEY_HEX = "112136474657a78d9d8490d8ab008c35261af7e45805b8b31507d02c1e8ff6c8"
ZAKPUBG_PREFIX = "ZAKPUBG"
ZAKPUBG_SECRET_2026 = "ZakPubgSkin_2026_VIP_SECRET_KEY_12345"

# Known license families seen during the project.  These are *detection aids*,
# not assumptions that every file uses the same family.
KNOWN_LICENSE_MARKERS = (
    "ZakPubgSkin", "ZAKPUBG", "SECRET_KEY_", "KEY_EXPIRY_TIMESTAMP",
    "KEY_VALIDATED", "LicenseDeviceCache", "ALONE_OWNER1_license.txt",
    "SIGNATURE|EXPIRY|ACTIVATION|NAME", "1 Key = 1 Device",
    "VIP_", "ALONE", "ZAKPUBGSKIN",
)


def _master_walk(p: Proto, path: str = "root"):
    yield path, p
    for i, ch in enumerate(p.children):
        yield from _master_walk(ch, f"{path}.{i}")


def _master_decode_string(v) -> str | None:
    if isinstance(v, bytes):
        return v.decode("utf-8", errors="replace")
    if isinstance(v, str):
        return v
    return None


def master_extract_strings(inp: Path, query: str | None = None,
                           min_len: int = 1, unique: bool = True) -> list[dict]:
    """Extract decoded string constants from custom Lua 5.3 chunks."""
    data = inp.read_bytes()
    _, root, parse_end = parse_custom_chunk(data)
    q = query.lower() if query else None
    rows = []
    seen = set()
    for path, p in _master_walk(root):
        for idx, c in enumerate(p.constants):
            s = _master_decode_string(c.value)
            if s is None or len(s) < min_len:
                continue
            if q and q not in s.lower():
                continue
            if unique and s in seen:
                continue
            seen.add(s)
            rows.append({"proto": path, "index": idx, "tag": c.tag, "value": s})
    return rows


def _master_all_numbers(inp: Path) -> list[dict]:
    data = inp.read_bytes()
    _, root, _ = parse_custom_chunk(data)
    rows=[]
    for path,p in _master_walk(root):
        for idx,c in enumerate(p.constants):
            if isinstance(c.value, bool) or c.value is None:
                continue
            if isinstance(c.value, (int,float)):
                rows.append({"proto":path,"index":idx,"value":c.value,"tag":c.tag})
    return rows


def master_djb2_32(text_or_bytes) -> int:
    b = text_or_bytes.encode("utf-8") if isinstance(text_or_bytes, str) else bytes(text_or_bytes)
    h = 5381
    for x in b:
        h = ((h * 33) + x) & 0xFFFFFFFF
    return h


def master_zak_signature(expiry: int,
                         secret: str = ZAKPUBG_SECRET_2026,
                         prefix: str = ZAKPUBG_PREFIX) -> str:
    material = f"{prefix}{int(expiry)}{secret}"
    return f"{master_djb2_32(material):08X}"


def master_zak_make(expiry: int, activation: int, name: str,
                    secret: str = ZAKPUBG_SECRET_2026,
                    prefix: str = ZAKPUBG_PREFIX) -> str:
    sig = master_zak_signature(expiry, secret=secret, prefix=prefix)
    return f"{sig}|{int(expiry)}|{int(activation)}|{name}"


def master_zak_parse(key: str, secret: str = ZAKPUBG_SECRET_2026,
                     prefix: str = ZAKPUBG_PREFIX) -> dict:
    parts = key.strip().split("|")
    if len(parts) != 4:
        return {"family":"ZAKPUBG_FULL", "valid_format":False,
                "error":"expected SIGNATURE|EXPIRY|ACTIVATION|NAME"}
    sig, exp_s, act_s, name = parts
    try:
        expiry=int(exp_s); activation=int(act_s)
    except ValueError:
        return {"family":"ZAKPUBG_FULL", "valid_format":False,
                "error":"expiry/activation must be integers"}
    expected=master_zak_signature(expiry, secret=secret, prefix=prefix)
    from datetime import datetime, timezone, timedelta
    wib=timezone(timedelta(hours=7))
    def dt(v):
        try: return datetime.fromtimestamp(v,wib).strftime("%Y-%m-%d %H:%M:%S WIB")
        except Exception: return None
    return {
        "family":"ZAKPUBG_FULL",
        "valid_format":True,
        "signature":sig.upper(),
        "expected_signature":expected,
        "signature_valid":sig.upper()==expected,
        "expiry":expiry,
        "expiry_wib":dt(expiry),
        "activation":activation,
        "activation_wib":dt(activation),
        "duration_seconds":expiry-activation,
        "duration_days":(expiry-activation)/86400.0,
        "name":name,
        "prefix":prefix,
        "secret":secret,
    }


def master_alone_short_signature(license_key: str, expiry: int, max_devices: int,
                                 secret: str = ZAKPUBG_SECRET_2026) -> str:
    """Older ALONE 4-hex family: KEY|EXPIRY|MAXDEV|SIG4."""
    material=f"{license_key}|{int(expiry)}|{int(max_devices)}|{secret}"
    h=master_djb2_32(material)
    h2=(h*31)&0xFFFFFFFF
    combined=f"{h:08X}{h2:08X}"
    return combined[:4]


def master_alone_short_make(license_key: str, expiry: int, max_devices: int,
                            secret: str = ZAKPUBG_SECRET_2026) -> str:
    sig=master_alone_short_signature(license_key,expiry,max_devices,secret)
    return f"{license_key}|{int(expiry)}|{int(max_devices)}|{sig}"


def master_alone_short_parse(key: str, secret: str = ZAKPUBG_SECRET_2026) -> dict:
    parts=key.strip().split("|")
    if len(parts)!=4:
        return {"family":"ALONE_SHORT4","valid_format":False,
                "error":"expected LICENSEKEY|EXPIRY|MAXDEVICES|SIG4"}
    license_key, exp_s, dev_s, sig=parts
    try:
        expiry=int(exp_s); max_devices=int(dev_s)
    except ValueError:
        return {"family":"ALONE_SHORT4","valid_format":False,
                "error":"expiry/max_devices must be integers"}
    expected=master_alone_short_signature(license_key,expiry,max_devices,secret)
    return {"family":"ALONE_SHORT4","valid_format":True,
            "license_key":license_key,"expiry":expiry,"max_devices":max_devices,
            "signature":sig.upper(),"expected_signature":expected,
            "signature_valid":sig.upper()==expected,
            "secret":secret}


def master_parse_license_key(key: str, secret: str = ZAKPUBG_SECRET_2026) -> dict:
    """Auto-detect the two known local license formats."""
    p=key.strip().split("|")
    if len(p)==4 and len(p[0])==8:
        try:
            int(p[0],16); int(p[1]); int(p[2])
            return master_zak_parse(key,secret=secret)
        except Exception:
            pass
    # Short-family usually starts with a human-readable key and ends 4 hex.
    if len(p)==4:
        try:
            int(p[1]); int(p[2]); int(p[3],16)
            return master_alone_short_parse(key,secret=secret)
        except Exception:
            pass
    return {"family":"UNKNOWN","valid_format":False,"raw":key}


def master_license_scan(inp: Path) -> dict:
    """Deep-but-conservative scan for ALONE/ZAKPUBG/local-license evidence."""
    data=inp.read_bytes()
    h,root,parse_end=parse_custom_chunk(data)
    strings=master_extract_strings(inp,unique=True)
    string_values=[r["value"] for r in strings]
    hits=[]
    for marker in KNOWN_LICENSE_MARKERS:
        matches=[r for r in strings if marker.lower() in r["value"].lower()]
        if matches:
            hits.append({"marker":marker,"count":len(matches),"examples":matches[:8]})
    # Key-shaped constants and timestamp candidates are intentionally heuristic.
    import re
    keylike=[]
    rx_full=re.compile(r"^[0-9A-Fa-f]{8}\|\d{9,12}\|\d{9,12}\|[^|\r\n]+$")
    rx_short=re.compile(r"^[^|\r\n]{3,80}\|\d{9,12}\|\d{1,6}\|[0-9A-Fa-f]{4}$")
    for r in strings:
        s=r["value"].strip()
        if rx_full.match(s) or rx_short.match(s):
            row=dict(r); row["parsed_key"]=master_parse_license_key(s)
            keylike.append(row)
    nums=_master_all_numbers(inp)
    plausible=[]
    for n in nums:
        v=n["value"]
        if isinstance(v,int) and 1500000000 <= v <= 2200000000:
            plausible.append(n)
    tr=validate_trailer_compatible(data,parse_end)
    return {
        "tool":"SKUY Lua Master Parser",
        "version":MASTER_TOOL_VERSION,
        "file":str(inp),
        "size":len(data),
        "parse_end":parse_end,
        "trailing_bytes":len(data)-parse_end,
        "header":{**{k:v for k,v in h.__dict__.items() if k != "raw"}, "raw_hex":h.raw.hex()},
        "stats":stats(root),
        "trailer":tr,
        "marker_hits":hits,
        "embedded_license_keys":keylike,
        "plausible_unix_constants":plausible[:300],
        "known_families":{
            "ZAKPUBG_FULL":"SIGNATURE|EXPIRY|ACTIVATION|NAME; signature=DJB2(prefix+expiry+secret), 8 hex",
            "ALONE_SHORT4":"LICENSEKEY|EXPIRY|MAXDEVICES|SIG4; DJB2 + secondary h*31 formatter, first 4 hex",
        },
    }


def master_repair_trailer_crc_bytes(data: bytes) -> tuple[bytes,dict]:
    """Repair known 273-byte custom-family CRC fields without changing size."""
    import zlib
    try:
        _,_,parse_end=parse_custom_chunk(data)
    except Exception as e:
        return data,{"changed":False,"reason":f"parse failed: {e}"}
    if len(data)-parse_end < 0xBD:
        return data,{"changed":False,"reason":"known trailer not present","parse_end":parse_end}
    b=bytearray(data)
    c1=parse_end+0x4F; c2=parse_end+0xB9
    if c2+4>len(b):
        return data,{"changed":False,"reason":"trailer too short","parse_end":parse_end}
    old1=struct.unpack("<I",b[c1:c1+4])[0]
    old2=struct.unpack("<I",b[c2:c2+4])[0]
    crc1=zlib.crc32(b[:parse_end+59])&0xFFFFFFFF
    b[c1:c1+4]=struct.pack("<I",crc1)
    crc2=zlib.crc32(b[:parse_end+143])&0xFFFFFFFF
    b[c2:c2+4]=struct.pack("<I",crc2)
    return bytes(b),{"changed":old1!=crc1 or old2!=crc2,"parse_end":parse_end,
                     "crc1_old":f"{old1:08X}","crc1_new":f"{crc1:08X}",
                     "crc2_old":f"{old2:08X}","crc2_new":f"{crc2:08X}"}


def master_repair_trailer_crc_file(inp: Path,out: Path) -> dict:
    original=inp.read_bytes(); fixed,report=master_repair_trailer_crc_bytes(original)
    out.write_bytes(fixed)
    report.update({"input":str(inp),"output":str(out),"size":len(fixed),"same_size":len(fixed)==len(original)})
    return report


def master_known_project_notes() -> dict:
    """Machine-readable handoff constants for future analysis sessions."""
    return {
      "custom_lua":{
        "version":"Lua 5.3",
        "common_int_size":4,"common_size_t":4,
        "xor_string_key_hex":MASTER_XOR_KEY_HEX,
        "opcode_permutation":"std 0..12 -> custom 17..29; std 13..29 -> custom 0..16; std 30..46 unchanged",
        "custom_debug":"byte lineinfo + abslineinfo + locvars + upvalue names",
        "known_trailer_bytes":273,
        "crc_fields":{"C1_offset":"parse_end+0x4F","C1_input_end":"parse_end+59",
                      "C5_offset":"parse_end+0xB9","C5_input_end":"parse_end+143"},
      },
      "zakpubg":{
        "prefix":ZAKPUBG_PREFIX,"secret":ZAKPUBG_SECRET_2026,
        "format":"SIGNATURE|EXPIRY|ACTIVATION|NAME",
        "example_current":"BFC4303E|1789484764|1789398364|ALONE1DAYS",
        "example_older":"3D98B4BA|1789288506|1789202106|ZAKPUBGSKIN",
        "known_generated_2027":"D413B9A8|1820824506|1789202106|ZAKPUBGSKIN",
      },
      "alone_short":{
        "format":"LICENSEKEY|EXPIRY|MAXDEVICES|SIG4",
        "example":"ZAK-DFSXR-NYGQI|1789216611|500|FC9A",
      }
    }


# Mbohen/FVIP recovery learned from prior project.
MBOHEN_FVIP_KEY_BYTES = b"Fe3llzG@t3K3y#20"
MBOHEN_DELTA = 0x9E3779B9
MBOHEN_MASK = 0xFFFFFFFF

def _mbohen_mx(z, y, sum_, p, e, key_words):
    a = (((z >> 5) ^ ((y << 2) & MBOHEN_MASK)) +
         ((y >> 3) ^ ((z << 4) & MBOHEN_MASK))) & MBOHEN_MASK
    b = ((sum_ ^ y) + (key_words[(p & 3) ^ e] ^ z)) & MBOHEN_MASK
    return (a ^ b) & MBOHEN_MASK

def master_mbohen_fvip_decrypt(data: bytes, key_bytes: bytes = MBOHEN_FVIP_KEY_BYTES) -> bytes:
    if len(key_bytes) != 16:
        raise ValueError("Mbohen FVIP key must be exactly 16 bytes")
    key_words=[int.from_bytes(key_bytes[i:i+4],"big") for i in range(0,16,4)]
    v=[]
    for i in range(0,len(data),4):
        chunk=data[i:i+4]
        if len(chunk)<4: chunk += b"\x00"*(4-len(chunk))
        v.append(int.from_bytes(chunk,"big") & MBOHEN_MASK)
    n=len(v)
    if n<2: raise ValueError("FVIP blob too short")
    y=v[0]; rounds=6+52//n; sum_=(rounds*MBOHEN_DELTA)&MBOHEN_MASK
    for _ in range(rounds):
        e=(sum_>>2)&3
        for pos in range(n-1,0,-1):
            z=v[pos-1]
            v[pos]=(v[pos]-_mbohen_mx(z,y,sum_,pos,e,key_words))&MBOHEN_MASK
            y=v[pos]
        z=v[n-1]
        v[0]=(v[0]-_mbohen_mx(z,y,sum_,0,e,key_words))&MBOHEN_MASK
        y=v[0]; sum_=(sum_-MBOHEN_DELTA)&MBOHEN_MASK
    raw=b"".join(x.to_bytes(4,"big") for x in v)
    size=int.from_bytes(raw[:4],"big")
    body=raw[4:4+size]
    if not body.startswith(b"FVIP"):
        raise ValueError("FVIP marker not found after decrypt")
    return body[4:]

def master_mbohen_fvip_file(inp: Path, out: Path) -> dict:
    payload=master_mbohen_fvip_decrypt(inp.read_bytes())
    out.write_bytes(payload)
    return {"input":str(inp),"output":str(out),"payload_bytes":len(payload),
            "starts_lua":payload.startswith(b"\x1bLua"),
            "starts_source":payload.lstrip().startswith((b"--",b"local",b"function",b"_G"))}

def main():
    base=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser(description="SKUY Lua Master Parser: custom Lua 5.3 + constants/value-flow + RJ/SKUY layers + ALONE/ZAKPUBG license analysis")
    sub=ap.add_subparsers(dest="cmd")
    p=sub.add_parser("compile");p.add_argument("src");p.add_argument("out");p.add_argument("--luac",default=str(base/"EXES"/"luac"))
    p=sub.add_parser("restore-standard");p.add_argument("src");p.add_argument("out");p.add_argument("--source",default=None)
    p=sub.add_parser("decompile")
    p.add_argument("src")
    p.add_argument("out")
    p.add_argument("--source",default=None)
    p.add_argument("--engine",choices=["auto","luadec","unluac","nadeem"],default="auto")
    p.add_argument("--luadec",default=str(base/"EXES"/"luadec"))
    p.add_argument("--unluac",default=str(base/"EXES"/"unluac_pro.jar"))
    p.add_argument("--nadeem-jar",default=str(base/"EXES"/"LUADEC"))
    p.add_argument("--luac",default=str(base/"EXES"/"luac"))
    p=sub.add_parser("rescue-decompile")
    p.add_argument("src")
    p.add_argument("out_dir")
    p.add_argument("--source",default=None)
    p.add_argument("--nadeem-jar",default=str(base/"EXES"/"LUADEC"))
    p.add_argument("--unluac",default=str(base/"EXES"/"unluac_pro.jar"))
    p.add_argument("--luac",default=str(base/"EXES"/"luac"))
    p.add_argument("--timeout",type=int,default=20)
    p=sub.add_parser("native-disasm")
    p.add_argument("src")
    p.add_argument("out")
    p.add_argument("--cfg",default=None)
    p.add_argument("--include-extra-proto",action="store_true")

    p=sub.add_parser("native-source")
    p.add_argument("src")
    p.add_argument("out")
    p.add_argument("--include-extra-proto",action="store_true")

    p=sub.add_parser("scan-constants")
    p.add_argument("src")
    p.add_argument("--query", default=None)
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("patch-constant")
    p.add_argument("src")
    p.add_argument("out")
    p.add_argument("--proto", required=True)
    p.add_argument("--index", required=True, type=int)
    p.add_argument("--value", default=None)
    p.add_argument(
        "--type",
        choices=["auto","string","long_string","integer","number","boolean","nil"],
        default="auto",
    )
    p.add_argument("--expect", default=None)

    p=sub.add_parser("inspect-constants")
    p.add_argument("src")
    p.add_argument("--query", default=None)
    p.add_argument("--include-unreferenced", action="store_true")
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("make-patch-plan")
    p.add_argument("src")
    p.add_argument("out_plan")
    p.add_argument("--query", required=True)
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("apply-patch-plan")
    p.add_argument("src")
    p.add_argument("out")
    p.add_argument("plan")

    p=sub.add_parser("analyze-constant-context")
    p.add_argument("src")
    p.add_argument("--query", default=None)
    p.add_argument("--window", type=int, default=5)
    p.add_argument("--include-unreferenced", action="store_true")
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("constant-context-report")
    p.add_argument("src")
    p.add_argument("out_json")
    p.add_argument("--query", default=None)
    p.add_argument("--window", type=int, default=5)
    p.add_argument("--include-unreferenced", action="store_true")
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("analyze-value-flow")
    p.add_argument("src")
    p.add_argument("--query", default=None)
    p.add_argument("--window", type=int, default=4)
    p.add_argument("--max-steps", type=int, default=80)
    p.add_argument("--max-depth", type=int, default=12)
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("value-flow-report")
    p.add_argument("src")
    p.add_argument("out_json")
    p.add_argument("--query", default=None)
    p.add_argument("--window", type=int, default=4)
    p.add_argument("--max-steps", type=int, default=80)
    p.add_argument("--max-depth", type=int, default=12)
    p.add_argument("--include-extra-proto", action="store_true")

    p=sub.add_parser("analyze");p.add_argument("src")
    p=sub.add_parser("compare");p.add_argument("a");p.add_argument("b")

    p=sub.add_parser("strings")
    p.add_argument("src"); p.add_argument("--query",default=None); p.add_argument("--min-len",type=int,default=1)

    p=sub.add_parser("license-scan")
    p.add_argument("src"); p.add_argument("--out-json",default=None)

    p=sub.add_parser("key-verify")
    p.add_argument("key"); p.add_argument("--secret",default=ZAKPUBG_SECRET_2026)

    p=sub.add_parser("zak-key")
    p.add_argument("--expiry",required=True,type=int); p.add_argument("--activation",required=True,type=int)
    p.add_argument("--name",required=True); p.add_argument("--secret",default=ZAKPUBG_SECRET_2026)
    p.add_argument("--prefix",default=ZAKPUBG_PREFIX)

    p=sub.add_parser("alone-short-key")
    p.add_argument("--license-key",required=True); p.add_argument("--expiry",required=True,type=int)
    p.add_argument("--max-devices",required=True,type=int); p.add_argument("--secret",default=ZAKPUBG_SECRET_2026)

    p=sub.add_parser("repair-trailer-crc")
    p.add_argument("src"); p.add_argument("out")

    p=sub.add_parser("mbohen-recover")
    p.add_argument("src"); p.add_argument("out")

    sub.add_parser("project-notes")

    args=ap.parse_args()
    if not args.cmd:return menu(base)
    if args.cmd=="compile":print(compile_source(Path(args.src),Path(args.out),Path(args.luac)))
    elif args.cmd=="restore-standard":print(custom_to_standard_file(Path(args.src),Path(args.out),Path(args.source) if args.source else None))
    elif args.cmd=="decompile":
        print(json.dumps(decompile_file(
            Path(args.src),Path(args.out),Path(args.luadec),Path(args.unluac),
            source=Path(args.source) if args.source else None,
            luac=Path(args.luac),engine=args.engine,nadeem_jar=Path(args.nadeem_jar)
        ),indent=2))
    elif args.cmd=="rescue-decompile":
        print(json.dumps(rescue_decompile(
            Path(args.src),
            Path(args.out_dir),
            Path(args.nadeem_jar),
            Path(args.unluac) if args.unluac else None,
            source=Path(args.source) if args.source else None,
            luac=Path(args.luac),
            timeout_sec=args.timeout,
        ), indent=2))
    elif args.cmd=="native-disasm":
        print(json.dumps(native_disassemble(
            Path(args.src),
            Path(args.out),
            Path(args.cfg) if args.cfg else None,
            include_extra_proto=args.include_extra_proto,
        ), indent=2))
    elif args.cmd=="native-source":
        print(json.dumps(native_pseudolua(
            Path(args.src),
            Path(args.out),
            include_extra_proto=args.include_extra_proto,
        ), indent=2))
    elif args.cmd=="scan-constants":
        print(json.dumps(scan_constants(
            Path(args.src),
            query=args.query,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="patch-constant":
        print(json.dumps(patch_constant(
            Path(args.src),
            Path(args.out),
            proto_path=args.proto,
            index=args.index,
            value_text=args.value,
            type_name=args.type,
            expect=args.expect,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="inspect-constants":
        print(json.dumps(inspect_constants(
            Path(args.src),
            query=args.query,
            include_unreferenced=args.include_unreferenced,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="make-patch-plan":
        print(json.dumps(make_patch_plan(
            Path(args.src),
            Path(args.out_plan),
            query=args.query,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="apply-patch-plan":
        print(json.dumps(apply_patch_plan(
            Path(args.src),
            Path(args.out),
            Path(args.plan),
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="analyze-constant-context":
        print(json.dumps(analyze_constant_context(
            Path(args.src),
            query=args.query,
            window=args.window,
            include_unreferenced=args.include_unreferenced,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="constant-context-report":
        print(json.dumps(write_constant_context_report(
            Path(args.src),
            Path(args.out_json),
            query=args.query,
            window=args.window,
            include_unreferenced=args.include_unreferenced,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="analyze-value-flow":
        print(json.dumps(analyze_value_flow(
            Path(args.src),
            query=args.query,
            window=args.window,
            max_steps=args.max_steps,
            max_depth=args.max_depth,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="value-flow-report":
        print(json.dumps(write_value_flow_report(
            Path(args.src),
            Path(args.out_json),
            query=args.query,
            window=args.window,
            max_steps=args.max_steps,
            max_depth=args.max_depth,
            include_extra_proto=args.include_extra_proto,
        ), indent=2, ensure_ascii=False))
    elif args.cmd=="strings":
        print(json.dumps(master_extract_strings(Path(args.src),query=args.query,min_len=args.min_len),indent=2,ensure_ascii=False))
    elif args.cmd=="license-scan":
        rep=master_license_scan(Path(args.src))
        if args.out_json:
            Path(args.out_json).write_text(json.dumps(rep,indent=2,ensure_ascii=False),encoding="utf-8")
        print(json.dumps(rep,indent=2,ensure_ascii=False))
    elif args.cmd=="key-verify":
        print(json.dumps(master_parse_license_key(args.key,secret=args.secret),indent=2,ensure_ascii=False))
    elif args.cmd=="zak-key":
        key=master_zak_make(args.expiry,args.activation,args.name,secret=args.secret,prefix=args.prefix)
        print(key)
        print(json.dumps(master_zak_parse(key,secret=args.secret,prefix=args.prefix),indent=2,ensure_ascii=False))
    elif args.cmd=="alone-short-key":
        key=master_alone_short_make(args.license_key,args.expiry,args.max_devices,secret=args.secret)
        print(key)
        print(json.dumps(master_alone_short_parse(key,secret=args.secret),indent=2,ensure_ascii=False))
    elif args.cmd=="repair-trailer-crc":
        print(json.dumps(master_repair_trailer_crc_file(Path(args.src),Path(args.out)),indent=2,ensure_ascii=False))
    elif args.cmd=="mbohen-recover":
        print(json.dumps(master_mbohen_fvip_file(Path(args.src),Path(args.out)),indent=2,ensure_ascii=False))
    elif args.cmd=="project-notes":
        print(json.dumps(master_known_project_notes(),indent=2,ensure_ascii=False))
    elif args.cmd=="analyze":
        print(json.dumps(analyze_file(Path(args.src)),indent=2))
    elif args.cmd=="compare":
        print(json.dumps(compare_files(Path(args.a),Path(args.b)),indent=2))

if __name__=="__main__": main()
