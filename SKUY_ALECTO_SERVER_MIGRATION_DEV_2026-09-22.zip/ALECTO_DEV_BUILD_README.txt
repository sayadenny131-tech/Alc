ALECTO DEV BUILD - LOCAL MOCK AUTH
==================================

BASELINE PRODUKSI (LOCK):
alecto_full_SERVER_MIGRATED_no_RJ.lua
SHA-256: 4bafa9ff31c7e00ab5e867545138ef16e37b6c410ea8989378938295cd03e8f2

DEV BUILD:
alecto_full_SERVER_MIGRATED_DEV_no_login.lua
SHA-256: f7084ce44ca15405f55416c15a7b6e3c9e98fa0036b675d44937a57ee80fbbd2

TUJUAN:
- Build khusus pengembangan fitur / profiling CPU.
- Tidak melakukan POST auth ke server produksi pada jalur auth yang dipatch.
- Memasuki blok sukses auth yang sudah ada secara lokal.
- Baseline produksi tidak diubah.

PATCH:
1. Callback auth PC0 -> JMP ke existing success block PC52.
2. Auth function PC78..80 -> buat callback lokal, panggil tanpa HTTP Post, lalu return.

VALIDASI:
- Size: 2,501,855 -> 2,501,855 (SAMA)
- parse_end: 2,501,855 -> 2,501,855 (SAMA)
- Prototypes: 169 -> 169
- Instructions: 51,435 -> 51,435
- Constants: 1,898 -> 1,898
- Byte aktual berbeda: 15
- Parser: PASS

CATATAN:
Gunakan DEV build hanya untuk pengembangan. Untuk build produksi gunakan baseline LOCK yang tetap memakai auth server baru.
