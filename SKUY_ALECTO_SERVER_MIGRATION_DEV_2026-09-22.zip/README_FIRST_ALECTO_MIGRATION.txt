README FIRST - SKUY ALECTO MIGRATION ARCHIVE
============================================

Start with:
  SKUY_ALECTO_SERVER_MIGRATION_DEV_HANDOFF_2026-09-22.docx

Production baseline (LOCK):
  allecto_full_SERVER_MIGRATED_no_RJ.lua
  SHA-256: 4bafa9ff31c7e00ab5e867545138ef16e37b6c410ea8989378938295cd03e8f2

Development baseline:
  allecto_full_SERVER_MIGRATED_DEV_no_login.lua
  SHA-256: f7084ce44ca15405f55416c15a7b6e3c9e98fa0036b675d44937a57ee80fbbd2

Latest worker baseline:
  worker_GRW_COMPAT_TEST.txt
  SHA-256: 30ec4cc9d7e8c089f83cec1b046e21317ec12ea91fd920b87deaa4cba3843f40

Status: migration WORKING; DEV build WORKING (user runtime confirmation).
